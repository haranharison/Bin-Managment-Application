<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Charge extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
	$this->load->model('Charge_model','model');
	 }	
	 public function index()
	{
		$data['menu']='fare_settings';
		$data['submenu']='charge';
		
		$data['brand']=$this->model->getbrand();
		$data['details']=$this->model->getalldetails();
		$this->load->view('admin/do_header',$data);
		$this->load->view('admin/charge/addcharge',$data);
		$this->load->view('admin/footer');
	}
	
	public function get_mincharge(){
		$this->model->get_mincharge();
	}
	public function getmodel(){
		$this->model->getmodel();
	}
	public function mypdf($id=false)
	{
		$this->model->generatemypdf($id);
	}
	
	public function insert()
	{
		$this->model->insert();	
	}
	public function view($id=false)
	{
		$data['menu']='fare_settings';
		$data['submenu']='charge';
		
		$data['details']=$this->model->viewone($id);	
		$this->load->view('admin/do_header',$data);
		$this->load->view('admin/charge/view',$data);
		$this->load->view('admin/footer');
	}
	
	
	/*public function deleteService()
	{
		$this->model->deleteService();	
	}

     public function seredit($id=false){
		$mid=decode($id);
		$data['edit']=$this->model->editservice($mid);
		$data['service']=$this->model->getservice();
		$data['menu']='service';
		$data['submenu']='sservice';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/service/serviceedit',$data);
		$this->load->view('admin/footer'); 
		}
   	public function updateservice(){
		$this->model->updateservice();
	}
	
	
	public function getmin_charge(){
		$this->model->getmin_charge();
	}*/
	
	
}

