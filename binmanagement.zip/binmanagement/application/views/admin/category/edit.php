
<style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
			 .panel-heading1 {
		 font-size: 18px;
    font-weight: 300;
    letter-spacing: 0.025em;
    height: 66px;
    line-height: 45px;
    background: ##ddd;
    border-bottom: 1px solid #eee;
    color: #333;
	padding: 10px 15px;
    /* background: #428bca; */
}
</style>
 
		
	 <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Edit Category</h4>
                      <div class="row">
                    
							<form role="form" name="frmncat" action=""  id="frmncat"method="post">
							 <div class="row">
                            <div class="input-field col s12">
                           <input type="hidden" name="txthiden" id="txthiden"  value="<?php if($edit){ echo encode($edit->category_id);}?>" >
								<input class="text" placeholder="Category" name="txtcategory" id="txtcategory" type="text" value="<?php if($edit) {echo $edit->cat_name;}  ?>" >
							 <label for="first_name">Edit Category</label>
                            </div>
                            </div>
                     <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnsubmit">Update   <i class="material-icons right">send</i></button>
                                   <button class="btn cyan waves-effect waves-light right" type="reset" name="action" id="btncancel">Cancel</button>
                                 
                             
                              </div>
                            </div>
                          </div>
                           <!-- <div class="col-md-6" >
                              <a href="#" class="btn btn-primary btn-block lg" id="btnupdate" style="float:right:">Update</a></div>
                            	<div class="col-md-6">  <a href="" id="btncancel" class="btn btn-default btn-block lg" style="float:left;">Cancel</a></div>
								-->
                            
						<!--	    <div class="col-md-5"></div>   <div class="text-center "><a href="index.php" class="btn btn-primary btn-block lg">Submit</a>
                    <div class="col-md-4">
                    
                          
                         <a href="index.php" class="btn btn-primary btn-block lg">Submit</a>
                         
                          </div>
                            <div class="col-md-4">
                    
                          
                         <a href="index.php" class="btn btn-primary btn-block lg">Cancel</a>
                        </div></div>-->
                      
                            </fieldset>
								
								
								
							
								
							</form>	
						
							
						
					</div>
				</div>
                </div>
                <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Category</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                           <th style="width:10% !important;text-align:center;">SN</th>
                          <th style="width:100% !important;text-align:left;">Category</th>
                          <th style="width:20% !important;">Action</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php if($category) { $i=1; foreach($category as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:10% !important;text-align:center;"><?php echo $i ?></td>
								<td style="width:100% !important;text-align:left;"><?php echo $val->cat_name?> </td>
								<td style="width:20% !important;"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>category/editCategories/<?php echo encode($val->category_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->category_id);?>">
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
                
                	 <div class="panel-footer"></div>
                     </div>
                     </div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div>
    </div>
    <!--/.main-->
    
    
    <script src="<?php echo ADMIN_STYLEPATH ?>js/jquery-1.11.1.min.js" type="text/javascript"></script>


<script type="text/javascript">

$(document).ready(function(e) {
   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			//alert(1);
			var e=validation();
			if(e==0){
				$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>category/updatecategory";
  			var redirect = "<?php echo ADMIN_PATH?>category";
  			var form = document.forms.namedItem("frmncat");                        
			var oData = new FormData(document.forms.namedItem("frmncat"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
					$('.overlay').css({'display':'none'});
				 if(oReq.responseText==1){
					  swal("Already Exist!", "Exist!", "Exist")
					  
					 }
					 else
					 {
						 swal({
								  title: '<div class="tst" >Success</div>',
								  html:'<div class="tst1" >Category has been Updated</div>',
								  type: 'success',
								  customClass: 'swal-delete',
								})
 					document.location = redirect;
					 }}
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

      
       $('input').removeClass('errors');
		$('label').removeClass('labelerror');
        $('select').removeClass('errors');

            var values = {
                                    'category':$('#txtcategory').val(),

                                 }

        if(values.category == ''){
			  $('#txtcategory').addClass('errors');
              $('#txtcategory').attr("placeholder", "Please enter Category.");
			  $('#txtcategory').parent().children('label').addClass('labelerror');
            error=1;
        } 
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	var redirect = "<?php echo ADMIN_PATH?>category";
				document.location = redirect;
        });
	//---------End cancel------//	
	//------------delete------//
});

		   $(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel'); 
				var redirect ="<?php echo ADMIN_PATH?>category" ;
 swal({
                            title: "Are you sure?",
							   text: "Delete this Category",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:"swal-delete",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          }).then(function(){
						  $('.overlay').css({'display':'flex'});
			
			
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>category/deleteCategories",
					redirect : "<?php echo ADMIN_PATH?>category",

                                            data:"id="+id,

                                            success:function(data){ 
												
											$('.overlay').css({'display':'none'});
                                  	
	                                swal({
								  title: '<div class="tst" >Success</div>',
								  html:'<div class="tst1" >Category has been Deleted</div>',
								  type: 'success',
								  customClass: 'swal-delete',
								})
								document.location = redirect;
                                            }
                  });
					

				          });

		
			  
        });
		//------------end delete----------//
</script>


    
    
    
    
    
    
    
    
    

