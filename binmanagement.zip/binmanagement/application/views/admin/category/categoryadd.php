 

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">New Category</h4>
                      <div class="row">
                       <form role="form" name="frmncat" action="" id="form-role-category-add" method="post">
                          <div class="row">
                            <div class="input-field col s12">
                              <input placeholder="Enter Category Name" name="txtcategory" id="txtcategory" type="text">
                              <label for="first_name">New Category</label>
                            </div>
                          </div>
                          
                          
                          <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnsubmit" style="margin-right:9px;">Submit
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Category</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:10% !important;text-align:center;">SN</th>
                          <th style="width:100% !important;text-align:left;">Category</th>
                          <th style="width:20% !important;">Action</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php if($category) { $i=1; foreach($category as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:10% !important;text-align:center;"><?php echo $i ?></td>
								<td style="width:100% !important;text-align:left;"><?php echo $val->cat_name?> </td>
								<td > 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>category/editCategories/<?php echo encode($val->category_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->category_id);?>" href="#">
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

  
<script type="text/javascript">

$(document).ready(function(e) {
   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			
			var e=validation();
			if(e==0){ 
			$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>category/addcategory";
  			var redirect = "<?php echo ADMIN_PATH?>category";
  			var form = document.forms.namedItem("frmncat");                        
			var oData = new FormData(document.forms.namedItem("frmncat"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { console.log(oReq.responseText);
					$('.overlay').css({'display':'none'});
				 if(oReq.responseText==1){
					// alert("Exist");
					customSwalFunD("Alreadt Exist!", "Exist!", "error")
					  //alert("Exist");
					 }
					 else
					 {swal({
								  title: '<div class="tst" >Success</div>',
								  html:'<div class="tst1" >Category has been Added</div>',
								  type: 'success',
								  customClass: 'swal-delete',
								})
						setTimeout(function(){
 	document.location = redirect;
						 	},600)

					
					 }
					
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

       $('input').removeClass('errors');
		$('label').removeClass('labelerror');
        $('select').removeClass('errors');

            var values = {
                                    'category':$('#txtcategory').val(),

                                 }

        if(values.category == ''){
			  $('#txtcategory').addClass('errors');
              $('#txtcategory').attr("placeholder", "Please enter Category.");
			  $('#txtcategory').parent().children('label').addClass('labelerror');
            error=1;
        } 
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmncat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
	
	
	
	// ---------- < Delete Category   > ---------- /
		
		   $(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
 swal({
                            title: "Are you sure?",
							   text: "Delete this Category",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:"swal-delete",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          }).then(function(){
							  $('.overlay').css({'display':'flex'});
                                        $.ajax({
                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>category/deleteCategories",
                                            data:"id="+id,

                                            success:function(data){ //alert(data);
											 $('.overlay').css({'display':'none'});
										swal({
								  title: '<div class="tst" >Success</div>',
								  html:'<div class="tst1" >Category has been Deleted</div>',
								  type: 'success',
								  customClass: 'swal-delete',
								})		
                                  location.reload() ;
                                            }
           
     

                                        });
					

				          });

		
			  
        });
		
});
</script>


    
    
    
    
    
    
    
    
    

