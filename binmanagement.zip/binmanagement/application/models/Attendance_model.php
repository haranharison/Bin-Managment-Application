<?php
class Attendance_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	
	public function addattend()
		{
		date_default_timezone_set("Asia/Calcutta");
		$today=date('Y-m-d H:i:s');
		$date = new DateTime("now");
		$curr_date = $date->format('Y-m-d ');
		$this->db->where('DATE(date)',$curr_date);
		$this->db->where('emp_id',$this->session->userdata('username'));
		$this->db->select('tbl_attendance.*');
		$this->db->from('tbl_attendance');
		$atn=$this->db->get()->result();
		if(empty($atn))
		{
		$max=maxplus('tbl_attendance','attend_id');
			///////////////////////////////////////Attachment////////////////////////////		
		$config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('imgfile')) {
                $error = array('error'=>$this->upload->display_errors());
            } else {
            $data = array('upload_data'=>$this->upload->data());
            }
            $path='./uploads/'.$data['upload_data']['file_name'];
		//echo $path;
/////////////////////////////////////////////////////////////////////////////////////////////////////	
		$data= array(
		'org_id'=>$this->session->userdata('org_id'),
			   'attend_id' =>$max,
		       'emp_id'=>$this->session->userdata('username'),
			   'date'=>$today,
			   'photo'=>$path,
			   'latitude'=>$this->input->post('latitude'),
			   'longitude'=>$this->input->post('longitude'),
			   'created_date'=>$today,
			   'modified_date'=>$today
		);
		$this->db->insert('tbl_attendance',$data);
		
		echo 1;
		}
		}
	public function getprodetails()
		{
		
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),'salesmanid'=>$this->session->userdata('emp_id'));
			$this->db->where($array);
			$this->db->select('attendance_tracker');
			return $rows=$this->db->get('tbl_salesmanreg')->row();
		
		}
}