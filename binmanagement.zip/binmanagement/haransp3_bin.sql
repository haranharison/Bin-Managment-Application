-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 17, 2021 at 05:23 AM
-- Server version: 10.2.37-MariaDB-cll-lve
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `haransp3_bin`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_additional_part`
--

CREATE TABLE `tbl_additional_part` (
  `id` int(11) NOT NULL,
  `part_id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `part_name` varchar(100) NOT NULL,
  `part_amt` varchar(20) NOT NULL,
  `part_gst` varchar(20) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_advertisement`
--

CREATE TABLE `tbl_advertisement` (
  `id` int(11) NOT NULL,
  `adv_id` int(11) NOT NULL,
  `adv_title` varchar(500) NOT NULL,
  `adv_website` varchar(100) NOT NULL,
  `adv_img` varchar(300) NOT NULL,
  `adv_position` int(11) NOT NULL,
  `publish_status` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_area`
--

CREATE TABLE `tbl_area` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `area_id` int(11) NOT NULL,
  `area_name` varchar(50) NOT NULL,
  `latitude` varchar(100) NOT NULL,
  `longitude` varchar(100) NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_attendance`
--

CREATE TABLE `tbl_attendance` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `attend_id` int(11) NOT NULL,
  `emp_id` varchar(11) NOT NULL,
  `emp_name` varchar(100) NOT NULL,
  `abs_date` datetime NOT NULL,
  `reason` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_attendance`
--

INSERT INTO `tbl_attendance` (`id`, `org_id`, `attend_id`, `emp_id`, `emp_name`, `abs_date`, `reason`, `created_date`, `modified_date`, `status`) VALUES
(1, 'O_1 ', 1, 'AAAA', '', '2011-05-21 00:00:00', 3, '2021-05-11 00:00:00', '2021-05-11 00:00:00', '1'),
(2, 'O_1 ', 2, 'ASD346', '', '2011-05-21 00:00:00', 2, '2021-05-11 00:00:00', '2021-05-11 00:00:00', '0'),
(3, 'O_1 ', 3, '23245565', '', '2012-05-21 00:00:00', 2, '2021-05-12 00:00:00', '2021-05-12 00:00:00', '0'),
(4, '', 4, 'ASD125', '', '2013-05-21 00:00:00', 2, '2021-05-13 00:00:00', '2021-05-13 00:00:00', '0'),
(5, '', 5, 'AZS', '', '2013-05-21 00:00:00', 2, '2021-05-13 00:00:00', '2021-05-13 00:00:00', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_authreg`
--

CREATE TABLE `tbl_authreg` (
  `id` int(11) NOT NULL,
  `authid` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `phoneno` varchar(20) NOT NULL,
  `empcode` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `empid` varchar(100) NOT NULL,
  `emp_education` varchar(100) NOT NULL,
  `emp_qualification` varchar(100) NOT NULL,
  `emp_experience` varchar(200) NOT NULL,
  `nationality` varchar(100) NOT NULL,
  `family_status` varchar(20) NOT NULL,
  `date_of_birth` date NOT NULL,
  `date_of_joining` date NOT NULL,
  `emp_email` varchar(100) NOT NULL,
  `starttime` varchar(25) NOT NULL,
  `endtime` varchar(25) NOT NULL,
  `password` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  `permission` varchar(500) NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_authreg`
--

INSERT INTO `tbl_authreg` (`id`, `authid`, `org_id`, `name`, `address`, `designation`, `phoneno`, `empcode`, `gender`, `empid`, `emp_education`, `emp_qualification`, `emp_experience`, `nationality`, `family_status`, `date_of_birth`, `date_of_joining`, `emp_email`, `starttime`, `endtime`, `password`, `image`, `permission`, `create_date`, `modify_date`, `status`) VALUES
(15, 15, 'O_1 ', 'Sam', 'Kollam', '5', '8943043767', 'Auth_8943043767', 'male', 'sam123', '5', 'MCA', '2 Years', 'Indian', '1', '2021-05-13', '2021-05-20', 'sam123@gmail.com', '6', '14', '123', '/uploads/ddd1.png', '11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28', '2021-05-12', '2021-05-12', 0),
(16, 16, 'O_1 ', 'Das', 'Kollam', '3', '7907444297', 'Auth_7907444297', 'male', 'das123', '', 'BCA', 'BCA', 'Indian', '1 ', '2019-05-07', '2021-05-12', 'das@gmail.com', '7', '8', '123', '/uploads/ddd3.png', '21,22,23,24,15,16,18', '2021-05-12', '2021-05-14', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bank`
--

CREATE TABLE `tbl_bank` (
  `b_tid` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `b_uid` int(11) NOT NULL,
  `b_bname` varchar(60) NOT NULL,
  `b_created_date` date NOT NULL,
  `b_modify_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bin`
--

CREATE TABLE `tbl_bin` (
  `id` int(11) NOT NULL,
  `bin_id` int(11) NOT NULL,
  `org_id` varchar(50) NOT NULL,
  `pro_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `qty` int(11) NOT NULL,
  `bin_date` date NOT NULL,
  `reason` varchar(500) NOT NULL,
  `description` varchar(500) NOT NULL,
  `rack` varchar(250) NOT NULL,
  `user_bin` varchar(100) NOT NULL,
  `crea_date` varchar(30) NOT NULL,
  `mod_date` varchar(30) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_bin`
--

INSERT INTO `tbl_bin` (`id`, `bin_id`, `org_id`, `pro_id`, `cat_id`, `sub_id`, `unit`, `qty`, `bin_date`, `reason`, `description`, `rack`, `user_bin`, `crea_date`, `mod_date`, `status`) VALUES
(1, 1, 'O_1 ', 1, 2, 0, '3', 2, '2021-04-21', 'test', 'test', 'test', 'O_1 ', '21-04-25', '20210426', 1),
(2, 2, 'O_1 ', 1, 2, 3, '3', 2, '2021-04-26', 'test', 'Icecreams', 'test', 'O_1 ', '21-04-25', '20210426', 0),
(3, 3, 'O_1 ', 2, 2, 3, '3', 2, '2021-04-26', 'test', '', '', 'O_1 ', '21-04-26', '20210426', 0),
(10, 4, 'O_1 ', 2, 2, 3, '3', 2, '2021-04-30', 'test', 'Icecreams', '25', 'O_1 ', '21-04-30', '21-04-30', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brand`
--

CREATE TABLE `tbl_brand` (
  `id` int(11) NOT NULL,
  `man_id` int(100) NOT NULL,
  `org_id` varchar(10) NOT NULL,
  `man_title` varchar(200) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_brand`
--

INSERT INTO `tbl_brand` (`id`, `man_id`, `org_id`, `man_title`, `created_date`, `modified_date`, `status`) VALUES
(1, 1, 'O_1', 'mahindra', '2018-07-19', '2018-07-19', 0),
(2, 2, 'O_4', 'honda', '2018-07-24', '2018-07-24', 0),
(3, 3, 'O_4', 'hero', '2018-07-24', '2018-07-24', 0),
(4, 4, 'O_5', 'Honda', '2018-07-24', '2018-07-24', 0),
(5, 5, 'O_1', 'nissan', '2018-07-31', '2018-07-31', 0),
(6, 6, 'O_6', 'mahindra', '2018-08-02', '2018-08-02', 0),
(7, 7, 'O_6', 'renault', '2018-08-02', '2018-08-02', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cashcollect`
--

CREATE TABLE `tbl_cashcollect` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `cashcollect_id` int(11) NOT NULL,
  `salesman_id` varchar(50) NOT NULL,
  `merchant_id` int(11) NOT NULL,
  `terminal` varchar(30) NOT NULL,
  `area_id` int(11) NOT NULL,
  `amount` varchar(30) NOT NULL,
  `type` varchar(10) NOT NULL,
  `checkno` varchar(30) NOT NULL,
  `date` varchar(50) NOT NULL,
  `bank` varchar(60) NOT NULL,
  `branch` varchar(60) NOT NULL,
  `status` int(11) NOT NULL,
  `create_time` time NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `cat_id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL,
  `cat_name` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`cat_id`, `org_id`, `category_id`, `cat_name`, `status`, `create_date`, `modify_date`) VALUES
(1, 'O_1', 1, 'gdfgdfg', 1, '2018-12-01', '2018-12-01'),
(2, 'O_1 ', 2, 'Ice Cream', 0, '2021-04-26', '2021-04-26'),
(3, 'O_1 ', 3, 'Tooth Paste', 0, '2021-04-26', '2021-04-26'),
(4, 'O_1 ', 4, 'Wheat Powder', 0, '2021-04-26', '2021-04-26'),
(5, '', 5, 'Chilled ', 0, '2021-05-12', '2021-05-12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_credit_details`
--

CREATE TABLE `tbl_credit_details` (
  `id` int(11) NOT NULL,
  `credit_details_id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `employee_id` varchar(100) NOT NULL,
  `merchant_id` varchar(100) NOT NULL,
  `invoice_id` varchar(100) NOT NULL,
  `payment_mode` int(11) NOT NULL,
  `payment_type` int(11) NOT NULL,
  `credit_amt` decimal(13,2) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_currentlocation`
--

CREATE TABLE `tbl_currentlocation` (
  `location_id` int(11) NOT NULL,
  `latitude` varchar(20) NOT NULL,
  `longitude` varchar(20) NOT NULL,
  `emp_id` varchar(20) NOT NULL,
  `created_time` time NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_designation`
--

CREATE TABLE `tbl_designation` (
  `id` int(11) NOT NULL,
  `desi_id` int(11) NOT NULL,
  `org_id` varchar(110) NOT NULL,
  `desi_name` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_designation`
--

INSERT INTO `tbl_designation` (`id`, `desi_id`, `org_id`, `desi_name`, `status`, `created_date`, `modified_date`) VALUES
(1, 1, 'O_1 ', 'Manager', 0, '2021-05-03', '2021-05-03'),
(6, 2, 'O_1 ', 'Employee', 0, '2021-05-12', '2021-05-12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_driverdetails`
--

CREATE TABLE `tbl_driverdetails` (
  `id` int(11) NOT NULL,
  `did` int(11) NOT NULL,
  `regid` varchar(30) NOT NULL,
  `regno` varchar(30) NOT NULL,
  `dname` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `telno` varchar(20) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `licenseno` varchar(30) NOT NULL,
  `created_on` date NOT NULL,
  `modified_on` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_driverdetails`
--

INSERT INTO `tbl_driverdetails` (`id`, `did`, `regid`, `regno`, `dname`, `address`, `telno`, `mobile`, `licenseno`, `created_on`, `modified_on`, `status`) VALUES
(3, 3, 'ch7736342051', '258246', 'binu', 'sjadhj', '2265625', '8589859945', 'fh5749357', '2018-08-02', '2018-08-02', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_education`
--

CREATE TABLE `tbl_education` (
  `id` int(11) NOT NULL,
  `education_id` int(50) NOT NULL,
  `org_id` varchar(50) NOT NULL,
  `educationname` varchar(100) NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_education`
--

INSERT INTO `tbl_education` (`id`, `education_id`, `org_id`, `educationname`, `create_date`, `modify_date`, `status`) VALUES
(1, 1, 'O_1 ', 'SSLC', '2021-05-03', '2021-05-03', 0),
(2, 2, 'O_1 ', 'Higher Secondary', '2021-05-03', '2021-05-03', 0),
(3, 3, 'O_1 ', 'UG', '2021-05-03', '2021-05-03', 0),
(4, 4, 'O_1 ', 'PG', '2021-05-03', '2021-05-03', 0),
(5, 5, '', 'PG', '2021-05-12', '2021-05-12', 0),
(6, 6, '', 'UG', '2021-05-12', '2021-05-12', 0),
(7, 7, '', 'Higher Secondary', '2021-05-12', '2021-05-12', 0),
(8, 8, '', 'SSLC', '2021-05-12', '2021-05-12', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_emparea`
--

CREATE TABLE `tbl_emparea` (
  `slno` int(11) NOT NULL,
  `emp_id` varchar(20) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `area_id` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_empverification`
--

CREATE TABLE `tbl_empverification` (
  `id` int(11) NOT NULL,
  `ver_id` int(50) NOT NULL,
  `emp_id` int(50) NOT NULL,
  `org_id` varchar(50) NOT NULL,
  `verification` varchar(20) NOT NULL,
  `agency_name` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `status` int(20) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_emp_education`
--

CREATE TABLE `tbl_emp_education` (
  `emp_edu_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `education_id` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_emp_education`
--

INSERT INTO `tbl_emp_education` (`emp_edu_id`, `emp_id`, `org_id`, `education_id`, `created_date`, `modified_date`, `status`) VALUES
(1, 4, 'O_1 ', 0, '2021-05-03', '2021-05-03', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_enquiry`
--

CREATE TABLE `tbl_enquiry` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `en_id` int(11) NOT NULL,
  `merchant` varchar(25) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `address` varchar(300) NOT NULL,
  `landno` varchar(12) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `auth_person` varchar(50) NOT NULL,
  `en_date` date NOT NULL,
  `requirement` varchar(500) NOT NULL,
  `follow_date` date NOT NULL,
  `feedback` varchar(500) NOT NULL,
  `mar_status` int(11) NOT NULL,
  `lat` float NOT NULL,
  `long` float NOT NULL,
  `product_intro` varchar(1000) NOT NULL,
  `any_addi_info` varchar(1000) NOT NULL,
  `view_status` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `crea_date` date NOT NULL,
  `mod_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_enquiry_status`
--

CREATE TABLE `tbl_enquiry_status` (
  `id` int(11) NOT NULL,
  `enquiry_status_id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `status_name` varchar(100) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fare_settings`
--

CREATE TABLE `tbl_fare_settings` (
  `id` int(11) NOT NULL,
  `fare_settings_id` int(11) NOT NULL,
  `owner_id` varchar(10) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `model_id` int(11) NOT NULL,
  `min_charge` decimal(10,2) NOT NULL,
  `min_charge_km` varchar(15) NOT NULL,
  `rate_per_km` decimal(10,2) NOT NULL,
  `wait_time` varchar(15) NOT NULL,
  `after_wait_time` varchar(15) NOT NULL,
  `after_wait_time_amt` decimal(10,2) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_fare_settings`
--

INSERT INTO `tbl_fare_settings` (`id`, `fare_settings_id`, `owner_id`, `brand_id`, `model_id`, `min_charge`, `min_charge_km`, `rate_per_km`, `wait_time`, `after_wait_time`, `after_wait_time_amt`, `created_date`, `modified_date`, `status`) VALUES
(1, 1, '119', 4, 2, 250.00, '10', 20.00, '00:10', '00:10', 200.00, '2018-07-24', '2018-07-24', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hsn`
--

CREATE TABLE `tbl_hsn` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `hsn_id` varchar(50) NOT NULL,
  `hsn_code` varchar(100) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_hsn`
--

INSERT INTO `tbl_hsn` (`id`, `org_id`, `hsn_id`, `hsn_code`, `created_date`, `modified_date`, `status`) VALUES
(1, 'O_1 ', '1', 'ASD25', '2021-04-26', '2021-04-26', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE `tbl_login` (
  `id` int(11) NOT NULL,
  `emp_id` varchar(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usergroup` varchar(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`id`, `emp_id`, `username`, `password`, `usergroup`, `org_id`, `email`, `created_date`, `modified_date`, `status`) VALUES
(1, '0', 'admin', 'admin123', '0', '', '', '2017-11-03', '2017-11-03', 0),
(151, '15', '8943043767', '123', 'auth', 'O_1', 'sam123@gmail.com', '2021-05-12', '2021-05-12', 0),
(152, 'O_1', '3', '123', 'org', 'O_1', 'info.cafe@gmail.com', '2021-05-12', '2021-05-12', 0),
(153, '16', '7907444297', '123', 'auth', 'O_1 ', 'das@gmail.com', '2021-05-12', '2021-05-14', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_manufacture`
--

CREATE TABLE `tbl_manufacture` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `manufacture_id` int(11) NOT NULL,
  `manufacture_name` varchar(100) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_manufacture`
--

INSERT INTO `tbl_manufacture` (`id`, `org_id`, `manufacture_id`, `manufacture_name`, `created_date`, `modified_date`, `status`) VALUES
(1, 'O_1 ', 1, 'Arun Foods', '2021-04-26', '2021-04-26', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_measurement`
--

CREATE TABLE `tbl_measurement` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `measurement_id` int(11) NOT NULL,
  `measurement_name` varchar(100) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_measurement`
--

INSERT INTO `tbl_measurement` (`id`, `org_id`, `measurement_id`, `measurement_name`, `created_date`, `modified_date`, `status`) VALUES
(1, 'O_1 ', 1, 'KG', '2021-04-26', '2021-04-26', 0),
(2, 'O_1 ', 2, 'GM', '2021-04-26', '2021-04-26', 0),
(3, 'O_1 ', 3, 'No\'s', '2021-04-26', '2021-04-26', 0),
(4, 'O_1 ', 4, 'Bag', '2021-04-26', '2021-04-26', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menu`
--

CREATE TABLE `tbl_menu` (
  `menu_id` int(11) NOT NULL,
  `menu_name` varchar(50) NOT NULL,
  `menu_icon` varchar(100) NOT NULL,
  `menu_path` varchar(200) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_merchant`
--

CREATE TABLE `tbl_merchant` (
  `id` int(11) NOT NULL,
  `merchant_id` int(11) NOT NULL,
  `merchantname` varchar(50) NOT NULL,
  `merchantid_num` varchar(20) NOT NULL,
  `numofterminals` int(11) NOT NULL,
  `address` varchar(50) NOT NULL,
  `phoneno` varchar(20) NOT NULL,
  `authorised_person` varchar(50) NOT NULL,
  `gst_reg` varchar(50) NOT NULL,
  `mer_land_phone` varchar(50) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `latitude` varchar(50) NOT NULL,
  `longitude` varchar(50) NOT NULL,
  `creditlimit` varchar(50) NOT NULL,
  `tax_type` int(11) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_no` varchar(50) NOT NULL,
  `ifsc_code` varchar(50) NOT NULL,
  `dates` varchar(30) NOT NULL,
  `logo` varchar(150) NOT NULL,
  `image` varchar(150) NOT NULL,
  `status` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL,
  `org_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_merchantcategory`
--

CREATE TABLE `tbl_merchantcategory` (
  `id` int(11) NOT NULL,
  `merchant_id` int(11) NOT NULL,
  `merchant_procatid` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  `merchant_product` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `create_date` int(11) NOT NULL,
  `modify_date` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_merchantprocat`
--

CREATE TABLE `tbl_merchantprocat` (
  `id` int(11) NOT NULL,
  `merchant_id` int(11) NOT NULL,
  `merchant_procatid` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_merchantproduct`
--

CREATE TABLE `tbl_merchantproduct` (
  `id` int(11) NOT NULL,
  `merchant_id` int(11) NOT NULL,
  `merchant_product` int(11) NOT NULL,
  `merchant_product_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mincharge`
--

CREATE TABLE `tbl_mincharge` (
  `id` int(11) NOT NULL,
  `min_id` int(11) NOT NULL,
  `org_id` varchar(10) NOT NULL,
  `driver_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `model_id` int(11) NOT NULL,
  `c_name` varchar(100) NOT NULL,
  `c_id` varchar(100) NOT NULL,
  `s_km` varchar(100) NOT NULL,
  `e_km` varchar(100) NOT NULL,
  `w_time` varchar(100) NOT NULL,
  `min_charge` varchar(100) NOT NULL,
  `totalfare` varchar(15) NOT NULL,
  `created_date` date NOT NULL,
  `modifi_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_mincharge`
--

INSERT INTO `tbl_mincharge` (`id`, `min_id`, `org_id`, `driver_id`, `brand_id`, `model_id`, `c_name`, `c_id`, `s_km`, `e_km`, `w_time`, `min_charge`, `totalfare`, `created_date`, `modifi_date`, `status`) VALUES
(1, 1, 'O_5', 119, 4, 2, 'Das', 'Das123', '6500', '6750', '00:10', '250.00', '0', '2018-07-24', '2018-07-24', 0),
(2, 2, 'O_5', 119, 4, 2, 'Das', 'Das123', '6500', '6750', '00:10', '250.00', '0', '2018-07-24', '2018-07-24', 0),
(3, 3, 'O_5', 119, 4, 2, 'Faizy', 'FAZ', '5000', '5250', '00:10', '250.00', '0', '2018-07-24', '2018-07-24', 0),
(4, 4, 'O_5', 119, 4, 2, 'k', 'k', '8', '888', '18:34', '250.00', '0', '2018-07-24', '2018-07-24', 0),
(5, 5, 'O_5', 2, 4, 2, 'Reyo', 'Remo', '250', '500', '00:05', '250.00', '5050', '2018-07-24', '2018-07-24', 0),
(6, 6, 'O_5', 2, 4, 2, 'Das', 'Das', '100', '200', '00:05', '250.00', '2050', '2018-07-24', '2018-07-24', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_model`
--

CREATE TABLE `tbl_model` (
  `id` int(11) NOT NULL,
  `model_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `org_id` varchar(10) NOT NULL,
  `model_name` varchar(200) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_model`
--

INSERT INTO `tbl_model` (`id`, `model_id`, `brand_id`, `org_id`, `model_name`, `created_date`, `modified_date`, `status`) VALUES
(1, 1, 1, 'O_1', 'xuv', '2018-07-19', '2018-07-19', 0),
(2, 2, 4, 'O_5', 'Activa', '2018-07-24', '2018-07-24', 0),
(3, 3, 3, 'O_4', 'glamour', '2018-07-24', '2018-07-24', 0),
(4, 4, 2, 'O_4', 'test', '2018-07-24', '2018-07-24', 0),
(5, 5, 2, 'O_4', 'tets1', '2018-07-26', '2018-07-26', 0),
(6, 6, 5, 'O_1', '123', '2018-07-31', '2018-07-31', 0),
(7, 7, 7, 'O_6', 'kwid', '2018-08-02', '2018-08-02', 0),
(8, 8, 6, 'O_6', 'xuv', '2018-08-02', '2018-08-02', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_opening_balance`
--

CREATE TABLE `tbl_opening_balance` (
  `id` int(11) NOT NULL,
  `openbalance_id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `merchant` int(11) NOT NULL,
  `date` date NOT NULL,
  `openingbalance` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(11) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `merchant_id` int(11) NOT NULL,
  `employee_id` varchar(11) NOT NULL,
  `tax_type` int(11) NOT NULL,
  `total_amount` decimal(13,2) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_details`
--

CREATE TABLE `tbl_order_details` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `order_details_id` int(11) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `item_id` int(11) NOT NULL,
  `qty` decimal(13,2) NOT NULL,
  `rate` decimal(13,2) NOT NULL,
  `rateinctax` decimal(13,2) NOT NULL,
  `total` decimal(13,2) NOT NULL,
  `discount_per` decimal(13,2) NOT NULL,
  `discount_amt` decimal(13,2) NOT NULL,
  `taxpay` decimal(13,2) NOT NULL,
  `cgst_rate` decimal(13,2) NOT NULL,
  `cgst_amt` decimal(13,2) NOT NULL,
  `sgst_rate` decimal(13,2) NOT NULL,
  `sgst_amt` decimal(13,2) NOT NULL,
  `igst_rate` decimal(13,2) NOT NULL,
  `igst_amt` decimal(13,2) NOT NULL,
  `net_amt` decimal(13,2) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_tax_details`
--

CREATE TABLE `tbl_order_tax_details` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `order_tax_details_id` int(11) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `item_id` int(11) NOT NULL,
  `tax_id` int(11) NOT NULL,
  `tax_property_id` int(11) NOT NULL,
  `tax_percentage` decimal(13,2) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_organisation`
--

CREATE TABLE `tbl_organisation` (
  `org_id` int(11) NOT NULL,
  `org_maxid` int(50) NOT NULL,
  `o_maxid` varchar(11) NOT NULL,
  `org_logo` varchar(100) NOT NULL,
  `org_name` varchar(50) NOT NULL,
  `org_phone` varchar(15) NOT NULL,
  `org_mobile` varchar(15) NOT NULL,
  `org_fax` varchar(50) NOT NULL,
  `org_mail` varchar(50) NOT NULL,
  `password` varchar(25) NOT NULL,
  `org_usrgrp` varchar(50) NOT NULL,
  `org_authperson` varchar(100) NOT NULL,
  `permission` varchar(500) NOT NULL,
  `user_limit` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_organisation`
--

INSERT INTO `tbl_organisation` (`org_id`, `org_maxid`, `o_maxid`, `org_logo`, `org_name`, `org_phone`, `org_mobile`, `org_fax`, `org_mail`, `password`, `org_usrgrp`, `org_authperson`, `permission`, `user_limit`, `status`, `created_date`, `modified_date`) VALUES
(1, 1, 'O_1', 'uploads/ddd2.png', 'cafe', '04762642481', '3', '04762642481', 'info.cafe@gmail.com', '123', '', '15', '1,2,3,4,5,6,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28', 2, 0, '2021-05-12', '2021-05-12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment_details`
--

CREATE TABLE `tbl_payment_details` (
  `id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `employee_id` varchar(100) NOT NULL,
  `merchant_id` int(11) NOT NULL,
  `invoice_id` varchar(100) NOT NULL,
  `payment_mode` int(11) NOT NULL,
  `payment_type` int(11) DEFAULT NULL,
  `cheque_num` varchar(100) DEFAULT NULL,
  `cheque_bank` varchar(200) DEFAULT NULL,
  `cheque_date` date DEFAULT NULL,
  `p_amount` decimal(13,2) DEFAULT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `p_id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `barcode_num` varchar(100) DEFAULT NULL,
  `p_type` varchar(50) DEFAULT NULL,
  `mrp` decimal(13,2) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `subcat_id` varchar(11) DEFAULT NULL,
  `p_hsncode` varchar(100) DEFAULT NULL,
  `product_name` varchar(50) NOT NULL,
  `amount` varchar(40) DEFAULT NULL,
  `manufacturer` varchar(100) DEFAULT NULL,
  `qtyonhand` int(11) DEFAULT NULL,
  `p_measurement` varchar(11) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `rack` varchar(30) DEFAULT NULL,
  `reorder_lvl` varchar(20) DEFAULT NULL,
  `product_tax` varchar(15) DEFAULT NULL,
  `p_discount` varchar(11) DEFAULT NULL,
  `p_netamount` varchar(20) DEFAULT NULL,
  `negative_stock` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL,
  `pur_amount` decimal(13,2) DEFAULT NULL,
  `banum` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_tax`
--

CREATE TABLE `tbl_product_tax` (
  `txp_id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `txp_uid` int(11) NOT NULL,
  `txp_p_id` int(11) NOT NULL,
  `txp_tax_type` varchar(100) NOT NULL,
  `txp_property` int(100) NOT NULL,
  `txp_percentage` decimal(13,2) NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `modifed_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_type`
--

CREATE TABLE `tbl_product_type` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `pro_type_id` int(11) NOT NULL,
  `pro_type_name` varchar(100) NOT NULL,
  `pro_type_percentage` varchar(10) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product_type`
--

INSERT INTO `tbl_product_type` (`id`, `org_id`, `pro_type_id`, `pro_type_name`, `pro_type_percentage`, `created_date`, `modified_date`, `status`) VALUES
(1, 'O_1 ', 1, 'GST-18%', '18', '2021-04-26', '2021-04-26', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_registerreturns`
--

CREATE TABLE `tbl_registerreturns` (
  `id` int(11) NOT NULL,
  `org_id` varchar(50) NOT NULL,
  `ret_id` int(11) NOT NULL,
  `item_id` varchar(25) NOT NULL,
  `itemname` varchar(100) NOT NULL,
  `ret_date` varchar(25) NOT NULL,
  `expirydate` varchar(25) NOT NULL,
  `storage_fac` int(11) NOT NULL,
  `retunqty` int(11) NOT NULL,
  `crea_date` date NOT NULL,
  `mod_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_registerreturns`
--

INSERT INTO `tbl_registerreturns` (`id`, `org_id`, `ret_id`, `item_id`, `itemname`, `ret_date`, `expirydate`, `storage_fac`, `retunqty`, `crea_date`, `mod_date`, `status`) VALUES
(1, 'O_1 ', 1, 'ASDER5255', 'Arun Icecreams', '05/31/2021', '05/26/2021', 3, 0, '2021-05-11', '2021-05-11', 0),
(2, 'O_1 ', 2, 'ASDER5255', 'Arun Icecreams', '05/19/2021', '05/12/2021', 1, 0, '2021-05-11', '2021-05-11', 1),
(3, 'O_1 ', 3, 'SAD250', 'Arun Icecreams', '05/26/2021', '05/25/2021', 2, 0, '2021-05-11', '2021-05-11', 1),
(4, 'O_1 ', 4, 'SAD250', 'Meriboi Ice Creams', '05/26/2021', '05/21/2021', 2, 10, '2021-05-12', '2021-05-12', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_routehistory`
--

CREATE TABLE `tbl_routehistory` (
  `routehistory_id` int(11) NOT NULL,
  `latitude` varchar(20) NOT NULL,
  `longitude` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `created_time` time NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sales`
--

CREATE TABLE `tbl_sales` (
  `id` int(11) NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `merchant_id` int(11) NOT NULL,
  `employee_id` varchar(100) NOT NULL,
  `tax_type` int(11) NOT NULL,
  `total_amount` decimal(13,2) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_salesmanprocat`
--

CREATE TABLE `tbl_salesmanprocat` (
  `id` int(11) NOT NULL,
  `salesmanprocat_id` int(11) NOT NULL,
  `salesman_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_salesmanproduct`
--

CREATE TABLE `tbl_salesmanproduct` (
  `id` int(11) NOT NULL,
  `salesman_product_id` int(11) NOT NULL,
  `salesman_id` int(11) NOT NULL,
  `salesman_product` varchar(50) NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_salesmanreg`
--

CREATE TABLE `tbl_salesmanreg` (
  `id` int(11) NOT NULL,
  `salesmanid` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `head` varchar(100) NOT NULL,
  `phoneno` varchar(20) NOT NULL,
  `empcode` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `emp_father_name` varchar(100) NOT NULL,
  `emp_education` varchar(100) NOT NULL,
  `emp_qualification` varchar(100) NOT NULL,
  `emp_experience` varchar(200) NOT NULL,
  `nationality` varchar(100) NOT NULL,
  `family_status` varchar(20) NOT NULL,
  `family_type` varchar(20) NOT NULL,
  `family_dependence_details` varchar(100) NOT NULL,
  `date_of_birth` date NOT NULL,
  `date_of_joining` date NOT NULL,
  `pf_uan_no` varchar(50) NOT NULL,
  `esi_no` varchar(50) NOT NULL,
  `attendance_tracker` varchar(10) NOT NULL,
  `emp_email` varchar(100) NOT NULL,
  `usergroup` int(11) NOT NULL,
  `bloodgroup` varchar(50) NOT NULL,
  `starttime` varchar(25) NOT NULL,
  `endtime` varchar(25) NOT NULL,
  `password` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  `biodata` varchar(100) NOT NULL,
  `emp_user_limit` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_salesproduct`
--

CREATE TABLE `tbl_salesproduct` (
  `id` int(11) NOT NULL,
  `salesproduct_id` int(11) NOT NULL,
  `salesman_id` int(11) NOT NULL,
  `merchant_id` int(11) NOT NULL,
  `area_id` int(11) NOT NULL,
  `terminal` varchar(30) NOT NULL,
  `product_id` int(11) NOT NULL,
  `proamount` varchar(40) NOT NULL,
  `numofitem` int(11) NOT NULL,
  `totalamount` varchar(40) NOT NULL,
  `mode` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `chequeno` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `bank` varchar(40) NOT NULL,
  `branch` varchar(50) NOT NULL,
  `create_time` time NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sales_details`
--

CREATE TABLE `tbl_sales_details` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `salesdetails_id` int(11) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `item_id` int(11) NOT NULL,
  `qty` decimal(13,2) NOT NULL,
  `rate` decimal(13,2) NOT NULL,
  `rateinctax` decimal(13,2) NOT NULL,
  `total` decimal(13,2) NOT NULL,
  `discount_per` decimal(13,2) NOT NULL,
  `discount_amt` decimal(13,2) NOT NULL,
  `taxpay` decimal(13,2) NOT NULL,
  `cgst_rate` decimal(13,2) NOT NULL,
  `cgst_amt` decimal(13,2) NOT NULL,
  `sgst_rate` decimal(13,2) NOT NULL,
  `sgst_amt` decimal(13,2) NOT NULL,
  `igst_rate` decimal(13,2) NOT NULL,
  `igst_amt` decimal(13,2) NOT NULL,
  `net_amt` decimal(13,2) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_service`
--

CREATE TABLE `tbl_service` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `emp_id` varchar(100) NOT NULL,
  `ser_id` int(11) NOT NULL,
  `complaint_no` varchar(100) NOT NULL,
  `ser_name` varchar(50) NOT NULL,
  `ser_address` varchar(200) NOT NULL,
  `ser_product` varchar(200) NOT NULL,
  `yr_of_manu` date NOT NULL,
  `ser_warranty` varchar(20) NOT NULL,
  `ser_delivery_date` date NOT NULL,
  `ser_complaints` varchar(200) NOT NULL,
  `ser_mobile` varchar(15) NOT NULL,
  `ser_alternative` varchar(15) NOT NULL,
  `ser_email` varchar(100) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_servicereg`
--

CREATE TABLE `tbl_servicereg` (
  `id` int(11) NOT NULL,
  `servicereg_id` int(11) NOT NULL,
  `org_id` varchar(20) NOT NULL,
  `regid` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `address` varchar(100) NOT NULL,
  `telno` varchar(10) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_on` date NOT NULL,
  `modified_on` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_servicereg`
--

INSERT INTO `tbl_servicereg` (`id`, `servicereg_id`, `org_id`, `regid`, `name`, `address`, `telno`, `mobile`, `email`, `created_on`, `modified_on`, `status`) VALUES
(2, 113, 'O_1', 'te9009346756', 'test', 'Ernakulam\r\nErnakulam\r\nErnakulam', '', '8943043767', 'aabharaj@gmail.com', '2018-07-20', '2018-07-20', 0),
(3, 119, 'O_5', 'Sw9995555450', 'Swathi', 'Kollam', '0474265248', '9995555450', 'swathi123@gmail.com', '2018-07-24', '2018-07-24', 0),
(4, 114, 'O_1', 'an9995555473', 'Rajeev', 'Kollam', '0476264248', '9995555473', 'aneeshpournami92@gmail.com', '2018-07-30', '2018-07-30', 0),
(5, 114, 'O_1', 'an9995555403', 'Rajeev', 'Kollam', '047626481', '9995555403', 'aneeshpournami92@gmail.com', '2018-07-30', '2018-07-30', 0),
(13, 129, 'O_6', 'ch7736342051', 'chikku', 'sdds', '3456789', '7736342051', 'kfkfk@gmail.com', '2018-08-02', '2018-08-02', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_servicereturn`
--

CREATE TABLE `tbl_servicereturn` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `emp_id` varchar(100) NOT NULL,
  `servicereturn_id` int(11) NOT NULL,
  `complaint_id` varchar(100) NOT NULL,
  `item_status` int(11) NOT NULL,
  `s_tax_type` int(11) NOT NULL,
  `s_net_total` decimal(13,2) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_servicereturn_details`
--

CREATE TABLE `tbl_servicereturn_details` (
  `sreturn_details_id` int(11) NOT NULL,
  `sreturn_id` int(11) NOT NULL,
  `part_id` int(11) NOT NULL,
  `part_amnt` decimal(13,2) NOT NULL,
  `p_cgst` decimal(13,2) DEFAULT NULL,
  `p_sgst` decimal(13,2) DEFAULT NULL,
  `p_igst` decimal(13,2) DEFAULT NULL,
  `p_totamt` decimal(13,2) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_services_amenity`
--

CREATE TABLE `tbl_services_amenity` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `se_id` int(11) NOT NULL,
  `am_label` varchar(30) NOT NULL,
  `am_det` varchar(30) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_services_amenity`
--

INSERT INTO `tbl_services_amenity` (`id`, `org_id`, `se_id`, `am_label`, `am_det`, `created_date`, `modified_date`, `status`) VALUES
(1, 'O_1', 1, 'test1', 'tst', '2018-07-19', '2018-07-19', 0),
(2, 'O_1', 1, 'test12', 'tst1', '2018-07-19', '2018-07-19', 0),
(10, 'O_6', 2, 'item1', '1', '2018-08-02', '2018-08-02', 0),
(11, 'O_6', 2, 'item2', '', '2018-08-02', '2018-08-02', 0),
(12, 'O_6', 2, 'item3', '1', '2018-08-02', '2018-08-02', 0),
(13, 'O_6', 3, 'item1', 'ds', '2018-08-02', '2018-08-02', 0),
(14, 'O_6', 3, 'item2', 'dscf', '2018-08-02', '2018-08-02', 0),
(15, 'O_6', 3, 'item3', 'desw', '2018-08-02', '2018-08-02', 0),
(16, 'O_6', 4, 'item1', '1', '2018-08-02', '2018-08-02', 0),
(17, 'O_6', 4, 'item2', '1', '2018-08-02', '2018-08-02', 0),
(18, 'O_6', 4, 'item3', '1', '2018-08-02', '2018-08-02', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_services_details`
--

CREATE TABLE `tbl_services_details` (
  `id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `c_name` varchar(50) NOT NULL,
  `c_address` varchar(200) NOT NULL,
  `tele_o` varchar(20) DEFAULT NULL,
  `tele_r` varchar(20) DEFAULT NULL,
  `mob` varchar(20) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `s_details` text NOT NULL,
  `s_feedback` text NOT NULL,
  `time_in` varchar(15) NOT NULL,
  `team` varchar(50) NOT NULL,
  `delivary_date` varchar(15) NOT NULL,
  `delivary_time` varchar(15) NOT NULL,
  `amt` varchar(15) NOT NULL,
  `service_id` varchar(100) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_services_details`
--

INSERT INTO `tbl_services_details` (`id`, `s_id`, `org_id`, `c_name`, `c_address`, `tele_o`, `tele_r`, `mob`, `mail`, `s_details`, `s_feedback`, `time_in`, `team`, `delivary_date`, `delivary_time`, `amt`, `service_id`, `created_date`, `modified_date`, `status`) VALUES
(1, 1, 'O_1', 'mahesh', 'mahesh', '123456', '098765554', '987654367', 'mahesh@gmail.com', 'tst2', 'tst3', '12:10PM', 'sasi', '2018-07-04', '12:10PM', '10000', 'SER#1O_120180719122607', '2018-07-19', '2018-07-19', 0),
(5, 2, 'O_6', 'asd', 'ads', '1', '1', '1', 'binu@gmail.com', '1', '1', '05:18PM', 'ds', '2018-08-02', '05:18PM', '2323', 'SER#2O_620180802114916', '2018-08-02', '2018-08-02', 0),
(6, 3, 'O_6', 'gbdf', 'd', '', '', '95494', 'rdfeg@gmil.com', 'wdesf', 'dswfc', '05:20PM', 'sdf', '2018-08-02', '05:20PM', '342', 'SER#3O_620180802115102', '2018-08-02', '2018-08-02', 0),
(7, 4, 'O_6', 'sa', '1', '1', '1', '1', '1@gmi.klk', '1', '1', '05:25PM', 'sw', '2018-08-02', '05:23PM', '23', 'SER#4O_620180802115323', '2018-08-02', '2018-08-02', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_services_history`
--

CREATE TABLE `tbl_services_history` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `serv_id` int(11) NOT NULL,
  `history_date` varchar(30) DEFAULT NULL,
  `history_desc` text DEFAULT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_services_history`
--

INSERT INTO `tbl_services_history` (`id`, `org_id`, `serv_id`, `history_date`, `history_desc`, `created_date`, `modified_date`, `status`) VALUES
(1, 'O_1', 1, '2018-07-19', 'wer', '2018-07-19', '2018-07-19', 0),
(6, 'O_6', 2, '2018-08-02', 'ds', '2018-08-02', '2018-08-02', 0),
(7, 'O_6', 2, '2018-08-02', 'ds', '2018-08-02', '2018-08-02', 0),
(8, 'O_6', 3, '2018-08-02', 'sdf', '2018-08-02', '2018-08-02', 0),
(9, 'O_6', 4, '2018-08-02', 'sd', '2018-08-02', '2018-08-02', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_services_item`
--

CREATE TABLE `tbl_services_item` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `ser_id` int(11) NOT NULL,
  `item_label` varchar(30) NOT NULL,
  `item_det` varchar(30) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_services_item`
--

INSERT INTO `tbl_services_item` (`id`, `org_id`, `ser_id`, `item_label`, `item_det`, `created_date`, `modified_date`, `status`) VALUES
(1, 'O_1', 1, 'test22', 'tst5', '2018-07-19', '2018-07-19', 0),
(9, 'O_6', 2, 'amenity1', '1', '2018-08-02', '2018-08-02', 0),
(10, 'O_6', 2, 'amenity2', '1', '2018-08-02', '2018-08-02', 0),
(11, 'O_6', 2, 'amenity3', '1', '2018-08-02', '2018-08-02', 0),
(12, 'O_6', 3, 'amenity1', 'dfcsw', '2018-08-02', '2018-08-02', 0),
(13, 'O_6', 3, 'amenity2', 'dcfsw', '2018-08-02', '2018-08-02', 0),
(14, 'O_6', 3, 'amenity3', 'swcdf', '2018-08-02', '2018-08-02', 0),
(15, 'O_6', 4, 'amenity1', '1', '2018-08-02', '2018-08-02', 0),
(16, 'O_6', 4, 'amenity2', '1', '2018-08-02', '2018-08-02', 0),
(17, 'O_6', 4, 'amenity3', '11', '2018-08-02', '2018-08-02', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_services_job`
--

CREATE TABLE `tbl_services_job` (
  `id` int(11) NOT NULL,
  `servjob_id` int(11) NOT NULL,
  `org_id` varchar(50) NOT NULL,
  `ser_job` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_services_job`
--

INSERT INTO `tbl_services_job` (`id`, `servjob_id`, `org_id`, `ser_job`, `created_date`, `modified_date`, `status`) VALUES
(1, 1, 'O_1', 1, '2018-07-19', '2018-07-19', 0),
(8, 2, 'O_6', 4, '2018-08-02', '2018-08-02', 0),
(9, 3, 'O_6', 2, '2018-08-02', '2018-08-02', 0),
(10, 3, 'O_6', 3, '2018-08-02', '2018-08-02', 0),
(11, 3, 'O_6', 4, '2018-08-02', '2018-08-02', 0),
(12, 4, 'O_6', 2, '2018-08-02', '2018-08-02', 0),
(13, 4, 'O_6', 3, '2018-08-02', '2018-08-02', 0),
(14, 4, 'O_6', 4, '2018-08-02', '2018-08-02', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_service_amenity`
--

CREATE TABLE `tbl_service_amenity` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `amenity_id` int(11) NOT NULL,
  `amenity_title` varchar(50) NOT NULL,
  `Item_title` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_service_amenity`
--

INSERT INTO `tbl_service_amenity` (`id`, `org_id`, `amenity_id`, `amenity_title`, `Item_title`, `status`, `create_date`, `modify_date`) VALUES
(1, 'O_1', 1, 'test', 'test2', 0, '2018-07-19', '2018-07-19'),
(4, 'O_6', 2, 'item', 'amenity', 0, '2018-08-02', '2018-08-02');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_service_jobs`
--

CREATE TABLE `tbl_service_jobs` (
  `id` int(11) NOT NULL,
  `jobs_id` int(11) NOT NULL,
  `org_id` varchar(50) NOT NULL,
  `titles` text NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_service_jobs`
--

INSERT INTO `tbl_service_jobs` (`id`, `jobs_id`, `org_id`, `titles`, `create_date`, `modify_date`, `status`) VALUES
(2, 1, 'O_1', 'job1', '2018-08-02', '2018-08-02', 0),
(4, 2, 'O_6', 'job1', '2018-08-02', '2018-08-02', 0),
(5, 3, 'O_6', 'job2', '2018-08-02', '2018-08-02', 0),
(6, 4, 'O_6', 'job3', '2018-08-02', '2018-08-02', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_service_terms`
--

CREATE TABLE `tbl_service_terms` (
  `id` int(11) NOT NULL,
  `terms_id` int(11) NOT NULL,
  `org_id` varchar(50) NOT NULL,
  `titles` text NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shifts`
--

CREATE TABLE `tbl_shifts` (
  `id` int(11) NOT NULL,
  `org_id` varchar(50) NOT NULL,
  `shift_id` int(11) NOT NULL,
  `emp_name` varchar(100) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `date_from` varchar(25) NOT NULL,
  `date_to` varchar(25) NOT NULL,
  `time_from` int(11) NOT NULL,
  `time_to` int(11) NOT NULL,
  `crea_date` date NOT NULL,
  `mod_date` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_shifts`
--

INSERT INTO `tbl_shifts` (`id`, `org_id`, `shift_id`, `emp_name`, `emp_id`, `date_from`, `date_to`, `time_from`, `time_to`, `crea_date`, `mod_date`, `status`) VALUES
(1, 'O_1 ', 1, 'Asha', 'asha123', '05/13/2021', '05/13/2021', 11, 18, '2021-05-12', '2021-05-12', 0),
(2, 'O_1 ', 2, 'fdgfdg', 'sddsf', '05/17/2021', '05/22/2021', 10, 22, '2021-05-12', '2021-05-12', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sms`
--

CREATE TABLE `tbl_sms` (
  `id` int(11) NOT NULL,
  `org_id` varchar(30) NOT NULL,
  `sid` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `model_id` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `s_range` int(11) NOT NULL,
  `e_range` int(11) NOT NULL,
  `modified_on` date NOT NULL,
  `created_on` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_sms`
--

INSERT INTO `tbl_sms` (`id`, `org_id`, `sid`, `brand_id`, `model_id`, `category`, `s_range`, `e_range`, `modified_on`, `created_on`, `status`) VALUES
(1, 'O_1', 1, 1, 1, 'oil change', 200, 750, '2018-07-19', '2018-07-19', 0),
(2, 'O_1', 1, 1, 1, 'chain lubricantion', 500, 1000, '2018-07-19', '2018-07-19', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sms_orgsettings`
--

CREATE TABLE `tbl_sms_orgsettings` (
  `id` int(11) NOT NULL,
  `max_id` int(11) NOT NULL,
  `org_id` varchar(30) NOT NULL,
  `smscount` varchar(20) NOT NULL,
  `modified_on` date NOT NULL,
  `created_on` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_sms_orgsettings`
--

INSERT INTO `tbl_sms_orgsettings` (`id`, `max_id`, `org_id`, `smscount`, `modified_on`, `created_on`, `status`) VALUES
(1, 1, 'O_1', '13', '2018-07-19', '2018-07-19', 0),
(2, 2, 'O_5', '2499', '2018-07-24', '2018-07-24', 0),
(3, 3, 'O_6', '10', '2018-08-02', '2018-08-02', 0),
(4, 4, 'O_7', '0', '2018-08-02', '2018-08-02', 0),
(5, 5, 'O_8', '0', '2018-09-06', '2018-09-06', 0),
(6, 6, 'O_9', '0', '2018-10-08', '2018-10-08', 0),
(7, 7, 'O_10', '0', '2021-04-23', '2021-04-23', 0),
(8, 8, 'O_10', '0', '2021-04-23', '2021-04-23', 0),
(9, 9, 'O_11', '0', '2021-04-23', '2021-04-23', 0),
(10, 10, 'O_12', '0', '2021-04-23', '2021-04-23', 0),
(11, 11, 'O_13', '0', '2021-04-23', '2021-04-23', 0),
(12, 12, 'O_14', '0', '2021-04-23', '2021-04-23', 0),
(13, 13, 'O_15', '0', '2021-04-23', '2021-04-23', 0),
(14, 14, 'O_16', '0', '2021-04-27', '2021-04-27', 0),
(15, 15, 'O_17', '0', '2021-05-04', '2021-05-04', 0),
(16, 16, 'O_18', '0', '2021-05-12', '2021-05-12', 0),
(17, 17, 'O_1', '0', '2021-05-12', '2021-05-12', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_storage`
--

CREATE TABLE `tbl_storage` (
  `id` int(11) NOT NULL,
  `storage_id` int(11) NOT NULL,
  `org_id` varchar(110) NOT NULL,
  `storage_name` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_storage`
--

INSERT INTO `tbl_storage` (`id`, `storage_id`, `org_id`, `storage_name`, `status`, `created_date`, `modified_date`) VALUES
(9, 1, 'O_1 ', 'Storage A', 0, '2021-05-11', '2021-05-11'),
(10, 2, 'O_1 ', 'Storage B', 0, '2021-05-11', '2021-05-11'),
(11, 3, 'O_1 ', 'Storage C', 0, '2021-05-11', '2021-05-11'),
(12, 4, 'O_1 ', 'Storage D', 0, '2021-05-11', '2021-05-11');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subcategory`
--

CREATE TABLE `tbl_subcategory` (
  `sub_id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  `subcat_name` varchar(50) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_subcategory`
--

INSERT INTO `tbl_subcategory` (`sub_id`, `org_id`, `subcategory_id`, `subcat_name`, `cat_id`, `status`, `create_date`, `modify_date`) VALUES
(1, 'O_1', 1, 'fgfg', 1, 0, '2018-12-01', '2018-12-01'),
(2, 'O_1 ', 2, 'Single Pack', 2, 0, '2021-04-26', '2021-04-26'),
(3, 'O_1 ', 3, 'Medium Pack', 2, 0, '2021-04-26', '2021-04-26'),
(4, 'O_1 ', 4, '100 Gm', 3, 0, '2021-04-26', '2021-04-26');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_submenu`
--

CREATE TABLE `tbl_submenu` (
  `submenu_id` int(11) NOT NULL,
  `mainmenu_id` int(11) NOT NULL,
  `submenu_name` varchar(50) NOT NULL,
  `submenu_icon` varchar(100) NOT NULL,
  `submenu_path` varchar(200) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_s_amenity`
--

CREATE TABLE `tbl_s_amenity` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `am_id` int(11) NOT NULL,
  `titles` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_s_amenity`
--

INSERT INTO `tbl_s_amenity` (`id`, `org_id`, `am_id`, `titles`, `status`, `create_date`, `modify_date`) VALUES
(1, 'O_1', 1, 'test1', 0, '2018-07-19', '2018-07-19'),
(2, 'O_1', 1, 'test12', 0, '2018-07-19', '2018-07-19'),
(6, 'O_6', 2, 'item1', 0, '2018-08-02', '2018-08-02'),
(7, 'O_6', 2, 'item2', 0, '2018-08-02', '2018-08-02'),
(8, 'O_6', 2, 'item3', 0, '2018-08-02', '2018-08-02');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_s_items`
--

CREATE TABLE `tbl_s_items` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `it_id` int(11) NOT NULL,
  `titles` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_s_items`
--

INSERT INTO `tbl_s_items` (`id`, `org_id`, `it_id`, `titles`, `status`, `create_date`, `modify_date`) VALUES
(1, 'O_1', 1, 'test22', 0, '2018-07-19', '2018-07-19'),
(5, 'O_6', 2, 'amenity1', 0, '2018-08-02', '2018-08-02'),
(6, 'O_6', 2, 'amenity2', 0, '2018-08-02', '2018-08-02'),
(7, 'O_6', 2, 'amenity3', 0, '2018-08-02', '2018-08-02');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tax`
--

CREATE TABLE `tbl_tax` (
  `tax_id` int(11) NOT NULL COMMENT 'A_I table id for product tax details',
  `org_id` varchar(100) NOT NULL,
  `tax_product_id` int(11) NOT NULL COMMENT 'Id of Tax',
  `tax_name` varchar(50) NOT NULL COMMENT 'Type of Tax - Name',
  `tax_create_date` date NOT NULL COMMENT 'date of product tax created date',
  `tax_modify_date` date NOT NULL COMMENT 'date of product tax modify date',
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Table for storing the Tax details of each Products';

-- --------------------------------------------------------

--
-- Table structure for table `tbl_taxpropery`
--

CREATE TABLE `tbl_taxpropery` (
  `ptax_id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `ptax_u_id` int(11) NOT NULL,
  `ptax_taxid` int(11) NOT NULL,
  `ptax_propery` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `modify_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_terminal`
--

CREATE TABLE `tbl_terminal` (
  `id` int(11) NOT NULL,
  `terminalid` int(11) NOT NULL,
  `merchantid_num` varchar(20) NOT NULL,
  `terminalid_num` varchar(20) NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_usergroup`
--

CREATE TABLE `tbl_usergroup` (
  `id` int(11) NOT NULL,
  `org_id` varchar(100) NOT NULL,
  `usergroup_id` int(20) NOT NULL,
  `usergroup_name` varchar(50) NOT NULL,
  `permission` varchar(500) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vehicledetails`
--

CREATE TABLE `tbl_vehicledetails` (
  `id` int(11) NOT NULL,
  `vehicleid` int(11) NOT NULL,
  `servicereg_id` int(11) NOT NULL,
  `brandname` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `engineno` varchar(30) NOT NULL,
  `chaiseno` varchar(30) NOT NULL,
  `regno` varchar(30) NOT NULL,
  `insurancedudate` date NOT NULL,
  `motorvehicletest` date NOT NULL,
  `pollutiontest` date NOT NULL,
  `color` varchar(20) NOT NULL,
  `modified_on` date NOT NULL,
  `created_on` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_vehicledetails`
--

INSERT INTO `tbl_vehicledetails` (`id`, `vehicleid`, `servicereg_id`, `brandname`, `model`, `engineno`, `chaiseno`, `regno`, `insurancedudate`, `motorvehicletest`, `pollutiontest`, `color`, `modified_on`, `created_on`, `status`) VALUES
(8, 1, 127, '1', '1', '2323', '2323', '2323', '2018-07-31', '2018-07-30', '2018-07-31', 'blue', '2018-07-31', '2018-07-31', 0),
(9, 2, 127, '5', '6', '44', '4', '34534fgdfg', '2018-07-10', '2018-07-10', '2018-07-31', 'blue', '2018-07-31', '2018-07-31', 0),
(10, 3, 129, '7', '7', '285859', '656869', '258246', '2018-08-07', '2018-08-06', '2018-08-05', 'red', '2018-08-02', '2018-08-02', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_additional_part`
--
ALTER TABLE `tbl_additional_part`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_advertisement`
--
ALTER TABLE `tbl_advertisement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_area`
--
ALTER TABLE `tbl_area`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_attendance`
--
ALTER TABLE `tbl_attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_authreg`
--
ALTER TABLE `tbl_authreg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_bank`
--
ALTER TABLE `tbl_bank`
  ADD PRIMARY KEY (`b_tid`);

--
-- Indexes for table `tbl_bin`
--
ALTER TABLE `tbl_bin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cashcollect`
--
ALTER TABLE `tbl_cashcollect`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `tbl_credit_details`
--
ALTER TABLE `tbl_credit_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_currentlocation`
--
ALTER TABLE `tbl_currentlocation`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `tbl_designation`
--
ALTER TABLE `tbl_designation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_driverdetails`
--
ALTER TABLE `tbl_driverdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_education`
--
ALTER TABLE `tbl_education`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_emparea`
--
ALTER TABLE `tbl_emparea`
  ADD PRIMARY KEY (`slno`);

--
-- Indexes for table `tbl_empverification`
--
ALTER TABLE `tbl_empverification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_emp_education`
--
ALTER TABLE `tbl_emp_education`
  ADD PRIMARY KEY (`emp_edu_id`);

--
-- Indexes for table `tbl_enquiry`
--
ALTER TABLE `tbl_enquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_enquiry_status`
--
ALTER TABLE `tbl_enquiry_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_fare_settings`
--
ALTER TABLE `tbl_fare_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_hsn`
--
ALTER TABLE `tbl_hsn`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_manufacture`
--
ALTER TABLE `tbl_manufacture`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_measurement`
--
ALTER TABLE `tbl_measurement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `tbl_merchant`
--
ALTER TABLE `tbl_merchant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_merchantcategory`
--
ALTER TABLE `tbl_merchantcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_merchantprocat`
--
ALTER TABLE `tbl_merchantprocat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_merchantproduct`
--
ALTER TABLE `tbl_merchantproduct`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_mincharge`
--
ALTER TABLE `tbl_mincharge`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_model`
--
ALTER TABLE `tbl_model`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_opening_balance`
--
ALTER TABLE `tbl_opening_balance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order_tax_details`
--
ALTER TABLE `tbl_order_tax_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_organisation`
--
ALTER TABLE `tbl_organisation`
  ADD PRIMARY KEY (`org_id`);

--
-- Indexes for table `tbl_payment_details`
--
ALTER TABLE `tbl_payment_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `tbl_product_tax`
--
ALTER TABLE `tbl_product_tax`
  ADD PRIMARY KEY (`txp_id`);

--
-- Indexes for table `tbl_product_type`
--
ALTER TABLE `tbl_product_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_registerreturns`
--
ALTER TABLE `tbl_registerreturns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_routehistory`
--
ALTER TABLE `tbl_routehistory`
  ADD PRIMARY KEY (`routehistory_id`);

--
-- Indexes for table `tbl_sales`
--
ALTER TABLE `tbl_sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_salesmanprocat`
--
ALTER TABLE `tbl_salesmanprocat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_salesmanproduct`
--
ALTER TABLE `tbl_salesmanproduct`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_salesmanreg`
--
ALTER TABLE `tbl_salesmanreg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_salesproduct`
--
ALTER TABLE `tbl_salesproduct`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_sales_details`
--
ALTER TABLE `tbl_sales_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_service`
--
ALTER TABLE `tbl_service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_servicereg`
--
ALTER TABLE `tbl_servicereg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_servicereturn`
--
ALTER TABLE `tbl_servicereturn`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_servicereturn_details`
--
ALTER TABLE `tbl_servicereturn_details`
  ADD PRIMARY KEY (`sreturn_details_id`);

--
-- Indexes for table `tbl_services_amenity`
--
ALTER TABLE `tbl_services_amenity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_services_details`
--
ALTER TABLE `tbl_services_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_services_history`
--
ALTER TABLE `tbl_services_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_services_item`
--
ALTER TABLE `tbl_services_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_services_job`
--
ALTER TABLE `tbl_services_job`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_service_amenity`
--
ALTER TABLE `tbl_service_amenity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_service_jobs`
--
ALTER TABLE `tbl_service_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_service_terms`
--
ALTER TABLE `tbl_service_terms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_shifts`
--
ALTER TABLE `tbl_shifts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_sms`
--
ALTER TABLE `tbl_sms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_sms_orgsettings`
--
ALTER TABLE `tbl_sms_orgsettings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_storage`
--
ALTER TABLE `tbl_storage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_subcategory`
--
ALTER TABLE `tbl_subcategory`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `tbl_submenu`
--
ALTER TABLE `tbl_submenu`
  ADD PRIMARY KEY (`submenu_id`);

--
-- Indexes for table `tbl_s_amenity`
--
ALTER TABLE `tbl_s_amenity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_s_items`
--
ALTER TABLE `tbl_s_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_tax`
--
ALTER TABLE `tbl_tax`
  ADD PRIMARY KEY (`tax_id`);

--
-- Indexes for table `tbl_taxpropery`
--
ALTER TABLE `tbl_taxpropery`
  ADD PRIMARY KEY (`ptax_id`);

--
-- Indexes for table `tbl_terminal`
--
ALTER TABLE `tbl_terminal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_usergroup`
--
ALTER TABLE `tbl_usergroup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_vehicledetails`
--
ALTER TABLE `tbl_vehicledetails`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_additional_part`
--
ALTER TABLE `tbl_additional_part`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_advertisement`
--
ALTER TABLE `tbl_advertisement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_area`
--
ALTER TABLE `tbl_area`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_attendance`
--
ALTER TABLE `tbl_attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_authreg`
--
ALTER TABLE `tbl_authreg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_bank`
--
ALTER TABLE `tbl_bank`
  MODIFY `b_tid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_bin`
--
ALTER TABLE `tbl_bin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_cashcollect`
--
ALTER TABLE `tbl_cashcollect`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_credit_details`
--
ALTER TABLE `tbl_credit_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_currentlocation`
--
ALTER TABLE `tbl_currentlocation`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_designation`
--
ALTER TABLE `tbl_designation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_driverdetails`
--
ALTER TABLE `tbl_driverdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_education`
--
ALTER TABLE `tbl_education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_emparea`
--
ALTER TABLE `tbl_emparea`
  MODIFY `slno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_empverification`
--
ALTER TABLE `tbl_empverification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_emp_education`
--
ALTER TABLE `tbl_emp_education`
  MODIFY `emp_edu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_enquiry`
--
ALTER TABLE `tbl_enquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_enquiry_status`
--
ALTER TABLE `tbl_enquiry_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_fare_settings`
--
ALTER TABLE `tbl_fare_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_hsn`
--
ALTER TABLE `tbl_hsn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_login`
--
ALTER TABLE `tbl_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;

--
-- AUTO_INCREMENT for table `tbl_manufacture`
--
ALTER TABLE `tbl_manufacture`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_measurement`
--
ALTER TABLE `tbl_measurement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  MODIFY `menu_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_merchant`
--
ALTER TABLE `tbl_merchant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_merchantcategory`
--
ALTER TABLE `tbl_merchantcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_merchantprocat`
--
ALTER TABLE `tbl_merchantprocat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_merchantproduct`
--
ALTER TABLE `tbl_merchantproduct`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_mincharge`
--
ALTER TABLE `tbl_mincharge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_model`
--
ALTER TABLE `tbl_model`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_opening_balance`
--
ALTER TABLE `tbl_opening_balance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_order_tax_details`
--
ALTER TABLE `tbl_order_tax_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_organisation`
--
ALTER TABLE `tbl_organisation`
  MODIFY `org_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_payment_details`
--
ALTER TABLE `tbl_payment_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_product_tax`
--
ALTER TABLE `tbl_product_tax`
  MODIFY `txp_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_product_type`
--
ALTER TABLE `tbl_product_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_registerreturns`
--
ALTER TABLE `tbl_registerreturns`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_routehistory`
--
ALTER TABLE `tbl_routehistory`
  MODIFY `routehistory_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_sales`
--
ALTER TABLE `tbl_sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_salesmanprocat`
--
ALTER TABLE `tbl_salesmanprocat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_salesmanproduct`
--
ALTER TABLE `tbl_salesmanproduct`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_salesmanreg`
--
ALTER TABLE `tbl_salesmanreg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_salesproduct`
--
ALTER TABLE `tbl_salesproduct`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_sales_details`
--
ALTER TABLE `tbl_sales_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_service`
--
ALTER TABLE `tbl_service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_servicereg`
--
ALTER TABLE `tbl_servicereg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_servicereturn`
--
ALTER TABLE `tbl_servicereturn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_servicereturn_details`
--
ALTER TABLE `tbl_servicereturn_details`
  MODIFY `sreturn_details_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_services_amenity`
--
ALTER TABLE `tbl_services_amenity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_services_details`
--
ALTER TABLE `tbl_services_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_services_history`
--
ALTER TABLE `tbl_services_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_services_item`
--
ALTER TABLE `tbl_services_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_services_job`
--
ALTER TABLE `tbl_services_job`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_service_amenity`
--
ALTER TABLE `tbl_service_amenity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_service_jobs`
--
ALTER TABLE `tbl_service_jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_service_terms`
--
ALTER TABLE `tbl_service_terms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_shifts`
--
ALTER TABLE `tbl_shifts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_sms`
--
ALTER TABLE `tbl_sms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_sms_orgsettings`
--
ALTER TABLE `tbl_sms_orgsettings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_storage`
--
ALTER TABLE `tbl_storage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_subcategory`
--
ALTER TABLE `tbl_subcategory`
  MODIFY `sub_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_submenu`
--
ALTER TABLE `tbl_submenu`
  MODIFY `submenu_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_s_amenity`
--
ALTER TABLE `tbl_s_amenity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_s_items`
--
ALTER TABLE `tbl_s_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_tax`
--
ALTER TABLE `tbl_tax`
  MODIFY `tax_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'A_I table id for product tax details';

--
-- AUTO_INCREMENT for table `tbl_taxpropery`
--
ALTER TABLE `tbl_taxpropery`
  MODIFY `ptax_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_terminal`
--
ALTER TABLE `tbl_terminal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_usergroup`
--
ALTER TABLE `tbl_usergroup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_vehicledetails`
--
ALTER TABLE `tbl_vehicledetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
