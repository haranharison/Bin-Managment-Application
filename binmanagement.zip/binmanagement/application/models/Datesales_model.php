<?php
class Datesales_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	
	/*public function addsalesreport(){
		
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('salesmanid')->result();

		
		}*/
	public function getsalesman(){
		
	 $from=$this->input->post('txtfromdate');
	 $to=$this->input->post('txttodate');
     
	 $orgid=$this->session->userdata('org_id');
	 
	 $array=array('tbl_sales.status'=>0,'tbl_sales.org_id'=>$orgid,'tbl_sales.created_date >='=>$from,'tbl_sales.created_date <='=>$to);
		$this->db->where($array);
		//$this->db->select('*');
	   //$rows=$this->db->get('tbl_sales_details')->result();
	  
	   
	   
	   $this->db->select('tbl_sales.total_amount,tbl_sales.created_date,tbl_salesmanreg.name,tbl_merchant.merchantname');
	   $this->db->from('tbl_sales');
	   $this->db->join('tbl_merchant','tbl_merchant.merchant_id=tbl_sales.merchant_id');
	   $this->db->join('tbl_salesmanreg','tbl_salesmanreg.salesmanid=tbl_sales.employee_id');
	   $r=$this->db->get();	
	   
	   $result=$r->result();
	   $totamt=0;
	   $html='';
				if($r->num_rows() > 0)
				{
						//$html.='<td></td>';
						$i=1;
					foreach($result as $key)
					{	
						$totamt=$totamt+$key->total_amount;
					
						
						$html.='<tr><td>'.$i.'</td>';
						$html.='<td>'.$key->name.'</td>';
						$html.='<td>'.$key->merchantname.'</td>';
						
						$html.='<td>'.$key->total_amount.'</td>';
						$html.='<td>'.$key->created_date.'</td></tr>';
						
						$i=$i+1;
					}
					
					    $html.='<td></td>';
						$html.='<td></td>';
						$html.='<td style="font-weight:bold;">Total Amount</td>';
						$html.='<td>'.$totamt.'</td>';
					
				}else{
					$html.='<td>-- No result  --</td>';
						}
					$html.="<script> $('#datatable').dataTable( { pageLength: 10,
        dom: 'Bfrtip',
        buttons: ['csv', 'excel', 'pdf', 'print'],
        responsive: true} );</script>";	
						
			echo $html;
	   
	   
	      
	}

}