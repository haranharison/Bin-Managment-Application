<?php
class Marketing_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        
		public function getmarketing()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		$this->db->group_by('en_id');
		return $rows=$this->db->get('tbl_enquiry')->result();
		}
		
		
		public function getmainmarketing()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		$this->db->group_by('en_id');
		return $rows=$this->db->get('tbl_enquiry')->result();
		}
		
		public function addmarketing()
		{
		  $max=maxplus('tbl_enquiry','en_id');	
		    $today=date('Y-m-d');
			$data= array(
			'org_id'=>$this->session->userdata('org_id'),
			   'en_id' =>$max,
		       'merchant'=>$this->input->post('cname'),
			   'emp_id'=>$this->session->userdata('emp_id'),
			   'category'=>$this->input->post('category'),
			   'address'=>$this->input->post('address'),
			   'landno'=>$this->input->post('phone'),
			   'mobile'=>$this->input->post('mobile'),
			   'product_intro'=>$this->input->post('prdctintro'),
			   'any_addi_info'=>$this->input->post('anyinfo'),
			   'auth_person'=>$this->input->post('author'),
			   'en_date'=>$today,
			   'requirement'=>$this->input->post('require'),
			   'follow_date'=>$this->input->post('fdate'),
			   'feedback'=>$this->input->post('feedback'),
			   'mar_status'=>$this->input->post('status'),
			   'lat'=>$this->input->post('latitude'),
			   'long'=>$this->input->post('longitude'),
			   'status'=>0,
			   'crea_date'=>$today,
			   'mod_date'=>$today,
			);
			$this->db->insert('tbl_enquiry',$data);	
		}
		public function deleteMarketing(){
		   $cid=$this->input->post('id');
		   $mid=decode($cid);
		   $data=array('status'=>1);
		   $array= array('en_id'=>$mid);
		   $this->db->where($array);
		   $this->db->update('tbl_enquiry',$data);	
			
		}
		public function editmarketing($mid){ 
		    $id=$mid;
			$array=array('status'=>0,'en_id'=>$id);
			$this->db->where($array);
			$this->db->select('*');
       		$result=$this->db->get('tbl_enquiry');
       		return $rows=$result->result();
		}
		public function updatemarketing(){
		    $today=date('Y-m-d');
			$eid=$this->input->post('hdnid');
			$array= array('en_id'=>$eid);
			$data= array(
		       'merchant'=>$this->input->post('cname'),
			   'emp_id'=>$this->session->userdata('emp_id'),
			   'category'=>$this->input->post('category'),
			   'address'=>$this->input->post('address'),
			   'landno'=>$this->input->post('phone'),
			   'product_intro'=>$this->input->post('prdctintro'),
			   'any_addi_info'=>$this->input->post('anyinfo'),
			   'mobile'=>$this->input->post('mobile'),
			   'auth_person'=>$this->input->post('author'),
			   'en_date'=>$today,
			   'requirement'=>$this->input->post('require'),
			   'follow_date'=>$this->input->post('fdate'),
			   'feedback'=>$this->input->post('feedback'),
			   'mar_status'=>$this->input->post('status'),
			   'lat'=>$this->input->post('latitude'),
			   'long'=>$this->input->post('longitude'),
			   'status'=>0,
			   'crea_date'=>$today,
			   'mod_date'=>$today,
			);	
			$this->db->where($array);
		    $this->db->update('tbl_enquiry',$data);
		
		}
		public function insertnew(){
			$max=maxplus('tbl_enquiry_status','enquiry_status_id');	
		    $today=date('Y-m-d');
			$data= array(
			'org_id'=>$this->session->userdata('org_id'),
			   'enquiry_status_id' =>$max,
		       'status_name'=>$this->input->post('sname'),
			    'status'=>0,
			   'created_date'=>$today,
			   'modified_date'=>$today,
			   );
			   	$this->db->insert('tbl_enquiry_status',$data);
			}
			
			public function getnewstatus()
		{
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),);
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_enquiry_status');
				 $res= $rows->result();
				 $html='';
				 
				 if($rows->num_rows()>0){
					 
					 $html.='<select  id="status" name="status" style="display:block;" ><option value="0" >Select Status</option>';
					foreach($res as $val){
					 $html.='<option value="'.$val->enquiry_status_id.' ">'.$val->status_name.'</option>	';
					}
					$html.='</select>';
					 //$html.='</select><a class="addDynamicfield btnaddunit"><i class="material-icons">add_circle</i></a>';
					 }
					
					
						 
				echo $html;
		}
				public function getstatus()
		{
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_enquiry_status');
				return $res= $rows->result();
		}
		
		public function changevwstatus()
		{
			
		
		$enqid=decode($this->input->post('vid'));
		
		$array=array('status'=>0,'en_id'=>$enqid);
		$data=array('view_status'=>1);
		$this->db->where($array);
		
		$this->db->update('tbl_enquiry',$data);
		}
}