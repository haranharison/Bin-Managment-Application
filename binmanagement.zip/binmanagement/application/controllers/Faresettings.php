<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Faresettings extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
	$this->load->model('Faresettings_model','model');
	 }	
	 public function index()
	{
		$data['menu']='Fairsettings';
		$data['submenu']='Fairsettings';
		$data['fare']=$this->model->getallfare();
		$data['brands']=$this->model->getbrand();
		$this->load->view('admin/do_header',$data);
		$this->load->view('admin/fare_settings/add',$data);
		$this->load->view('admin/footer');
	}
	public function insert()
	{
		$this->model->insert();	
	}
	public function get_model()
	{
		$this->model->get_model();	
	}
	
	public function edit($id=false){
		$mid=decode($id);
		$data['menu']='Fairsettings';
		$data['submenu']='Fairsettings';
		
		$data['details']=$this->model->getdetails($mid);
		$data['fare']=$this->model->getallfare();
		$data['brands']=$this->model->getbrand();	
		$data['model']=$this->model->getallmodel();	
		$this->load->view('admin/do_header',$data);
		$this->load->view('admin/fare_settings/edit',$data);
		$this->load->view('admin/footer'); 
		}
		
			public function update(){
		$this->model->update();
	}
	
	public function delete()
	{
		$this->model->delete();	
	}

	/*
	
     
   */
	
}

