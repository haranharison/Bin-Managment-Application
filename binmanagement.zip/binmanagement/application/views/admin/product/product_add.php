<style>
  .addDynamicfield,.removeDynamicfield{
						    position: absolute;
							top: 16px;
							right: -10px;
							padding:0px;
							color: #0092d3;
							cursor:pointer;
							opacity:0.7;
							transition:opacity 0.2s;
							  -webkit-touch-callout: none; /* iOS Safari */
							-webkit-user-select: none; /* Safari */
							 -khtml-user-select: none; /* Konqueror HTML */
							   -moz-user-select: none; /* Firefox */
								-ms-user-select: none; /* Internet Explorer/Edge */
									user-select: none; /* Non-prefixed version, currently
														  supported by Chrome and Opera */
				  }
				   .addDynamicfield:hover,.removeDynamicfield:hover{
					   opacity:1;
				   }
				  .removeDynamicfield{
						color:#F30;  
				  }
                  .addDynamicfield i,.removeDynamicfield i{
					font-size: 22px;  
				  }
				  .removeDynamicfield i.removing{
					  animation:spin 2s linear infinite;
				  }
				  </style>
<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  <!-- Form with placeholder -->
                  <div class="col s12 m6 l6">
                <div class="card-panel">
				<h4 class="header2">Add Product</h4>
                  <div class="row">
                  <!--FORM PRODUCT ADD-->
                   <form role="form" action="" name="frmproduct" id="frmproduct">
                    <!--Product Type-->
                 <div class="row">
                  <div class="input-field col s12 m6 l6">
                               <input  class="form-control confirm-chr" data-handel="allow-input-chr-field" title="input-field-role-for-product-name" spellcheck="false" id="txtproduct" name="txtproduct" type="text" >
                              <label for="email">Product Name</label>
                       </div>
                        <div class="input-field col s12 m6 l6">
                               <input  class="form-control confirm-chr" data-handel="allow-input-chr-field" title="input-field-role-for-product-name" spellcheck="false" id="txtbatch" name="batch" type="text" >
                              <label for="batch">Batch Number</label>
                       </div>
                       </div>
                          <div class="row">
                          <div class="input-field col s12 m6 l6">
                               <input  class="form-control "  value="" spellcheck="false" id="txtpcode" name="txtpcode" type="text" >
                              <label for="pcode">Product Code</label>
                             </div>
                             <div class="input-field col s12 m6 l6">
                               <input  class="form-control confirm-chr" data-handel="allow-input-chr-field" title="input-field-role-for-product-name" spellcheck="false" id="txtbcode" name="txtbcode" type="text" >
                              <label for="batch">Barcode Number</label>
                       </div>
                           
                        </div>
                        	<div class="row">
                             
                             <div class="input-field col s11 m5 l5 nmanu">
									<select class="form-control form-control1" id="manufacturer" name="manufacturer" >
                                    	<option value="0" >Select Supplier</option>
                                        	<?php foreach($manufacture as $manuval){	?>
													<option value="<?php echo $manuval->manufacture_id;?>"><?php echo $manuval->manufacture_name;?></option>	
                                                <?php }	?>
									</select>
                                      <label for="price">Supplier</label>
                           </div>
                           <div  class="input-field col s1 m1 l1 ">
                        <a class="addDynamicfield btnaddmanu" style="right:12px"><i class="material-icons">add_circle</i></a>
                           </div>
                           
                            <div class="input-field col s12 m6 l6">
                               <input  class="form-control number-check"  spellcheck="false" id="txtmrp" name="txtmrp" type="text" >
                              <label for="batch">MRP</label>
                       </div>
                            
                            </div>
						<div class="row">
                        
                          <div class="input-field col s11 m5 l5">
                          <select class="form-control form-control1 ncat" id="selcat" name="selcat" >
                                    	<option value="0">Select Category</option>
										<?php foreach($category as $key){	?>
													<option value="<?php echo $key->category_id;?>"><?php echo $key->cat_name;?></option>	
                                                <?php }	?>
									</select>
                          <label for="first_name">Category</label>  
                        </div>
                        <div  class="input-field col s1 m1 l1">
                        <a class="addDynamicfield btnaddcat" style="right:12px"><i class="material-icons">add_circle</i></a>
                        </div>
                         <div class="input-field col s12 m2 l2">
                               <input  class="form-control number-check " id="qtyinhand" name="qtyinhand" type="text"   >
                              <label for="net amount" class="active">Stock</label>
                        </div>
                        <div class="input-field col s11 m5 l3 nunit">
									<select class="form-control form-control1" id="selunit" name="selunit" >
                                    	<option value="0" >Product Unit</option>
										<?php foreach($measurement as $measurement){	?>
													<option value="<?php echo $measurement->measurement_id;?>"><?php echo $measurement->measurement_name;?></option>	
                                                <?php }	?>
									</select>
                                      <label for="price">Product Unit</label>
                          </div>
						  <div  class="input-field col s1 m1 l1">
                        <a class="addDynamicfield btnaddunit" style="right:12px"><i class="material-icons">add_circle</i></a>
                        </div>
                     
						 
                        </div>
                       
                      <!--PRODUCT NAME-->
                      
                      <!--PRICE & DESCOUNT-->
                       
                      <div class="row">
                      	      <div class="input-field col s6">
                           <input  class="form-control " id="description" name="description" type="text"   >
 						   <label for="description">Description</label>
                        </div>                
                         <!--<div class="input-field col s6">
                               <input  class="form-control input_field-amount input_field-tax_properties" data-handel="allow-input-numeric-field" title="input-field-role-for-product-net-amount" spellcheck="false" id="txtnetamount" name="txtnetamount" type="text" readonly placeholder="Net Amount" >
                              <label for="net amount" class="active">Enter Net Amount</label>
                        </div>-->
                        
						 <!--<div class="input-field col s6">
									<select class="form-control form-control1" id="seltax" name="seltax" >
                                    	<option value="0" >Select Tax</option>
										 
									</select>
                              		<label for="product tax">Tax</label>
                         </div>-->
                      
                         
                      </div>
                          
                         
                        
                        
                        <div class="row">
                            <div class="col s12" id="taxproperty" role="show-tax-property">
                              
                                     
                            </div>
                       </div> 
                        
                        
                        
                        
                        
                        
                      <!--BUTTON SUBMIT-->
                        <div class="row">
                          <div class="input-field col s12">
                            <button class="btn cyan waves-effect waves-light right" type="button" id="prdct-add-btn" name="action">Add Product
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                        </div>
                    </form>
                  </div>
                </div>
              </div>
              
              <div class="col s12 m6 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Product</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:20px;text-align:center;">SN</th>
                          <th style="text-align:left;width:75px;">Product</th>
                          <th style="width:75px;text-align:left;">Action</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php if($product){ $i=1; foreach($product as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:20px;text-align:center;"><?php echo $i ?></td>
								<td style="text-align:left;width:75px;"><?php echo $val->product_name?> </td>
								<td style="width:75px;text-align:left;"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>product/proedit/<?php echo encode($val->product_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->product_id);?>" href="#">
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
              
              
                </div>
                
                
                
                
                
                
                
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
<div class="overlay"><div class="loadingimg"></div></div>        
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

<script type="text/javascript">
 $(document).ready(function(){
    $('#tooltipped').tooltip({delay: 50});
  });
$(document).ready(function(e) {
	$(document).on('focusout','input',function(){
		if($(this).val()!=''){$(this).removeClass('errors');$(this).parent().children('label').removeClass('labelerror');}
	});
	//GET Sub Categorie
	$(document).on('change','#selcat', function(){
	 $('#selcat').material_select();
		$('.overlay').css({'display':'flex'});
		var catid=$('#selcat').val();
	//	alert(catid);
		$.ajax({
			type:'POST',
			url:"<?php echo ADMIN_PATH ?>product/newgetsubcategoriey",
			data:'catid='+catid,
			success: function(data){
			//	alert(data);
					$('.overlay').css({'display':'none'});
					//$('#selsubcats').parent('.select-wrapper').children('.select-dropdown').addClass('selsubinp');
					$('#selsubcats').html(data);
					$('#selsubcats').trigger('contentChanged');
				}
			})
	});
	//GET Tax Property	
	$(document).on('change','#seltax', function(){

		$('.overlay').css({'display':'flex'});
		var selectedtaxid=$(this).val();
		$.ajax({
			type:'POST',
			url:"<?php echo ADMIN_PATH ?>product/newgettaxproperty",
			data:'selectedtaxid='+selectedtaxid,
			success: function(data){//alert(data);
					$('.overlay').css({'display':'none'});
					$('#taxproperty').html(data);
					setTimeout(function(){
						$('.input-field').removeClass('append-div-item');
						},500);
					//$('#selsubcats').trigger('contentChanged');
				calcnet();
				}
			});
	});
	//Materialize Select Calling
	$('select').on('contentChanged', function() {
    // re-initialize (update)
    $(this).material_select();
  });

//*Field Validation*//	
$('#prdct-add-btn').click(function(e) {
	
     data=$('#frmproduct').serialize();
	
	 var errorfield=FieldValidation();
	 if(errorfield!=1){
	 $('.overlay').css({'display':'flex'});
			$.ajax({
					type:'POST',
					url:"<?php echo  ADMIN_PATH ?>product/addproduct",
					data:data,
					success: function(data)
					{
						$('.overlay').css({'display':'none'});
						customSwalFunD("Added!", "Product item Successfully Added!", "success");
						location.reload() ;
					}
				 });
		}
//	
	function FieldValidation(){
$datasel_id=0;error_result=0;
$('input').removeClass('errors');$('label').removeClass('labelerror');$('select').removeClass('errors');
var values = {
	'ptype':$('#selptype').val(),
	'hsncode':$('#txthsncode').val(),
	'category':$('#selcat').val(),
	'subc':$('#selsubcats').val(),
	'product':$('#txtproduct').val(),
	'amount':$('#txtamount').val(),
 	'txtrack':$('#txtrack').val(),
	'discount':$('#txtdiscount').val(),
	'measurement':$('#selunit').val(),
	'netam':$('#txtnetamount').val(),
	'tax':$('#seltax').val(),
	'txreorderlvl':$('#txreorderlvl').val(),
 	'txtpcode':$('#txtpcode').val(),
 	'txtmrp':$('#txtmrp').val(),
	'txtpurchase':$('#txtpurchase').val(),
	'manufacturer':$('#manufacturer').val(),
	'qtyinhand':$('#qtyinhand').val(),
	'selNeg':$('#selNeg').val()}	

    if(values.txreorderlvl == ''){
            $('#txreorderlvl').addClass('errors');
			$('#txreorderlvl').parent().children('label').addClass('labelerror active');
            error_result=1;
        } 
		
		  if(values.txtrack == ''){
		    $('#txtrack').addClass('errors');
			$('#txtrack').attr("placeholder", "Please enter Rack")
		    $('#txtrack').parent().children('label').addClass('labelerror active');
            error=1;
        }  
		   
		
		
		 if(values.txreorderlvl == ''){
		    $('#txreorderlvl').addClass('errors');
			$('#txreorderlvl').attr("placeholder", "Please enter Re order level")
		    $('#txreorderlvl').parent().children('label').addClass('labelerror active');
            error=1;
        }
		
		if(values.qtyinhand == ''){
            $('#qtyinhand').addClass('errors');
			$('#qtyinhand').parent().children('label').addClass('labelerror');
            error_result=1;
        } 
		    if(values.manufacturer ==0){
           $('#manufacturer').parent().children('.select-dropdown').addClass('errors');
			$('#manufacturer').parent().parent().children('label').addClass('labelerror');
			
            error_result=1;
        } 
		
		 if(values.hsncode == 0){
		   $('#txthsncode').parent().children('.select-dropdown').addClass('errors');
			$('#txthsncode').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		
		
		if(values.txtpurchase == ''){
            $('#txtpurchase').addClass('errors');
			$('#txtpurchase').parent().children('label').addClass('labelerror');
            error_result=1;
        }    
		
		 if(values.txtmrp == ''){
            $('#txtmrp').addClass('errors');
			$('#txtmrp').parent().children('label').addClass('labelerror');
            error_result=1;
        } 
		
		  
			if(values.txtpcode == ''){
            $('#txtpcode').addClass('errors');
			$('#txtpcode').parent().children('label').addClass('labelerror');
            error_result=1;
        } 
		 if(values.ptype == 0) {
			$('#selptype').parent().children('.select-dropdown').addClass('errors');
			$('#selptype').parent().parent().children('label').addClass('labelerror');
			error_result=1;
		 }
		 if(values.category == 0) {
			$('#selcat').parent().children('.select-dropdown').addClass('errors');
			$('#selcat').parent().parent().children('label').addClass('labelerror');
			error_result=1;
		 }
		/* if(values.subc == 0){
			$('#selsubcats').parent().children('.select-dropdown').addClass('errors');
			$('#selsubcats').parent().parent().children('label').addClass('labelerror');
			error_result=1;
		 }*/
		 if(values.measurement == 0){
			$('#selunit').parent().children('.select-dropdown').addClass('errors');
			$('#selunit').parent().parent().children('label').addClass('labelerror');
			error_result=1;
		} 
		 if(values.tax == 0 ){
			$('#seltax').parent().children('.select-dropdown').addClass('errors');
			$('#seltax').parent().parent().children('label').addClass('labelerror');
			error_result=1;
		 }
        if(values.hsncode == ''){
            $('#txthsncode').addClass('errors');
			$('#txthsncode').parent().children('label').addClass('labelerror');
            error_result=1;
        } 
		
		if(values.product == ''){
            $('#txtproduct').addClass('errors');
			$('#txtproduct').parent().children('label').addClass('labelerror');
            error_result=1;
        } 
		if(values.amount == ''){
            $('#txtamount').addClass('errors');
			$('#txtamount').parent().children('label').addClass('labelerror');
            error_result=1;
        } 
		if(values.selNeg == 0 ){
			$('#selNeg').parent().children('.select-dropdown').addClass('errors');
			$('#selNeg').parent().parent().children('label').addClass('labelerror');
			error_result=1;
		 }
		return error_result;
	}
});	
});	
function alreadyexistalert(){
	
	 swal({
                            title: "Error",
							   text: "Tax Type Already Exist",
							   showCancelButton: true,
							   confirmButtonText: "OK",
							   cancelButtonText: "Cancel ",
							   customClass:"swal-delete",
                         	 }).then(function(){
							  
							   btnaddprotype();
							  
							  });
	}
function btnaddprotype(){
								
		  					  $('#selptype').material_select();
							  $('#selptype').css({'display':'block'});
							//  var cat=$("#cat").val();
				swal({
						  title: 'Add New Tax Type',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input autofocus="autofocus" placeholder="Enter Tax Type " name="txtprotype" spellcheck="false" id="txtprotype" type="text"  ><label for="first_name">Tax Type</label></div></div><div class="row"><div class="input-field col s12"><input autofocus="autofocus" placeholder="Enter Tax Type Percentage" name="txtproper" spellcheck="false" id="txtproper" type="text" class="number-check"  ><label for="first_name" class="active">Tax Type Percentage</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var txtprotype=$("#txtprotype").val();
									var txtproper=$("#txtproper").val();
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors'); 
								    $('select').removeClass('errors');
								   if(txtprotype==''){ 
											$('#txtprotype').parent().children('label').addClass('labelerror');
											$('#txtprotype').addClass('errors');
											$('#txtprotype').attr("placeholder", "Please enter Product type");
										err=1;
									}
									if(txtproper==''){ 
											$('#txtproper').parent().children('label').addClass('labelerror');
											$('#txtproper').addClass('errors');
											$('#txtproper').attr("placeholder", "Please enter Product type percentage");
										err=1;
									}
									return err;	
							}
								if(ev==0){
								
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/newprotype",
														data:"txtprotype="+txtprotype+"&txtproper="+txtproper,
														success:function(data){
															 $('.overlay').css({'display':'none'}); 
														if(data==1){
															alreadyexistalert();
															//reject('Tax Type Already Exist');
															}
															else{
															
																resolve();	  
															}
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
										$('.overlay').css({'display':'flex'});
									swal({
		  title: '<div class="tst" >Success</div>',
		  html:'<div class="tst1" >Product Type Added</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
			 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/getnewprotypes",
												//	data:"catval="+cat2,
														success:function(data){ 
																$('.overlay').css({'display':'none'}); 
																$('#selptype').material_select('destroy');
																$('.nprotype').html(data);
																$('#selptype').material_select();
														}
										 			});
			  	});
	
		}
						
						
	$(document).on('click', '.btnaddprotype', function(){
		btnaddprotype();
		
		})

//Adding Sub Category Direct//
	$(document).on('click', '.btnaddsubcat', function(){	
	
		  					  $('#subcat').material_select();
							  $('#subcat').css({'display':'block'});
							//  var cat=$("#cat").val();
				swal({
						  title: 'Add New Sub Category',
						  type: 'info',
						  html:
							'<div class="row"><select style="display:block;" class="form-control form-control1" id="cat" name="cat" ><option value="0">Select Category</option><?php foreach($category as $key){	?><option value="<?php echo $key->category_id;?>"><?php echo $key->cat_name;?></option><?php }	?></select></div><div class="row"><div class="input-field col s12"><input role="tax-name-content" autofocus="autofocus" placeholder="Enter Sub Category Name" name="txtsubcats" spellcheck="false" id="txtsubcats" type="text"  ><label for="first_name">Sub Category Name</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var subcatname=$("#txtsubcats").val();
								var cat=$("#cat").val();
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors'); 
								    $('select').removeClass('errors');
								   	if(cat==0){ 
											$('#cat').parent().children('label').addClass('labelerror');
											$('#cat').addClass('errors');
											$('#cat').attr("placeholder", "Please Select a Category ");
										err=1;
									}
								   
									if(subcatname==''){ 
											$('#txtsubcats').parent().children('label').addClass('labelerror');
											$('#txtsubcats').addClass('errors');
											$('#txtsubcats').attr("placeholder", "Please enter Sub Category Name");
										err=1;
									}
								
									
									return err;	
									
									
									
							}
								if(ev==0){
								
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/newsubcategory",
														data:"txtsubcats="+subcatname+"&cat="+cat,
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
																resolve();	  
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
										$('.overlay').css({'display':'flex'});
								  $('#subcat').material_select();
								  var cat2=$("#cat").val();
									swal({
		  title: '<div class="tst" >Suscess</div>',
		  html:'<div class="tst1" >CategoryAdded</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
			 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/getnewsubcats",
													data:"catval="+cat2,
														success:function(data){ 
														
															$('.overlay').css({'display':'none'}); 
															//	resolve();
														  $('#selsubcats').material_select('destroy');
															//console.log(data);
																//  $('#selunit').remove();  
															//	$('#btnadnsub').remove(); 
																$('.nsubcat').html(data);
																$('#selsubcats').material_select();
															
														}
										 			});
	/*	setTimeout(function(){
			location.reload() ;
			},600)*/
		
			 
			  	});
	
	
	
	})
	
	//adding category Direct//
		$(document).on('click', '.btnaddcat', function(){	
	
		  				
							
				swal({
						  title: 'Add New Category',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input role="tax-name-content" autofocus="autofocus" placeholder="Enter Category Name" name="txtcats" spellcheck="false" id="txtcats" type="text"  ><label for="first_name">Category Name</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var catname=$("#txtcats").val();
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors');
									if(txtcats==''){
											$('#txtcats').parent().children('label').addClass('labelerror');
											$('#txtcats').addClass('errors');
											$('#txtcats').attr("placeholder", "Please enter Category Name.");
										err=1;
										}
									return err;	
							}
								if(ev==0){
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/newcategory",
														data:"txtcats="+catname,
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
																resolve();	  
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
									  $('#selcat').material_select();
								var cat2= $('#selcat').val();
									$('.overlay').css({'display':'flex'});
									swal({
		  title: '<div class="tst" >Suscess</div>',
		  html:'<div class="tst1" >New Category Added</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
		 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/getnewcats",
														data:"cat="+cat2,
														success:function(data){ 
														
															$('.overlay').css({'display':'none'}); 
															//	resolve();
														  $('#selcat').material_select('destroy');
																$('.ncat').html(data);
																$('#selcat').material_select();
														
														}
										 			});
		
		/*setTimeout(function(){
			location.reload() ;
			},600)*/
		
			 
			  	});
	
	
	
	})
	
	$(document).on('click', '.btnaddunit', function(){	
	
		  				
							
				swal({
						  title: 'Add New Mesurement unit',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input role="tax-name-content" autofocus="autofocus" placeholder="Enter Mesurement Name" name="munit" spellcheck="false" id="munit" type="text"  ><label for="first_name">Mesurement Name</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var unitname=$("#munit").val();
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors');
									if(unitname==''){
											$('#munit').parent().children('label').addClass('labelerror');
											$('#munit').addClass('errors');
											$('#munit').attr("placeholder", "Please enter a Name.");
										err=1;
										}
									return err;	
							}
								if(ev==0){
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/newmesureunit",
														data:"munit="+unitname,
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
																resolve();	  
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
										$('.overlay').css({'display':'flex'});
									swal({
		  title: '<div class="tst" >Suscess</div>',
		  html:'<div class="tst1" >New MesurmentAdded</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
		
			 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/getnewmesureunit",
													
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
															//	resolve();
														  $('#selunit').material_select('destroy');
															//console.log(data);
																//  $('#selunit').remove();  
																$('#btnaddunit').remove(); 
																$('.nunit').html(data);
																$('#selunit').material_select();
															
														}
										 			});
		/*setTimeout(function(){
			location.reload() ;
			},600)
		*/
			 
			  	});
})
	$(document).on('click', '.btnaddhsn', function(){	
	
		  				
							
				swal({
						  title: 'Add New Hsn Code',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input role="tax-name-content" autofocus="autofocus" placeholder="Enter Hsn Code" name="hsn" spellcheck="false" id="hsn" type="text"  ><label for="first_name">Hsn Code</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var name=$("#hsn").val();
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors');
									if(name==''){
											$('#hsn').parent().children('label').addClass('labelerror');
											$('#hsn').addClass('errors');
											$('#hsn').attr("placeholder", "Please enter a valid Code.");
										err=1;
										}
									return err;	
							}
								if(ev==0){
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/hsn",
														data:"hsn="+name,
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
																resolve();	  
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
										$('.overlay').css({'display':'flex'});
									swal({
		  title: '<div class="tst" >Suscess</div>',
		  html:'<div class="tst1" >New HsnAdded</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
		
			 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/getnewhsn",
													
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
															//	resolve();
														  $('#txthsncode').material_select('destroy');
															//console.log(data);
																//  $('#selunit').remove();  
																$('#btnaddhsn').remove(); 
																$('.nhsn').html(data);
																$('#txthsncode').material_select();
															
														}
										 			});
		/*setTimeout(function(){
			location.reload() ;
			},600)
		*/
			 
			  	});
	})
	
		//adding category Direct//
		$(document).on('click', '.btnaddmanu', function(){	
	
		  				
							
				swal({
						  title: 'Add New Manufacturer',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input role="tax-name-content" autofocus="autofocus" placeholder="Enter Manufacturer Name" name="txtmanus" spellcheck="false" id="txtmanus" type="text"  ><label for="first_name">Manufacturer Name</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var txtmanus=$("#txtmanus").val();
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors');
									if(txtmanus==''){
											$('#txtmanus').parent().children('label').addClass('labelerror');
											$('#txtmanus').addClass('errors');
											$('#txtmanus').attr("placeholder", "Please enter Manufacturer Name.");
										err=1;
										}
									return err;	
							}
								if(ev==0){
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/addnewmanufacturer",
														data:"txtmanus="+txtmanus,
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
																resolve();	  
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
									//  $('#manufacturer').material_select();
							//	var txtmanus2= $('#txtmanus').val();
									$('.overlay').css({'display':'flex'});
									swal({
		  title: '<div class="tst" >Success</div>',
		  html:'<div class="tst1" >New Manufacturer Added</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
		 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/getnewmanufacturer",
													
														success:function(data){ 
														
															$('.overlay').css({'display':'none'}); 
															//	resolve();
														  $('#manufacturer').material_select('destroy');
																$('.nmanu').html(data);
																$('#manufacturer').material_select();
														
														}
										 			});
		
		/*setTimeout(function(){
			location.reload() ;
			},600)*/
		
			 
			  	});
	
	
	
	})
</script>

<script type="text/javascript">
$(document).on('click', '.btndlt', function(){
	var redirect=	"<?php echo ADMIN_PATH ?>product";
$btn=$(this);$tr=$btn.parent().parent();var id=$(this).attr('rel');  
swal({
	  title: "Are you sure?",
	  text: "Your will not be able to recover this Data!",
	  type: "warning",
	  showCancelButton: true,
	  confirmButtonClass: "btn-danger",
	  confirmButtonText: "Yes, delete it!",
	  customClass: 'swal-delete',
	  cancelButtonText: "No, cancel!",
  
}).then(function(){
			 $.ajax({
                                            type:"post",
                       						url: "<?php echo ADMIN_PATH ?>product/deleteproduct",
                                            data:"id="+id,
                                            success:function(data){ //alert(data);
												swal(
														  'Success!',
														  'Data has been Deleted',
														  'success'
														)
											//	$tr.remove();
											//	location.reload() ;
											document.location=redirect;
											 }
								});
			});
			/*
function(isConfirm) {
  if (isConfirm) {
	  alert(0)
	  $.ajax({
                    type:"post",
					url: "<?php  echo ADMIN_PATH ?>tax/deletetax",
					data:"id="+id,
					success:function(data){ 
					alert(data);
								swal("Sucessfully!", "Sucessfully Deleted!", "success");
								location.reload() ;
          						}
						});//AJAX END
  //  swal("Deleted!", "Your imaginary file has been deleted.", "success");
  } 
  else {
    swal("Cancelled", "Your imaginary file is safe :)", "error");*/
  });

 $(document).on('keypress','.number-check', function(e) {	
				//console.log(1);
				if ( event.keyCode == 46 || event.keyCode == 8 ) {//|| event.keyCode == 37	event.keyCode==37 for Percentage
							
				}
				 else {
            // Ensure that it is a number and stop the keypress
						if (event.keyCode < 48 || event.keyCode > 57) {
							event.preventDefault(); 
						}  
				 }
				//return isNumber(event, this)
			});
</script>
    
    
    
    
    
    
    

