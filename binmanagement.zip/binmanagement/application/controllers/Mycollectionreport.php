<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MycollectionReport extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Mycollection_model','model');
	 }	
	 public function index()
	{
		$data['menu']='reports';
		$data['submenu']='myclreport';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/datecollectionreport/mycollection');
		$this->load->view('admin/footer');
	}
	
	public function collection()
	{

		$this->model->datecollection();
		
		}
		
}
