<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class EmployeeViceCollectionReport extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Employeecollection_model','model');
	 }	
	 public function index()
	{
	    $data['employee']=$this->model->getemployee();
		$data['menu']='collection';
		$data['submenu']='empcolreport';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/employeecollection/empcoll',$data);
		$this->load->view('admin/footer');
	}
	
	public function empvicecollection()
	{
		
		$this->model->empvicecollection();
		
		}
		
}
