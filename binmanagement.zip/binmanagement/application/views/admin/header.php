<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="keywords" content="">
    <title>Bin Management - A basic smart Digital Manager</title>
    <!-- Favicons-->
    <link rel="icon" href="<?php echo ADMIN_STYLEPATH ?>images/favicon/favicon-32x32.png" sizes="32x32">
    <!-- Favicons-->
    <link rel="apple-touch-icon-precomposed" href="<?php echo ADMIN_STYLEPATH ?>images/favicon/apple-touch-icon-152x152.png">
    <!-- For iPhone -->
    <meta name="msapplication-TileColor" content="#00bcd4">
    <meta name="msapplication-TileImage" content="<?php echo ADMIN_STYLEPATH ?>images/favicon/mstile-144x144.html">
    <!-- For Windows Phone -->
    <!-- CORE CSS-->
    <link href="<?php echo ADMIN_STYLEPATH ?>css/themes/horizontal-menu/materialize.css" type="text/css" rel="stylesheet">
   <link href="<?php echo ADMIN_STYLEPATH ?>css/themes/horizontal-menu/material.min.css" type="text/css" rel="stylesheet">
   
    <link href="<?php echo ADMIN_STYLEPATH ?>css/themes/horizontal-menu/style.css" type="text/css" rel="stylesheet">
    <link href="<?php echo ADMIN_STYLEPATH ?>css/layouts/style-horizontal.css" type="text/css" rel="stylesheet">
	<link href="<?php echo ADMIN_STYLEPATH ?>vendors/sweetalert/dist/sweetalert2.min.css" type="text/css" rel="stylesheet">
    <link href="<?php echo ADMIN_STYLEPATH ?>vendors/jvectormap/jquery-jvectormap.css" type="text/css" rel="stylesheet">
    <link href="<?php echo ADMIN_STYLEPATH ?>vendors/flag-icon/css/flag-icon.min.css" type="text/css" rel="stylesheet">
<!--    <link href="<?php echo ADMIN_STYLEPATH; ?>vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
-->    <link href="<?php echo ADMIN_STYLEPATH; ?>vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo ADMIN_STYLEPATH; ?>vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo ADMIN_STYLEPATH; ?>vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo ADMIN_STYLEPATH; ?>vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">
 <!--   <link href="<?php echo ADMIN_STYLEPATH; ?>material-datepicker/css/material.datepicker.css" rel="stylesheet"> -->
      
      
        <link href="https://cdn.datatables.net/1.10.16/css/dataTables.material.min.css" rel="stylesheet"> 

<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false&key=AIzaSyDR07gIkjnjfMhUqqj5WPZ3oUAjoo49wKQ"></script> 

    <style>
	
/*.dataTables_wrapper{    padding: 15px !important;
}
table{background: #fff;
    padding: 10px 3px;
	}
	body{
		background-color:#f5f5f5 !important;
	}
	table.dataTable {
    border-collapse: collapse !important;
	}
button,button:focus{
	outline:none;
}*/
   .buttons-html5,.buttons-print {
    background-color: #82a0ac !important;
    margin-right: 5px !important;
    height: 32px !important;
   }
.container_right {
    background: #f5f5f5;
    border-left: 1px solid #f5f5f5;
    border-top: 1px solid #f5f5f5;
    margin: 0;
    min-width: 600px;
    padding: 2px;
    position: relative;
    width: 79%;
    float: right;
}.main-panel>.content {
   margin-top: 0px !important; 
    padding: 30px 15px;
    min-height: calc(100% - 123px);
}
.btn-group, .btn-group-vertical {
	float:left;
}

.swal2-modal .swal2-content {
     text-align: left !important; 
}
.btn-primary:hover {
    color: #fff;
    border-color:transparent;
}
.btn-primary {
    color: #fff;
    border-color:transparent;
}
.error{
	background-image:linear-gradient(#f9c941, #f9c941), linear-gradient(#ff0000, #ff1111) !important;
	
	}
	.swal-form .swal2-icon  {
    display: none !important;
}
.swal-form .swal2-title {
 	margin: 0px 0px 85px 0px  !important;
	padding-bottom:8px !important;
	color: #a7a7a7 !important;
    font-size: 24px !important;
    font-weight: 400 !important;
    letter-spacing: 1px !important;
    font-family: segoe ui !important;
    border-bottom: 1px solid #e4d8d8 !important;
   /* font-size: 28px !important;
    font-weight: 500 !important;*/
}  
.swal-form .swal2-confirm { 
	background-color: rgb(34, 167, 122) !important;
    
}
.swal-form{
	width: 420px !important;
    padding: 10px 20px !important;
    min-height: 300px !important;
	  
	}
.swal-form	.swal2-cancel{
	background-color: rgb(34, 167, 122) !important;
		
		}
	.swal-form	.card-content .title{
		    font-weight: 600;	
			
}
/*new*/
.swal2-modal .swal2-title,.swal2-modal .swal2-content{
/*	text-align:center !important;*/
}

	.head-content{
		width:90%;
		padding:10px;
		background:#f9c941;
		}
		.card .card-header {
    
    padding: 12px !important;
    
}
th{
	font-size:14px !important;
	font-weight:bold;
}


.pagination>.active>a
{
	background:#82a0ac;
	color:#FFF;
	border:none;
}
.btn-default, .cyan 
{
	/*background-color:rgba(21, 190, 241, 0.65) !important*/
	background-color:rgb(34, 167, 122) !important;
	border-radius:0px !important;
}
.ui-widget-header {
     border: 1px solid #00bcd4 !important; 
     background: #00bcd4 url(images/ui-bg_highlight-soft_15_cc0000_1x100.png) 50% 50% repeat-x !important; 
    color: #ffffff;
    font-weight: bold;
}
.page-footer {
    padding-top: 20px;
    color: #fff;
    background-color: #00bcd4;
    bottom: 0px;
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    color: white;
    text-align: center;
}
.wrapper{
	min-height:478px !important;
	}
	.gradient-45deg-light-blue-cyan {
    background: #0288d1 !important;
    background-color: #0288d1 !important;
    
}
.page-footer {
	background: #073d4a !important;
    background-color: #073d4a !important;
	z-index:100;
}
.picker__header select
{
position: relative !important;
    width: 36% !important;
    pointer-events: all !important;
    height: 30px !important;
    top: 0 !important;
    left: 0 !important;
    opacity: 1 !important;
}
.picker__table th, .picker__table td {
    background:#FFF !important;
}
.btn-floating {
	width:30px !important;
	height:30px !important;
}
.btn-floating i {
	font-size:19px !important;
	line-height:31px !important;
}
.dataTables_filter
{
	width:23% !important;
	float:right;
}
.dataTables_filter input
{
	height:20px !important;
}
.pagination li a {
	font-size:13px !important;
}




.addDynamicfield,.removeDynamicfield{
						    position: absolute;
							top: 16px;
							right: -10px;
							padding:0px;
							color: #0092d3;
							cursor:pointer;
							opacity:0.7;
							transition:opacity 0.2s;
							  -webkit-touch-callout: none; /* iOS Safari */
							-webkit-user-select: none; /* Safari */
							 -khtml-user-select: none; /* Konqueror HTML */
							   -moz-user-select: none; /* Firefox */
								-ms-user-select: none; /* Internet Explorer/Edge */
									user-select: none; /* Non-prefixed version, currently
														  supported by Chrome and Opera */
				  }
				   .addDynamicfield:hover,.removeDynamicfield:hover{
					   opacity:1;
				   }
				  .removeDynamicfield{
						color:#F30;  
				  }
                  .addDynamicfield i,.removeDynamicfield i{
					font-size: 22px;  
				  }
				  .removeDynamicfield i.removing{
					  animation:spin 2s linear infinite;
				  }
			.btn-default, .cyan {
    background-color: rgb(34, 167, 122) !important;
    border-radius: 0px !important;
    margin-right: 12px;
}	  
	@media only screen and (max-width: 701px) {
  .page-footer {
    display:none;
  }
  .btn-floating {
    width: 40px !important;
    height: 40px !important;
}
.btn-floating i {
    font-size: 19px !important;
    line-height: 40px !important;
}
#layouts-horizontal .sidebar-collapse {
    position: absolute;
    left: 10px;
    top: 9px;
    z-index: 999;
}
}			  
 .buttons-print {
    background-color: #0288d1 !important;
    margin-right: 5px !important;
    height: 32px !important;
   }  
   .buttons-csv {
    background-color: #0288d1 !important;
    margin-right: 5px !important;
    height: 32px !important;
   }  
    .buttons-excel {
    background-color: #0288d1 !important;
    margin-right: 5px !important;
    height: 32px !important;
   }  .buttons-pdf        {
    background-color: #0288d1 !important;
    margin-right: 5px !important;
    height: 32px !important;
   }  
   
   .gradient-45deg-purple-deep-orange {
    background: #0a3c48;
    background: -webkit-linear-gradient(45deg, #0a3c48 0%, #0a3c48 100%);
    background: linear-gradient(45deg, #0a3c48 0%, #0a3c48 100%) !important;
}
.selorgs input[type="text"]{
    padding: 0px 20px;
	border-bottom:none;
	font-size: 18px;
    font-weight: bold;
    letter-spacing: 0.9px;	
	}
	.selorgs .caret{
	font-size: 18px !important;
    color: #fff !important;
    padding: 0px 20px;
	}
	.selorgs:hover{
		
		}
		#ul-horizontal-nav > li > a {
    padding: 0 15px !important;
}
	
		#horizontal-nav ul li a span {
    font-size: 14px;
	}
@media screen and (min-width: 993px) and (max-width: 1350px) {		
	#horizontal-nav ul li a span {
    font-size: 12px !important;
	}
	#ul-horizontal-nav > li > a {
		padding: 0 10px !important;
	}
}
.org {
	display:none;
}
.org input[type="text"]
{
	background:#0288d1;
}
@media only screen and (max-width: 990px) {
  .org {
    display:block !important;
  }
}
 </style>
          <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>vendors/jquery-3.2.1.min.js"></script> 

	 
  </head>
  <body id="layouts-horizontal">
    <!-- Start Page Loading -->
    <div id="loader-wrapper">
      <div id="loader"></div>
      <div class="loader-section section-left"></div>
      <div class="loader-section section-right"></div>
    </div>
    <!-- End Page Loading -->
    <!-- //////////////////////////////////////////////////////////////////////////// -->
    <!-- START HEADER -->
    <div class="overlay"><div class="loadingimg"></div></div>
    <header id="header" class="page-topbar">
      <div class="navbar-fixed">
        <nav class="navbar-color gradient-45deg-light-blue-cyan">
          <div class="nav-wrapper">
            <ul class="left">
              <li>
                <h1 class="logo-wrapper">
                
                <?php if($this->session->userdata('org_id'))
				{
				$iconz1=getmyicon($this->session->userdata('org_id'));
				}  
				else{$iconz1='';}
				?>
                  <a href="index.html" class="brand-logo darken-1">
           <img style="width:191px !important;height:28px !important;" src="<?php if(!empty($iconz1)){ echo PATH.$iconz1;}else{ echo ADMIN_STYLEPATH.'images/logo/materialize-logo.png';}?>" alt="materialize logo">
                   <!-- <span class="logo-text hide-on-med-and-down">CarbonCopy</span>-->
                  </a>
                </h1>
              </li>
            </ul>
            <div class="header-search-wrapper hide-on-med-and-down">
            <?php if($this->session->userdata('usergroup')=='0') { getallorg() ; }?>
            
            </div>
            <ul class="right hide-on-med-and-down">
              
             <?php  if($this->session->userdata('usergroup')!='0') { ?> 
              <li>
                <a href="javascript:void(0);" class="waves-effect waves-block waves-light notification-button" data-activates="notifications-dropdown">
                  <i class="material-icons">notifications_none
                    <small class="notification-badge orange accent-3"><?php   getnotificationcount();?></small>
                  </i>
                </a>
              </li>
              <?php   } ?>
              <li>
                <a href="javascript:void(0);" class="waves-effect waves-block waves-light profile-button" data-activates="profile-dropdown">
                  <span class="avatar-status avatar-online">
                    <img src="<?php echo ADMIN_STYLEPATH ?>images/avatar/avatar-7.png" alt="avatar">
                    <i></i>
                  </span>
                </a>
              </li>
              
            </ul>
            <!-- translation-button -->
            
            <!-- notifications-dropdown -->
            
            <ul id="notifications-dropdown" class="dropdown-content" style="max-height:300px !important;">
             <?php  if($this->session->userdata('usergroup')!='0') { ?> 
              <li>
                <h6>NOTIFICATIONS
                 
                  <span class="new badge"><?php getnotificationcount() ; ?></span>
                </h6>
              </li>
              <li class="divider"></li>
              <?php  getnotifications(); }?>
             
            </ul>
            <!-- profile-dropdown -->
            <ul id="profile-dropdown" class="dropdown-content">
              
              <li class="<?php if($menu=='changepassword'){echo 'active';}  ?>">
                <a href="<?php echo ADMIN_PATH ?>changepwd" class="grey-text text-darken-1">
                  <i class="material-icons">lock_outline</i> Change Password</a>
              </li>
              <li>
                <a href="<?php echo ADMIN_PATH?>logout" class="grey-text text-darken-1">
                  <i class="material-icons">keyboard_tab</i> Logout</a>
              </li>
            </ul>
          </div>
           <div class="org">
            <?php if($this->session->userdata('usergroup')=='0') { getallorg() ; }?>
            
            </div>
        </nav>
        <!-- HORIZONTL NAV START-->
        <nav id="horizontal-nav" class="white hide-on-med-and-down">
          <div class="nav-wrapper">
            <ul id="ul-horizontal-nav" class="left hide-on-med-and-down">
              <li class="<?php if($menu=='index'){echo 'active';} ?>">
                <a href="<?php echo ADMIN_PATH?>index/home" >
                  <i class="material-icons">dashboard</i>
                  <span>Dashboard <?php //echo $this->session->userdata('org_id'); ?>
                  </span>
                </a>
              </li>
              
           <?php if($this->session->userdata('usergroup')=='0') {?>
			   
			   <li class="<?php if($menu=='organization'){echo 'active';} ?>">
                <a class="dropdown-menu" href="#!" data-activates="BasicUIdropdown">
                  <i class="material-icons">shop_two</i>
                  <span>Department
                   <i class="material-icons right">keyboard_arrow_down</i>
                  </span>
                </a>
              </li>
				
                <?php  }?>   
                
             <!--   -->
               <?php //if($this->session->userdata('usergroup')=='0') { ?>
               <!--<li class="<?php //if($menu=='smsorg'){echo 'active';} ?>">
                <a href="<?php //echo ADMIN_PATH?>smsorg" >
                  <i class="material-icons">shop_two</i>
                  <span>Sms settings
                  
                  </span>
                </a>
              </li>-->
			 <?php  //}?>   
           <!-- -->
              
              <?php 
              $a=array(1,2,3,4,5,6,7,14,9,10,13);
            $res=  mmenu($a);
		 if($res==1){
			  ?>
               <li class="<?php if($menu=='organizer'){echo 'active';} ?>">
                <a class="dropdown-menu" href="#!" data-activates="orgdropdown">
                 <i class="material-icons">settings</i>
                  <span>Organizer
                   <i class="material-icons right">keyboard_arrow_down</i>
                  </span>
                </a>
              </li>
              <?php  }    ?>
               <?php   $a=array(11,12);
            $res=  mmenu($a);
			 if($res==1){
			  ?>
              <li class="<?php if($menu=='product'){echo 'active';} ?>">
                <a class="dropdown-menu" href="#!" data-activates="Productdropdown">
                 <i class="material-icons">add_shopping_cart</i>
                  <span>Product
                   <i class="material-icons right">keyboard_arrow_down</i>
                  </span>
                </a>
              </li>
              <?php } ?>
              
              
              
               <?php  $a=array(15,16,17,18,19,20);
            $res=mmenu($a);
			//var_dump($res);
			 if($res==1){
			  ?>
              <li class="<?php if($menu=='organization'){echo 'active';} ?>">
                <a class="dropdown-menu" href="#!" data-activates="bin">
                  <i class="material-icons">shop_two</i>
                  <span>Bin Management
                   <i class="material-icons right">keyboard_arrow_down</i>
                  </span>
                </a>
              </li>
              <?php }    $a=array(21,22,23,24);
            $res=  mmenu($a);
			 if($res==1){ ?>
              
              <li class="<?php if($menu=='merchant'){echo 'active';} ?>">
                <a class="dropdown-menu" href="#!" data-activates="absence">
                  <i class="material-icons">supervisor_account</i>
                  <span>Absence report 
                    <i class="material-icons right">keyboard_arrow_down</i>
                  </span>
                </a>
              </li>
             <?php } ?>
             
              <?php  $a=array(25,26,27);
            $res=  mmenu($a);
			
			 if($res==1){  ?>
        
             <li class="<?php if($menu=='sales'){echo 'active';} ?>">
                <a  class="dropdown-menu" data-activates="employee">
                 <i class="material-icons">store</i>
                     <span>Employee Management  <i class="material-icons right">keyboard_arrow_down</i>
                  </span>
                </a>
              </li>
             
                 <?php } ?>
                 <?php     $a=array(28);
            $res=  mmenu($a);
			 if($res==1){ ?>
              
              <li class="<?php if($menu=='merchant'){echo 'active';} ?>">
                <a class="dropdown-menu" href="#!" data-activates="noti">
                  <i class="material-icons">supervisor_account</i>
                  <span>Notification
                    <i class="material-icons right">keyboard_arrow_down</i>
                  </span>
                </a>
              </li>
             <?php } ?> 
             
             <ul id="noti" class="dropdown-content dropdown-horizontal-list">
            <?php $res=menucheck(28); 
        if ($res==1)  {?>
            <li class="<?php //if($submenu=='employee'){echo 'active';} ?>"><a href="<?php echo ADMIN_PATH?>absents/notification"> Notification </a></li>
            <?php } ?>
          
             
        </ul>
             
             
             
             
             
             
             
             
             
             <ul id="absence" class="dropdown-content dropdown-horizontal-list">
            <?php $res=menucheck(22); 
        if ($res==1)  {?>
            <li class="<?php //if($submenu=='employee'){echo 'active';} ?>"><a href="<?php echo ADMIN_PATH?>Absents"> Report Absence </a></li>
            <?php } $res=menucheck(23); 
        if ($res==1)  {?>
            <li class="<?php //if($submenu=='deo'){echo 'active';} ?>"><a href="<?php echo ADMIN_PATH?>Viewshifts">View shift </a></li>
              <?php } $res=menucheck(24); 
        if ($res==1)  {?>
            <li class="<?php //if($submenu=='deo'){echo 'active';} ?>"><a href="<?php echo ADMIN_PATH?>Viewshifts">Download shift sheet </a></li>
              <?php } ?>
            
          
             
        </ul> 
             
             
           <ul id="employee" class="dropdown-content dropdown-horizontal-list">
            <?php $res=menucheck(26); 
        if ($res==1)  {?>
            <li class="<?php //if($submenu=='employee'){echo 'active';} ?>"><a href="<?php echo ADMIN_PATH?>authorisedperson/addemployee"> Register employees </a></li>
            <?php } $res=menucheck(27); 
        if ($res==1)  {?>
            <li class="<?php //if($submenu=='deo'){echo 'active';} ?>"><a href="<?php echo ADMIN_PATH?>assignshifts">Assign shift </a></li>
              <?php } ?>
            
          
             
        </ul>    
             
             
             
             
             
             
             <ul id="bin" class="dropdown-content dropdown-horizontal-list">
            <?php $res=menucheck(18); 
        if ($res==1)  {?>
            <li class="<?php //if($submenu=='employee'){echo 'active';} ?>"><a href="<?php echo ADMIN_PATH?>binreport"> View bin report </a></li>
            <?php } $res=menucheck(16); 
        if ($res==1)  {?>
            <li class="<?php //if($submenu=='deo'){echo 'active';} ?>"><a href="<?php echo ADMIN_PATH?>service">Register bin</a></li>
              <?php } $res=menucheck(17); 
        if ($res==1)  {?>
            <li class="<?php //if($submenu=='deo'){echo 'active';} ?>"><a href="<?php echo ADMIN_PATH?>registerreturn">Register returns  </a></li>
              <?php } $res=menucheck(19); 
        if ($res==1)  {?>
            <li class="<?php //if($submenu=='deo'){echo 'active';} ?>"><a href="<?php echo ADMIN_PATH?>viewreturnstock">View return stocks   </a></li>
              <?php } $res=menucheck(20); 
        if ($res==1)  {?>
			<li class="<?php //if($submenu=='deo'){echo 'active';} ?>"><a href="<?php echo ADMIN_PATH?>viewreturnstock">View current return stock 
</a>
            </li>
              <?php }?>
          
             
        </ul> 
             
             
            
          
          
          
          
          
           
        </nav>
        <!--ProductDropDownList -->
         <ul id="orgdropdown" class="dropdown-content dropdown-horizontal-list">
     <?php $res=menucheck(1); 
        if ($res==1)  {?>
            <li class="<?php if($submenu=='category'){ echo 'active'; } ?>"><a href="<?php echo ADMIN_PATH ?>category">Category</a></li>
            <?php   } ?> <?php   /*$res=menucheck(2); 
        if ($res==1)  {  */?>
			<!--<li class="<?php //if($submenu=='subcategory'){ echo 'active'; } ?>"><a href="<?php //echo ADMIN_PATH ?>subcategory">Sub Category</a></li>-->
             <?php   //} ?> <?php  $res=menucheck(3); 
        if ($res==1)  {  ?>
            <li class="<?php if($submenu=='manufacture'){ echo 'active'; } ?>"><a href="<?php echo ADMIN_PATH ?>manufacture">Supplier</a></li>
          <?php } ?> <?php  /*$res=menucheck(4); 
        if ($res==1)  {*/  ?>
           <!-- <li class="<?php //if($submenu=='tax'){ echo 'active'; } ?>"><a href="<?php echo ADMIN_PATH ?>productType">Tax Type</a></li>-->
		 <?php //} ?><?php   $res=menucheck(5); 
        if ($res==1)  {  ?>
        	  <li class="<?php if($submenu=='uom'){ echo 'active'; } ?>"><a href="<?php echo ADMIN_PATH ?>measurement">UOM ( Unit of Measurement)</a></li>
		 <?php } ?> <?php /*$res=menucheck(6); 
        if ($res==1)  {*/  ?>
        <!--	<li class="<?php //if($submenu=='usergroup'){ echo 'active'; } ?>"><a href="<?php //echo ADMIN_PATH ?>usergroup">User Group</a></li>-->
            
             <?php /* }  $res=menucheck(13); 
        if ($res==1)  {*/  ?>
        <!-- <li class="<?php //if($submenu=='area'){ echo 'active'; } ?>"><a href="<?php //echo ADMIN_PATH ?>area">Area</a></li>   -->
         
         <?php //} ?> <?php  $res=menucheck(9); 
        if ($res==1)  {  ?>
            <li class="<?php if($submenu=='education'){ echo 'active'; } ?>"><a href="<?php echo ADMIN_PATH ?>education"> Education </a></li>
			<?php } ?> <?php /*$res=menucheck(10); 
        if ($res==1)  {*/  ?>
            <!--<li class="<?php //if($submenu=='designation'){ echo 'active'; } ?>"><a href="<?php //echo ADMIN_PATH ?>Designation"> Designation </a></li>-->
            
                 
			 <?php //} ?> <?php  $res=menucheck(7); 
        if ($res==1)  {  ?>
           <!-- <li class="<?php if($submenu=='employeereg'){ echo 'active'; } ?>"><a href="<?php echo ADMIN_PATH ?>employee/addemployee">Employee Registration</a></li>-->
			 <?php }  $res=menucheck(14); 
        if ($res==1)  {  ?>
         <li class="<?php if($submenu=='employee'){ echo 'active'; } ?>"><a href="<?php echo ADMIN_PATH ?>employee">Employee List</a></li>        
			
       <?php }  ?>
        </ul>
        <ul id="Productdropdown" class="dropdown-content dropdown-horizontal-list">
        <?php $res=menucheck(11); 
        if ($res==1)  {  ?>
         	<li class="<?php if($submenu=='product'){ echo 'active'; } ?>"><a href="<?php echo ADMIN_PATH ?>product">Product List</a></li>
           <?php }  $res=menucheck(12); 
        if ($res==1)  {  ?>
            <li class="<?php if($submenu=='newproduct'){ echo 'active'; } ?>"><a href="<?php echo ADMIN_PATH ?>product/newproduct">New Product</a></li>
       <?php }   ?>
        </ul>
        <!-- BasicUIdropdown-->
        <ul id="BasicUIdropdown" class="dropdown-content dropdown-horizontal-list">
               
        <li class="<?php if($submenu=='orgreg'){ echo 'active'; } ?>"><a href="<?php echo ADMIN_PATH ?>authorisedperson/addemployee"> Authorised Person Registration </a></li>
        <li class="<?php if($submenu=='orgreg'){ echo 'active'; } ?>"><a href="<?php echo ADMIN_PATH ?>department/depregistration"> Department Registration </a></li>

         
         <!--<li class="<?php if($submenu=='vieworglist'){ echo 'active'; } ?>"><a href="<?php echo ADMIN_PATH ?>department">View Organisation List </a></li>       -->
         
        </ul>
        
        <!-- AdvancedUIdropdown-->
        
         
        
        
         
        
        
        
        
        
        <!--/////////////////////////////////////-->
        
        
        
         
        
        
        
       
      </div>
    </header>
    <!-- END HEADER -->
    <!-- //////////////////////////////////////////////////////////////////////////// -->
    
    	
<!-- START MAIN -->
    <div id="main">
      <!-- START WRAPPER mobile -->
      <div class="wrapper">
        <!-- START LEFT SIDEBAR NAV-->
        <aside id="left-sidebar-nav hide-on-large-only">
          <ul id="slide-out" class="side-nav leftside-navigation">
            <li class="no-padding">
              <ul class="collapsible" data-collapsible="accordion">
                <li class="bold">
                  <a class="waves-effect waves-cyan active" href="<?php echo SITE_PATH;?>">
                    <i class="material-icons">dashboard</i>
                    <span>Dashboard</span>
                  </a>
                </li>
                
                 <?php 
              $a=array(15,16,17,18,19,20);
            $res=  mmenu($a);
		 if($res==1){
			  ?>
                <li class="bold">
                  <a class="collapsible-header waves-effect waves-cyan">
                    <i class="material-icons">settings</i>
                    <span>Bin Management</span> 
                  </a>
                  <div class="collapsible-body">
                  <ul>
                  
                    <?php  $res=menucheck(18); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>binreport">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>View bin report</span>
                        </a>
                      </li>
                        <?php  } $res=menucheck(16); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>service">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>Register bin</span>
                        </a>
                      </li>
                        <?php } $res=menucheck(17); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>registerreturn">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>Register returns</span>
                        </a>
                      </li>
                        <?php } $res=menucheck(19); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>viewreturnstock">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>View return stocks </span>
                        </a>
                      </li>
                        <?php } $res=menucheck(20); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>viewreturnstock">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>View current return stock </span>
                        </a>
                      </li>
                        <?php }  ?>
                     
                      </ul>
                      </div>
                </li>
                <?php } ?>
                
                
                <?php 
              $a=array(21,22,23,24);
            $res=  mmenu($a);
		 if($res==1){
			  ?>
                <li class="bold">
                  <a class="collapsible-header waves-effect waves-cyan">
                    <i class="material-icons">settings</i>
                    <span>Absence report </span> 
                  </a>
                  <div class="collapsible-body">
                  <ul>
                  
                    <?php  $res=menucheck(22); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>Absents">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>Report Absence</span>
                        </a>
                      </li>
                        <?php  } $res=menucheck(23); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>Viewshifts">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>View shift</span>
                        </a>
                      </li>
                        <?php } $res=menucheck(24); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>Viewshifts">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>Download shift sheet</span>
                        </a>
                      </li>
                        <?php }  ?>
                      </div>
                </li>
                <?php } ?> 
                
                
                
                
                <?php 
              $a=array(25,26,27);
            $res=  mmenu($a);
		 if($res==1){
			  ?>
                <li class="bold">
                  <a class="collapsible-header waves-effect waves-cyan">
                    <i class="material-icons">settings</i>
                    <span>Employee Management</span> 
                  </a>
                  <div class="collapsible-body">
                  <ul>
                  
                    <?php  $res=menucheck(26); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>authorisedperson/addemployee">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>Register employees</span>
                        </a>
                      </li>
                        <?php  } $res=menucheck(27); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>assignshifts">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>Assign shift</span>
                        </a>
                      </li>
                        <?php } ?>
                     
                      </div>
                </li>
                <?php } ?> 
                
                
                
                
                
                
                
                 <?php 
              $a=array(1,2,3,4,5,6,7,8,9,10,13);
            $res=  mmenu($a);
		 if($res==1){
			  ?>
                <li class="bold">
                  <a class="collapsible-header waves-effect waves-cyan">
                    <i class="material-icons">settings</i>
                    <span>Organiser</span> 
                  </a>
                  <div class="collapsible-body">
                  <ul>
                  
                    <?php  $res=menucheck(1); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>category">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>Category</span>
                        </a>
                      </li>
                        <?php  } $res=menucheck(2); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>subcategory">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>Sub Category</span>
                        </a>
                      </li>
                        <?php } $res=menucheck(3); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>manufacture">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>Manufacture</span>
                        </a>
                      </li>
                        <?php } $res=menucheck(4); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>productType">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>Tax Type</span>
                        </a>
                      </li>
                        <?php } $res=menucheck(5); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>measurement">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>UOM(Unit of Measurement)</span>
                        </a>
                      </li>
                        <?php } $res=menucheck(6); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>usergroup">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>User Group</span>
                        </a>
                      </li>
                        <?php }  $res=menucheck(14); 
        if ($res==1)  {  ?>
         <li>
                        <a href="<?php echo SITE_PATH;?>employee">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>Employee List</span>
                        </a>
                      </li>
                      
                      
                  <?php  }      $res=menucheck(13); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>area">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>Area</span>
                        </a>
                      </li>
                       
                      
                        <?php } $res=menucheck(9); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>education">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>Education</span>
                        </a>
                      </li>
                        <?php }  $res=menucheck(10); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>designation">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>Designation</span>
                        </a>
                      </li>
                        <?php  } ?>
                      </ul>
                      </div>
                </li>
               
                 <?php }  $a=array(11,12);
            $res=  mmenu($a);
			 if($res==1){
			  ?>
                <li class="bold">
                  <a class="collapsible-header waves-effect waves-cyan">
                    <i class="material-icons">add_shopping_cart</i>
                    <span>Product</span>
                  </a>
                  <div class="collapsible-body">
                  <ul>
                   <?php  $res=menucheck(11); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>product">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>Product List</span>
                        </a>
                      </li>
                       <?php }  $res=menucheck(12); 
        if ($res==1)  {  ?>
                      <li>
                        <a href="<?php echo SITE_PATH;?>product/newproduct">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>New Product</span>
                        </a>
                      </li>
                       <?php }   ?>
                      </ul>
                      </div>
                  
                </li>
                   <?php }if($this->session->userdata('usergroup')=='0') {?>
                <li class="bold">
                  <a class=" collapsible-header waves-effect waves-cyan">
                    <i class="material-icons">shop two</i>
                    <span>Departments</span>
                  </a>
                   <div class="collapsible-body">
                  <ul> 
                      <li>
                        <a href="<?php echo SITE_PATH;?>authorisedperson/addemployee">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>Authorised Person Registration</span>
                        </a>
                      </li>
                      <li>
                        <a href="<?php echo SITE_PATH;?>department/depregistration">
                          <i class="material-icons">keyboard_arrow_right</i>
                          <span>Department Registration</span>
                        </a>
                      </li>
                      
                       
                      </ul>
                      </div>
                </li>
                <?php } ?>
                
               
                
                <!---->
                        
                
                
                 <li class="bold">
                  <a class="waves-effect waves-cyan active" href="<?php echo ADMIN_PATH;?>changepwd">
                    <i class="material-icons">lock_outline</i>
                    <span>Change Password</span>
                  </a>
                </li>

			 <li class="bold">
                  <a class="waves-effect waves-cyan active" href="<?php echo ADMIN_PATH;?>logout">
                    <i class="material-icons">keyboard_tab</i>
                    <span>Logout</span>
                  </a>
                </li>

               
              </ul>
            </li>
          </ul>
          <a href="#" data-activates="slide-out" class="sidebar-collapse btn-floating btn-medium waves-effect waves-light hide-on-large-only" style="position:fixed;">
            <i class="material-icons">menu</i>
          </a>
        </aside>
        <!-- END LEFT SIDEBAR NAV-->
        <!-- //////////////////////////////////////////////////////////////////////////// -->
        <section id="content">
        <script>
        function customSwalFun(sw_title,sw_html,sw_type,sw_class){
							swal({
											  title: '<div class="tst" >'+sw_title+'</div>',
											  html:'<div class="tst1" >'+sw_html+'</div>',
											  type: sw_type,
											  customClass: sw_class,
											})	
		}
		  function customSwalFunD(sw_title,sw_html){
							swal({
											  title: '<div class="tst" >'+sw_title+'</div>',
											  html:'<div class="tst1" >'+sw_html+'</div>',
											  customClass: 'swal-delete',
											})	
		}
		  function customSwalValErr(){
							swal({
											  title: '<div class="tst" >Alert</div>',
											  html:'<div class="tst1" >Required Fields are Empty</div>',
											  customClass:  'swal-delete',
											})	
		}
		$(document).ready(function(e) {
			<?php if($this->session->userdata('org_id')){ ?>
			var sorg="<?php echo $this->session->userdata('org_id')?>";
			$('#adminorgselect').val(sorg);
			
			<?php } ?>
		$(document).on('change', '#adminorgselect', function(){	
		
		var adorgid=$(this).val();
	
		$('#adminorgselect').trigger('contentChanged');
		$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>department/adminselectorg",
														data:"adorgid="+adorgid,
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
															location.reload(); 
														}
										 			});
		});
		
			$(document).on('click', '.vwnoti', function(){	
			
			
		var vid=$(this).attr('data-nid');
	//alert(vid);
	 var vwdet="<?php echo ADMIN_PATH ?>marketing/maredit/"+vid;
		$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>marketing/changevwstatus",
														data:"vid="+vid,
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
															//location.reload(); 
															document.location=vwdet;
														}
										 			});
		});
		
		 });
        </script>