<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Routehistory extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Routehistory_model','model');
	 }
	
	
//--/---------------------- New------------------------*/
	public function index()
	{
		$data['menu']='reports';
		$data['submenu']='history';
		$data['salesman']=$this->model->getsalesman();
		$this->load->view('admin/header',$data);
		$this->load->view('admin/routehistory',$data);
		$this->load->view('admin/footer');
	}
	
    public function location()
	{
		$this->model->location();
		
	}
	
	
	
}
