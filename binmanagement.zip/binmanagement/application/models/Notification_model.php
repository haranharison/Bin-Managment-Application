<?php
class Notification_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
		public function notification(){
			//date_default_timezone_set("US/Mountain");
			$curr_date1 = date("Y-m-d",strtotime("+3 days"));
			$curr_date = date("Y-m-d");
			$arr=array('follow_date >='=>$curr_date,'follow_date <='=>$curr_date1);
			
			$this->db->where($arr);
			/*$this->db->where('DATE(follow_date)',$curr_date1);*/
			$this->db->select('tbl_enquiry.*');
			$this->db->from('tbl_enquiry');
	   		//$this->db->join('tbl_merchant','tbl_merchant.merchant_id=tbl_enquiry.merchant');
			return $open=$this->db->get()->result();  
			
		}
	//Adding New Bank name
	 
}