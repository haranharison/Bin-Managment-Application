<?php
class Salesreport_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
      public function getsalesman(){
		 $array=array('tbl_salesmanreg.status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_salesmanreg');
		return $result = $this->db->get()->result(); 
		
		}     
		
		public function getarea(){
		 $array=array('tbl_area.status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_area');
		return $result = $this->db->get()->result(); 
		
		}     
		public function getmerchant(){
		 $array=array('tbl_merchant.status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_merchant');
		return $result = $this->db->get()->result(); 
		
		}  
		
		public function getdetailsbysid(){
			$sid=$this->input->post('sid');
		 $array=array('tbl_salesproduct.status'=>0,'tbl_salesproduct.salesman_id'=>$sid);
		$this->db->where($array);
		$this->db->select('tbl_salesproduct.*,tbl_salesmanreg.salesmanid,tbl_salesmanreg.name,tbl_merchant.merchant_id,tbl_merchant.merchantname,');
		$this->db->from('tbl_salesproduct');
		//$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesproduct.area' );
		$this->db->join ( 'tbl_salesmanreg as tbl_salesmanreg', 'tbl_salesmanreg.salesmanid = tbl_salesproduct.salesman_id' );
		$this->db->join ( 'tbl_merchant as tbl_merchant', 'tbl_merchant.merchant_id = tbl_salesproduct.merchant_id' );
		$result=$this->db->get();
       		$rows=$result->result();
			//echo $result;
		//$result = $this->db->get()->result(); 
		
		    //$this->db->from ( 'tbl_salesmanreg' );
			//$this->db->group_by('salesmanid');
		//	$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesmanreg.area' );
		$html='';
						$debitcount=0;
						$debitamt=0;
						$creditcount=0;
						$creditamt=0;
						$cashamt=0;
						$chequeamt=0;
						$totalamt=0;
				if($result->num_rows() > 0)
				{
						//$html.='<td></td>';
						$i=1;
						$debitcount=0;
						$debitamt=0;
						$creditcount=0;
						$creditamt=0;
						$cashamt=0;
						$chequeamt=0;
						$totalamt=0;
					foreach($rows as $val =>$key)
					{
						$totalamt=$totalamt+$key->totalamount;
						$mode="";
						if($key->mode==1)
						{
							$mode="Cr";
							$creditcount=$creditcount+1;
							$creditamt=$creditamt+$key->totalamount;
						}
						else{
							$mode="Dr";
							$debitcount=$debitcount+1;
							$debitamt=$debitamt+$key->totalamount;
						}
						$type="";
						if($key->type==1)
						{
							$type="Cash";
							$cashamt=$cashamt+$key->totalamount;
						}
						else if($key->type==2){
							$type="Check";
							$chequeamt=$chequeamt+$key->totalamount;
						}
						$html.='<tr><td>'.$i.'</td>';
						$html.='<td>'.$key->name.'</td>';
						$html.='<td>'.$key->merchantname.'</td>';
						$html.='<td>'.$key->totalamount.'</td>';
						
						
						$i=$i+1;
					}
				}else{
					$html.='<td>- No result -</td>';
						}
						if($totalamt==0){
							//$html.='<td>-- No result  --</td>';
							echo $html.'--Credit Amount:'.$creditamt.'--Debit Amount:'.$debitamt.'--Cash Amount:'.$cashamt.'--Cheque Amount:'.$chequeamt.'--Total Amount:'.$totalamt;
							}
							else{
			echo $html.'--Credit Amount:'.$creditamt.'--Debit Amount:'.$debitamt.'--Cash Amount:'.$cashamt.'--Cheque Amount:'.$chequeamt.'--Total Amount:'.$totalamt;
							}
		}  
		
			public function getdetailsbydate(){
				
				
				$date=$this->input->post('date');
		 $array=array('tbl_salesproduct.status'=>0,'tbl_salesproduct.create_date'=>$date);
		$this->db->where($array);
		$this->db->select('tbl_salesproduct.*,tbl_salesmanreg.salesmanid,tbl_salesmanreg.name,tbl_merchant.merchant_id,tbl_merchant.merchantname,');
		$this->db->from('tbl_salesproduct');
		//$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesproduct.area' );
		$this->db->join ( 'tbl_salesmanreg as tbl_salesmanreg', 'tbl_salesmanreg.salesmanid = tbl_salesproduct.salesman_id' );
		$this->db->join ( 'tbl_merchant as tbl_merchant', 'tbl_merchant.merchant_id = tbl_salesproduct.merchant_id' );
		$result=$this->db->get();
       		$rows=$result->result();
			//echo $result;
		//$result = $this->db->get()->result(); 
		
		    //$this->db->from ( 'tbl_salesmanreg' );
			//$this->db->group_by('salesmanid');
		//	$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesmanreg.area' );
		$html='';
		$debitcount=0;
						$debitamt=0;
						$creditcount=0;
						$creditamt=0;
						$cashamt=0;
						$chequeamt=0;
						$totalamt=0;
				if($result->num_rows() > 0)
				{
					
						//$html.='<td></td>';
							$i=1;
							$debitcount=0;
						$debitamt=0;
						$creditcount=0;
						$creditamt=0;
						$cashamt=0;
						$chequeamt=0;
						$totalamt=0;
					foreach($rows as $val =>$key)
					{
						$totalamt=$totalamt+$key->totalamount;
						$mode="";
						if($key->mode==1)
						{
							$mode="Cr";
							$creditcount=$creditcount+1;
							$creditamt=$creditamt+$key->totalamount;
						}
						else if($key->mode==2){
							$mode="Dr";
							$debitcount=$debitcount+1;
							$debitamt=$debitamt+$key->totalamount;
						}
						$type="";
						if($key->type==1)
						{
							$cashamt=$cashamt+$key->totalamount;
							$type="Cash";
						}
						else if($key->type==2){
							$chequeamt=$chequeamt+$key->totalamount;
							$type="Check";
						}
						$html.='<tr><td>'.$i.'</td>';
						$html.='<td>'.$key->name.'</td>';
						$html.='<td>'.$key->merchantname.'</td>';
						$html.='<td>'.$key->totalamount.'</td>';
						
						
						$i=$i+1;
					}
				}else{
					$html.='<td>- No result  -</td>';
						}
						if($totalamt==0){
							//$html.='<td>-- No result  --</td>';
							echo $html.'--Credit Amount:'.$creditamt.'--Debit Amount:'.$debitamt.'--Cash Amount:'.$cashamt.'--Cheque Amount:'.$chequeamt.'--Total Amount:'.$totalamt;
							}
							else{
			echo $html.'--Credit Amount:'.$creditamt.'--Debit Amount:'.$debitamt.'--Cash Amount:'.$cashamt.'--Cheque Amount:'.$chequeamt.'--Total Amount:'.$totalamt;
							}
			
		
				
				}
	
		public function getdetailsbyarea(){
				
				
				$area=$this->input->post('area');
				 $array=array('tbl_salesproduct.status'=>0,'tbl_salesproduct.area_id'=>$area);
		$this->db->where($array);
		$this->db->select('tbl_salesproduct.*,tbl_salesmanreg.salesmanid,tbl_salesmanreg.name,tbl_merchant.merchant_id,tbl_merchant.merchantname,');
		$this->db->from('tbl_salesproduct');
		//$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesproduct.area' );
		$this->db->join ( 'tbl_salesmanreg as tbl_salesmanreg', 'tbl_salesmanreg.salesmanid = tbl_salesproduct.salesman_id' );
		$this->db->join ( 'tbl_merchant as tbl_merchant', 'tbl_merchant.merchant_id = tbl_salesproduct.merchant_id' );
		$result=$this->db->get();
       		$rows=$result->result();
		/* $array=array('tbl_cashcollect.status'=>0,'tbl_cashcollect.area_id'=>$area);
		$this->db->where($array);
		$this->db->select('tbl_cashcollect.*,tbl_salesmanreg.salesmanid,tbl_salesmanreg.name,tbl_merchant.merchant_id,tbl_merchant.merchantname,');
		$this->db->from('tbl_cashcollect');
		//$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesproduct.area' );
		$this->db->join ( 'tbl_salesmanreg as tbl_salesmanreg', 'tbl_salesmanreg.salesmanid = tbl_cashcollect.salesman_id' );
		$this->db->join ( 'tbl_merchant as tbl_merchant', 'tbl_merchant.merchant_id = tbl_cashcollect.merchant_id' );
		$result=$this->db->get();
       		$rows=$result->result();*/
			
		$html='';
		$debitcount=0;
						$debitamt=0;
						$creditcount=0;
						$creditamt=0;
						$cashamt=0;
						$chequeamt=0;
						$totalamt=0;
				if($result->num_rows() > 0)
				{
						//$html.='<td></td>';
							$i=1;
							$debitcount=0;
						$debitamt=0;
						$creditcount=0;
						$creditamt=0;
						$cashamt=0;
						$chequeamt=0;
						$totalamt=0;
					foreach($rows as $val =>$key)
					{
						$totalamt=$totalamt+$key->totalamount;
						$mode="";
						if($key->mode==1)
						{
							$mode="Cr";
							$creditcount=$creditcount+1;
							$creditamt=$creditamt+$key->totalamount;
						}
						else if($key->mode==2){
							$mode="Dr";
							$debitcount=$debitcount+1;
							$debitamt=$debitamt+$key->totalamount;
						}
						$type="";
						if($key->type==1)
						{
							$cashamt=$cashamt+$key->totalamount;
							$type="Cash";
						}
						else if($key->type==2){
							$chequeamt=$chequeamt+$key->totalamount;
							$type="Check";
						}
						$html.='<tr><td>'.$i.'</td>';
						$html.='<td>'.$key->name.'</td>';
						$html.='<td>'.$key->merchantname.'</td>';
						$html.='<td>'.$key->totalamount.'</td>';
						
						
						$i=$i+1;
					}
				}else{
					$html.='<td>- No result  -</td>';
						}
						if($totalamt==0){
							//$html.='<td>-- No result  --</td>';
							echo $html.'--Credit Amount:'.$creditamt.'--Debit Amount:'.$debitamt.'--Cash Amount:'.$cashamt.'--Cheque Amount:'.$chequeamt.'--Total Amount:'.$totalamt;
							}
							else{
			echo $html.'--Credit Amount:'.$creditamt.'--Debit Amount:'.$debitamt.'--Cash Amount:'.$cashamt.'--Cheque Amount:'.$chequeamt.'--Total Amount:'.$totalamt;
							}
		
		
				
				}
	public function getdetailsbymid(){
				
				
				$mid=$this->input->post('mid');
		 $array=array('tbl_salesproduct.status'=>0,'tbl_salesproduct.merchant_id'=>$mid);
		$this->db->where($array);
		$this->db->select('tbl_salesproduct.*,tbl_salesmanreg.salesmanid,tbl_salesmanreg.name,tbl_merchant.merchant_id,tbl_merchant.merchantname,');
		$this->db->from('tbl_salesproduct');
		//$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesproduct.area' );
		$this->db->join ( 'tbl_salesmanreg as tbl_salesmanreg', 'tbl_salesmanreg.salesmanid = tbl_salesproduct.salesman_id' );
		$this->db->join ( 'tbl_merchant as tbl_merchant', 'tbl_merchant.merchant_id = tbl_salesproduct.merchant_id' );
		$result=$this->db->get();
       		$rows=$result->result();
			
		$html='';
		$debitcount=0;
						$debitamt=0;
						$creditcount=0;
						$creditamt=0;
						$cashamt=0;
						$chequeamt=0;
						$totalamt=0;
				if($result->num_rows() > 0)
				{
						//$html.='<td></td>';
							$i=1;
							$debitcount=0;
						$debitamt=0;
						$creditcount=0;
						$creditamt=0;
						$cashamt=0;
						$chequeamt=0;
						$totalamt=0;
					foreach($rows as $val =>$key)
					{
						$totalamt=$totalamt+$key->totalamount;
						$mode="";
						if($key->mode==1)
						{
							$mode="Cr";
							$creditcount=$creditcount+1;
							$creditamt=$creditamt+$key->totalamount;
						}
						else if($key->mode==2){
							$mode="Dr";
							$debitcount=$debitcount+1;
							$debitamt=$debitamt+$key->totalamount;
						}
						$type="";
						if($key->type==1)
						{
							$cashamt=$cashamt+$key->totalamount;
							$type="Cash";
						}
						else if($key->type==2){
							$chequeamt=$chequeamt+$key->totalamount;
							$type="Check";
						}
						$html.='<tr><td>'.$i.'</td>';
						$html.='<td>'.$key->name.'</td>';
						$html.='<td>'.$key->merchantname.'</td>';
						$html.='<td>'.$key->totalamount.'</td>';
						$i=$i+1;
					}
				}else{
					$html.='<td>- No result  -</td>';
						}
						if($totalamt==0){
							//$html.='<td>-- No result  --</td>';
							echo $html.'--Credit Amount:'.$creditamt.'--Debit Amount:'.$debitamt.'--Cash Amount:'.$cashamt.'--Cheque Amount:'.$chequeamt.'--Total Amount:'.$totalamt;
							}
							else{
			echo $html.'--Credit Amount:'.$creditamt.'--Debit Amount:'.$debitamt.'--Cash Amount:'.$cashamt.'--Cheque Amount:'.$chequeamt.'--Total Amount:'.$totalamt;
							}
		
				
				}
}