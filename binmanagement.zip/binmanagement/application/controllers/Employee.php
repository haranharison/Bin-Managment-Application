<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Employee_model','model');
	 }	
	 public function index()
	{
		//$data['area']=$this->model->getarea();
		$data['employee']=$this->model->getemployeelist();
		$headdata['menu']='organization';
		$headdata['submenu']='employee';
		$this->load->view('admin/header',$headdata);
		$this->load->view('admin/employee/employeelist',$data);
		$this->load->view('admin/footer');
	}
	
	 public function addemployee()
	{
		$data['employee']=$this->model->getemployee();
		$data['designation']=$this->model->getdesig();
		$data['edu']=$this->model->geteducation();
		$data['usergroup']=$this->model->getusergroup();
		$data['area']=$this->model->getarea();	
		$data['menu']='organizer';
		$data['submenu']='employeereg';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/employee/employeeregistration',$data);
		$this->load->view('admin/footer');
		
	}
	public function inserteducation(){
		$this->model->addeducation();	
	}
	public function insertdesig(){
		$this->model->adddesi();
		}
	public function getdesig(){
		$this->model->getdesig();
		
	}
	public function getdesignation(){
		$this->model->getdesignation();
		
	}
	public function geteducation(){
		$this->model->geteducation();
		}
		public function geteducation1(){
		$this->model->geteducation1();
		}
	 public function employeereg()
	{
		
		$this->model->addemployee();	
		
	}
		public function employeeedit($id=false)
	
	{ // editSalesmanregvar_dump($id);
	//$data['editsalesman']=	$this->model->editSalesmanreg($id);
	$data['edu']=$this->model->geteducation();
	$data['allemployee']=$this->model->getemployee();
	$data['usergroup']=$this->model->getusergroup();
	$data['employee']=$this->model->getemployeebyid($id);
	$data['employeearea']=$this->model->getemployeearea($id);
	$data['emplyedu']=$this->model->getemployedu($id);
	$data['emplyverifi']=$this->model->getemployveri($id);
	$data['desig']=$this->model->getdesig($id);
	$data['designation']=$this->model->getdesig();
	$data['menu']='organizer';
	$data['submenu']='employeereg';
	//var_dump($datas['salesmans']);
	$data['area']=$this->model->getarea();
		$headdata['menu']='organizer';
		$headdata['submenu']='employeereg';
		$this->load->view('admin/header',$headdata);
		$this->load->view('admin/employee/editemployeeregistration',$data);
		$this->load->view('admin/footer');
	}
	
	
	 public function upemployeereg()
	{
		
			$this->model->upemployeereg();
		
	}
		public function deleteEmployee(){
		//echo $id;
		$this->model->deleteEmployee();
		}
/*	public function salesmanproductsadd()
	{
		
		$data['salesman']=$this->model->getsalesmanid();
		$data['productcat']=$this->model->getcategory();
		//var_dump($data['productcat']);
		$this->load->view('admin/header');
		$this->load->view('admin/salesman/salesmanproductsadd ',$data);
		$this->load->view('admin/footer');
	}
	public function getsubcategorybycategoryid()
	{ //fetching sucbcategory by category 
		$this->model->getsubcategorybycategoryid();
		
	}
	public function getproductsbysubcategoryid()
	{ //fetching products by sucbcategory 
		$this->model->getproductsbysubcategoryid();
		
	}
	public function addsalesmanproduct()
	{ //add salesman product
		$this->model->addsalesmanproduct();
		
	}*/

/*	public function editsalesmanproducts($id=false)
	{ 
	$data['salesman']=$this->model->getsalesmanprobyid($id);
	$data['salesmancat']=$this->model->getsalesmancatbyid($id);
	$data['salesmansubcat']=$this->model->getsalesmansubcatbyid($id);
	    $data['salesmanid']=$id;
		$data['productcat']=$this->model->getcategory();
		$data['productsubcat']=$this->model->getsubcategory();
		$data['products']=$this->model->getproducts($data['salesmansubcat'][0]);
		$this->load->view('admin/header');
		$this->load->view('admin/salesman/editsalesmanproducts',$data);
		$this->load->view('admin/footer');
	}
	 public function upsalespro()
	{
		
			$this->model->upsalespro();
		
	}*/

}
