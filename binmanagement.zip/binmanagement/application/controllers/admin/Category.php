<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->load->model('Category_model','model');
	 }	
	 public function index()
	{
		$data['category']=$this->model->getcategory();
		$data['menu']='organizer';
		$data['submenu']='category';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/category/categoryadd',$data);
		$this->load->view('admin/footer');
	}
	
	public function addcategory(){
	$this->model->addcategory();	
	}
	public function editCategories($id=false){
		$data['edit']=$this->model->editcategory($id);
		$this->load->view('admin/header');
		$this->load->view('admin/category/edit',$data);
		$this->load->view('admin/footer');
		}
		
	public function updatecategory(){
		$this->model->updatecategory();	
	}

	public function deleteCategories(){
		//echo $id;
		$this->model->deleteCategories();
		}
	
/*	public function deleteCategories($id=false){
		//echo $id;
		$this->model->deleteCategories($id);
		}*/
//product edit page
}

