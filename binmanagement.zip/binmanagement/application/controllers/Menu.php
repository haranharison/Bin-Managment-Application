<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
	$this->load->model('Menu_model','model');
	 }	
	 public function index()
	{
		$data['mainmenu']=$this->model->getmainmenu();
		$data['menu']=$this->model->getmenu();
		$this->load->view('admin/header');
		$this->load->view('admin/menu/menuadd',$data);
		$this->load->view('admin/footer');
	}
	
	public function addmenu(){
	$this->model->addmenu();	
	}
	public function editCategories($id=false){
		$data['edit']=$this->model->editcategory($id);
		$this->load->view('admin/header');
		$this->load->view('admin/category/edit',$data);
		$this->load->view('admin/footer');
		}
		
	public function updatemenu(){
		$this->model->updatemenu();	
	}

	public function deleteMenu(){
		
		$this->model->deleteMenu();
		}
	
/*	public function deleteCategories($id=false){
		//echo $id;
		$this->model->deleteCategories($id);
		}*/
//product edit page
	
}

