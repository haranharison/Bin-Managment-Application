<?php
class Salesmanprofile_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
      
	 public function Salesmanprofile(){
		 
		
		 $sid=$this->input->post('salesmanid');
		 $array=array('tbl_salesmanreg.status'=>0,'tbl_salesmanreg.salesmanid'=>$sid);
	
		$this->db->where($array);
	//$this->db->group_by('tbl_merchant.merchant_id');
		$this->db->select('tbl_salesmanreg.*,tbl_area.area_id,tbl_area.area_name');
		$this->db->from('tbl_salesmanreg');

		$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesmanreg.area' );
		 $result = $this->db->get()->result(); 
			
			$this->output->set_output(json_encode($result));	
		}  
	  
	  
	  public function alllocation(){
		 
		// $sid=$this->input->post('salesmanid');
	 $array=array('tbl_merchant.status'=>0);
	
		$this->db->where($array);
	//$this->db->group_by('tbl_merchant.merchant_id');
		$this->db->select('tbl_merchant.*,tbl_area.area_id,tbl_area.area_name');
		$this->db->from('tbl_merchant');

		$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_merchant.location' );
		 $result = $this->db->get()->result(); 
			
			$this->output->set_output(json_encode($result));	
		}  
	  
	  
	  
	  
	 public function routehistory(){
		$today= date("y-m-d");
		$time = strtotime($today);
		$newformat = date('H:i:s',$time);
			//	$max=maxplus('tbl_cashcollect','cashcollect_id');
		
		$latitude=$this->input->post('latitude');
		$longitude=$this->input->post('longitude');
		$username=$this->input->post('username');
		$data= array(
		    
				'latitude'=>$latitude,
			    'longitude'=>$longitude,
			    'username'=>$username,
				'create_time'=>$newformat,
			    'create_date'=>$today,
			    'modify_date'=>$today
		);
		$this->db->insert('tbl_routehistory',$data);
		 
		 }  
	  
	  
	  
	    
}