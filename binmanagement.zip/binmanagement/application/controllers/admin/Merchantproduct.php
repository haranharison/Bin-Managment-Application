<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Merchantproduct extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->load->model('Merchantproduct_model','model');
	 }	public function index()
	{
		$this->load->view('admin/header');
		$this->load->view('admin/merchant/merchantproductadd');
		$this->load->view('admin/footer');
	}
}
