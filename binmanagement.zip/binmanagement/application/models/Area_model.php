<?php
class Area_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        
		public function getarea()
		{
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_area')->result();
		}
		
		public function addarea()
		{
						$exist=fieldexist('tbl_area','area_name',$this->input->post('addarea'),'org_id',$this->session->userdata('org_id'));
	if($exist==1){
		echo 1;
	}else{
			$max=maxplus('tbl_area','area_id');
		$today= date("y-m-d");
		$area=$this->input->post('addarea');
		$latitude=$this->input->post('latitude');
		$longitude=$this->input->post('longitude');
		$data= array(
		'org_id'=>$this->session->userdata('org_id'),
			'area_id' =>$max,
		       'area_name'=>$area,
			   'latitude'=>$latitude,
			    'longitude'=>$longitude,
			   'create_date'=>$today,
			   'modify_date'=>$today
		);
		$this->db->insert('tbl_area',$data);
		}
		}	
		public function editArea($id){
			$cid=decode($id);
				$array=array('area_id'=>$cid,'status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_area')->row();
			}
			
			public function updatearea()
			{
				$cid=decode($this->input->post('txthiden'));
				$area=$this->input->post('addarea');
				$latitude=$this->input->post('latitude');
				$longitude=$this->input->post('longitude');
				$today= date("y-m-d");
		
				   $data=array(
				    'area_name'=>$area,
					'latitude'=>$latitude,
					'longitude'=>$longitude,
			   'create_date'=>$today,
			   'modify_date'=>$today
				   
				   
				   );
		   $array= array('area_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_area',$data);
			}
			
			  public function deleteArea(){
				  
		 	$cid=decode($this->input->post('id'));
		   $data=array('status'=>1);
		   $array= array('area_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_area',$data);
		   }
	
}