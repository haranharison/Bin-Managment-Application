
 <!--breadcrumbs start-->
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.0/sweetalert2.min.css" />
 <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.0/sweetalert2.min.js"></script>-->
 <style>
 	
 </style>
          <div id="breadcrumbs-wrapper">
            <!-- Search for small screen -->
            <div class="header-search-wrapper grey lighten-2 hide-on-large-only">
              <input type="text" name="Search" class="header-search-input z-depth-2" placeholder="Explore Materialize">
            </div>
            <div class="container">
              <div class="row">
                <div class="col s10 m6 l6">
                  <h5 class="breadcrumbs-title">Payment Bank List <?php // echo encode(1) ?></h5>
                  <ol class="breadcrumbs">
                    <li><a href="<?php echo ADMIN_PATH?>index/home">Dashboard</a>
                    </li>
                    <li><a href="#">Bank</a>
                    </li>
                  </ol>
                </div>
                
              </div>
            </div>
          </div>
          <!--breadcrumbs end-->

<!--start container-->
          <div class="container">
            <div class="section">
              <!-- Form with placeholder -->
              <div id="basic-form" class="section">
                <div class="row">
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2" style="letter-spacing:1">Bank Name</h4>
                      <div class="row">
                       <form role="form" name="frmncat" action="" id="frm-inp-bank" method="post">
                          <div class="row">
                            <div class="input-field col s12">
                              <input autofocus="autofocus" name="txtbankname" id="txtpbank" type="text">
                              <label for="first_name">Enter Bank name</label>
                            </div>
                          </div>
                          
                          
                          <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right"  type="button" name="action" id="btnsubmit">Add Bank
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                <!--Basic Form-->  
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Bank Names</h4>
                      <div class="row">
                        <table id="datatable" class="display" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:20px;text-align:center;">SN</th>
                          <th>Bank Names</th>
                          <th style="width:75px"></th>
                          
                        </tr>
                      </thead>
                      <tbody id="append-bank-data">
                      		 <?php  if($bank) { $i=1; foreach($bank as $val  ){ ?>
							<tr>
								<td style="width:20px;text-align:center;"><?php  echo $i ?></td>
								<td ><?php  echo $val->b_bname?> </td>
								<td style="width:75px"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan btnedit"  data-id="<?php  echo encode($val->b_uid); ?>"><i class="material-icons">mode_edit</i>	</a>
									<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php  echo encode($val->b_uid)?>" href="javascript:void(0)">	<i class="material-icons">delete</i></a>
                                </td>
							</tr>
					<?php  $i=$i+1;}}?>
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
<style>

</style>            
        
          </div>
        </section>
        <div class="reload-alert">Reload for changes</div>    
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

  
<script type="text/javascript">

$(document).ready(function(e) {
   	//------insert -------------//
       	 $("#btnsubmit").click(function(ev) {
			var data=$('#frm-inp-bank').serialize();
			var e=validation();
			if(e==0){
				$.ajax({
					type:'POST',
					url:"<?php  echo ADMIN_PATH?>Bank/addbank",
					data:data,
					success: function(data){
						if(data!=1){swal("Sucessfully!", "Sucessfully Added!", "success"); setTimeout(function(){location.reload()},600);}
						else{swal("Name Alreadt Exist!", "Exist!", "error");}
					}
				});//AJAX End
			}
   			});
	//----end insert--------------------//	
	function validation(){
        error=0;
		$('label').removeClass('labelerror');
        $('input').removeClass('errors');
      //  $('input').removeClass('errorInput');
        $('select').removeClass('errors');
     //   $('select').removeClass('errorInput');
        var values = {'bank':$('#txtpbank').val()}
        if(values.bank == ''){
			$('#txtpbank').parent().children('label').addClass('labelerror');
            $('#txtpbank').addClass('errors');
            $('#txtpbank').attr("placeholder", "Please enter Bank Name.")
            error=1;
        } 
        return error;
    }
/*----------------------------------------------------------------------------------------------------------------------------------------------------*/
	// ---------- < Delete bank Name   > ---------- //
$(document).on('click', '.btndlt', function(){
	$btn=$(this);
	$tr=$btn.parent().parent();
	var encryid=$(this).attr('rel');  
	swal({
  title: "Are you sure?",
  text: "Your will not be able to recover this Data!",
  type: "warning",
  showCancelButton: true,
  confirmButtonClass: "btn-danger",
  confirmButtonText: "Yes, delete it!",
  customClass: 'swal-delete',
  cancelButtonText: "No, cancel!",
  
}).then(function(){
$.ajax( {
    type:"post", 
	url: "<?php echo ADMIN_PATH ?>bank/deletebank", 
	data:"id="+encryid, 
	success:function(data) {
       // swal( 'Success!', 'Data has been Deleted', 'success');
						   swal({
					  title: 'Success!',
					  text: "Data has been Deleted",
					  type: 'success',
					  confirmButtonColor: '#3085d6',
					  confirmButtonText: ' Ok !'
					}).then(function () {
					  $tr.remove();
					  setTimeout(function(){$('.reload-alert').show().addClass('active');},600)
					})
			
        //	location.reload() ;
    }
});
			});
			/*
function(isConfirm) {
  if (isConfirm) {
	  alert(0)
	  $.ajax({
                    type:"post",
					url: "<?php  echo ADMIN_PATH ?>bank/deletebank",
					data:"id="+id,
					success:function(data){ 
					alert(data);
								swal("Sucessfully!", "Sucessfully Deleted!", "success");
								location.reload() ;
          						}
						});//AJAX END
  //  swal("Deleted!", "Your imaginary file has been deleted.", "success");
  } 
  else {
    swal("Cancelled", "Your imaginary file is safe :)", "error");
}*/

});
// ---------- < Delete Category ENDS > ---------- //
		
$(document).on('click', '.btnedit', function(){	
	var eid=$(this).attr('data-id');
	var name='';
	getval();
	function getval(){
			$.ajax({
				type:"post",
				url: "<?php echo ADMIN_PATH ?>bank/getbdetails",
				data:"eid="+eid,
				success:function(data){  
					name=data;
					updateform()
					}
			 });
		}
	function updateform(){
		  					//  var name=$("#ad").val();
				swal({
						  title: 'Edit Bank Name',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input role="bank-name-content" autofocus="autofocus" placeholder="Enter Bank Name" name="txtpbank" spellcheck="false" id="txtnewbank" type="text" value="'+name+'" ><label for="first_name">Bank Name</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Update',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var bankname=$("#txtnewbank").val();
									console.log(bankname)
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors');
									if(bankname==''){
											$('#txtnewbank').parent().children('label').addClass('labelerror');
											$('#txtnewbank').addClass('errors');
											$('#txtnewbank').attr("placeholder", "Please enter Bank Name.");
										err=1;
										}
									return err;	
							}
								if(ev==0){
									console.log(bankname)
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>bank/updatebank",
														data:"bankname="+bankname+"&eid="+eid,
														success:function(data){  
																resolve();	  
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
									swal({
		  title: '<div class="tst" >Update</div>',
		  html:'<div class="tst1" >Date Updated</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
		setTimeout(function(){
			location.reload() ;
			},600)
		
			 
			  	});
	}
	});
	});
</script>


    
    
    
    
    
    
    
    
    

