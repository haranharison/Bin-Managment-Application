

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2"> Organisation Permission</h4>
                      <div class="row">
                       <form role="form" name="frmaddgroup" action="" method="post">
                          <div class="row">
                            <div class="input-field col s12">
                               <label for="first_name"> Organisation Permission</label>
                            <!--  <input placeholder="Enter Usergroup" name="group" id="group" type="text">-->
                            </div>
                            </div>
                              <input type="hidden" name="txtid" id="txtid" />
                             <div class="row">
                            <div class="input-field col s12">
                               <select multiple="multiple" id="selper" name="selper">
                             
                                <option disabled="disabled" value="0">Choose permission....</option>  
                                <option value="1">Category</option>
                                <option value="2">Sub Category</option>
                                 <option value="3">Manufacture</option>
                                 <option value="4">Tax Type</option>
                                 <option value="5">UOM ( Unit of Measurement)</option>
                                  <option value="6">User Group</option> 
                                   <!--<option value="7">Employee Registration</option> -->
                            	  <option value="9"> Education </option>
                           		   <option value="10"> Designation </option>
                            	  <option value="11">Product List</option>
                         	      <option value="12">New Product</option>
                          	      <option value="13">Area</option>
                          	 	   <option value="14">Employee List</option>
                                   <option value="15">Bin Management</option>
                                   <option value="16">Register Bin</option>
                                   <option value="17">Register Returns </option>
                                   <option value="18">View bin report </option>
                                   <option value="19">View return stocks </option>
                                   <option value="20">View current return stock </option>
                                   <option value="21">Absence report</option>
                                   <option value="22">Report Absence </option>
                                   <option value="23"> View shifts </option>
                                   <option value="24"> Download shift sheet  </option>
                                   <option value="25">  Employee Management  </option>
                                   <option value="26">  Register employees  </option>
                                   <option value="27">  Assign shift   </option>
                                   <option value="28">  Notification   </option>
                                   
                          		 <!-- <option value="16">Merchant List</option>
                        	    <option value="17">New Merchant </option>
                         	   <option value="18">Attendance</option>
                         		   <option value="19">Sales</option>
                         	    <option value="20">Enquiry Form </option>-->
                         	   <!--<option value="21">Service Return </option>
                         	   <option value="22">Cash Collection</option>
                           <option value="23">Date Vice Sales Report</option>-->
                           <!-- <option value="24">Date Vice Collection Report</option>
                             <option value="25">Employee Vice Sales Report</option>
                              <option value="26">Employee Vice Collection Report</option>
                               <option value="27">My Sales Report</option>-->
                                <!--<option value="28">My Collection Report</option>
                                 <option value="29">Current Location</option>
                                  <option value="30">Route History</option>
                                      <option value="31">service</option>
                              <option value="32">Advertisement</option>-->
                         
                         <!--note:-->
                            
                               
                              <!-- <option value="34">Service Amenity</option>
                               <option value="35">Service Terms & Condition</option>
                               <option value="36">Service Jobs</option>
                               <option value="37">Service User Registration</option>
                               <option value="38">Driver Assigning</option>
                               <option value="39">Sms Settings</option>
                                <option value="40">Fare Settings</option>
                                 <option value="41">Trip Sheet</option>-->
                              
                              
                                 </select>
                                   <input type="hidden" name="txthper" id="txthper" />
                           
                            </div>
                          </div>
                         <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnsubmit">Submit
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  <div class="col s12 m6 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Organisations</h4>
                      <div class="row">
						
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
						  <thead>
							  <tr class="text-center">
								  <th style="width:50px;">Sl.no</th>
								 <!-- <th>Shop name</th>-->
                                   <th style="text-align:left;">Organisation name</th>
                                    <th style="text-align:left;">Action</th>
								  <!--<th>Edit</th>
                                  
                                  <th>Delete</th>-->
							  </tr>
						  </thead>   
						  <tbody>
                          
                          
                           <?php  if($allorg) { $i=1; foreach($allorg as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:50px;text-align:center;"><?php echo $i ?></td>
                                    	<td style="text-align:left;"><?php echo $val->org_name?> </td>
								      <td  style="width:100px;text-align:right;">
								
									<a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH?>Organisation/orgedit/<?php echo encode($val->org_maxid);?>">
										<i class="material-icons">mode_edit</i>
									</a>
                               
									<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange btndlt"  id="btndelt"rel="<?php echo encode($val->org_maxid);?>">
										<i class="material-icons">delete</i>
									</a>
								</td>
							</tr>
					<?php $i=$i+1;}}?>
							
						
							
							
						  </tbody>
					  </table>   
						
								
								
							
						
				</div>
                    </div>
                  </div>
                  <!-- Form with placeholder -->
                  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->





<script type="text/javascript">

$(document).ready(function(e) {
	
   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			//alert(1);
				$('#txthper').val($('#selper').val());
			var e=validation();
			if(e==0){
				$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>department/updatepermission";
  			var redirect = "<?php echo ADMIN_PATH?>department";
  			var form = document.forms.namedItem("frmaddgroup");                        
			var oData = new FormData(document.forms.namedItem("frmaddgroup"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) {//console.log(oReq.responseText);
					$('.overlay').css({'display':'none'});
				 if(oReq.responseText==1){
					// alert("Exist");
					customSwalFunD(" Already Exist!", "Exist!", "error")
					  //alert("Exist");
					 }
					 else
					 {
						 customSwalFunD("Sucessfully!", "Permission Added!", "success")
 				 document.location = redirect;
					 }
					
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	/*$('label').removeClass('labelerror');
$('#txttax').parent().children('label').addClass('labelerror');
*/	function validation(){

        error=0;

        $('input').removeClass('errors');
		$('label').removeClass('labelerror');
        $('select').removeClass('errors');

            var values = {
                                    'per':$('#selper').val(),
                                 }

       if(values.per == 0){
			 $('#selper').parent().children('.select-dropdown').addClass('errors');
			$('#selper').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
	
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmncat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
	
	
	
	// ---------- < Delete Category   > ---------- //
	
	   $(document).on('click', '#btndelt', function(){
                var id=$(this).attr('rel');  
 swal({
                             title: "Are you sure?",
							   text: "Delete this organisation",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:"swal-delete",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          }).then(function(){
						  
			$('.overlay').css({'display':'flex'});
			//alert(id);
                                        $.ajax({

                                            type:"post",
                        					url: "<?php echo ADMIN_PATH ?>Organisation/deleteorganisation",
                                            data:"id="+id,
                                            success:function(data){//alert(data);
											$('.overlay').css({'display':'none'});	
											document.location = "<?php echo ADMIN_PATH?>Organisation";
											customSwalFunD("Sucess", "Sucessfully deleted!", "success")
                                            }
                                        });
				          });
			  
        });
		// ---------- < Delete Category ENDS > ----------
	
});
</script>
  
    





    
    
    
    
    
    
    
    
    

