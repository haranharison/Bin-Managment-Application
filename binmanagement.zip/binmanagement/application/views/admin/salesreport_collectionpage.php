	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Icons</li>
			</ol>
		</div><!--/.row-->
		
        
        
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Sales report</h1>
			</div>
		</div><!--/.row-->
				
		
        <div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Sales report</div>
					<div class="panel-body">
						<div class="col-md-6">
							<form role="form" name="frmopeningbalance" id="frmopeningbalance" action="" method="post">
							
<fieldset>
							  	 <div class="form-group">
									
									<select class="form-control form-control1" name="selsalesman" id="selsalesman">
                                    	<option value="0"> Salesman</option>
                                        
											  <?php foreach($salesman as $val){?>
											<option value="<?php echo $val->salesmanid?>"><?php echo $val->name?></option>
											
											<?php }?>
											
											
										
										
									</select>
			<!--<span id="cater" style="color:red; display:none;">errors</span>-->
            					</div>
                                	<div class="form-group">
								<input class="form-control " placeholder="Date" name="txtdate" id="txtdate" type="date" >
							</div>
							
                            <div class="form-group">
									
									<select class="form-control form-control1" name="selarea" id="selarea">
                                    	<option value="0"> Location</option>
                                        
											<?php foreach($area as $val){?>
											<option value="<?php echo $val->area_id?>"><?php echo $val->area_name?></option>
											
											<?php }?>
											
											
										
										
									</select>
			<!--<span id="cater" style="color:red; display:none;">errors</span>-->
            					</div>
                                <div class="form-group">
									
									<select class="form-control form-control1" name="selmerchant" id="selmerchant">
                                    	<option value="0"> Merchant</option>
                                        
											<?php foreach($merchant as $val){?>
											<option value="<?php echo $val->merchant_id?>"><?php echo $val->merchantname?></option>
											
											<?php }?>
											
											
										
										
									</select>
			<!--<span id="cater" style="color:red; display:none;">errors</span>-->
            					</div>
							<!--<div class="col-md-6" >
                              <a href="#" class="btn btn-primary btn-block lg" id="btnsubmit" style="float:right;">Submit</a></div>
                            	<div class="col-md-6">  <a href="" id="btncancel" class="btn btn-default btn-block lg" style="float:left;">Cancel</a></div>-->
                            </fieldset>
								
								
								
							
								
							</form>	
								
								
							
						
					</div>
				</div><style>.detal{color:#fff}</style>
                	 <div class="panel-footer" style="height: 60px;">
                     
                     <div id="dat1" class="col-md-3 detal" style="float:left"></div>
                     <div id="dat2" class="col-md-3 detal" style="float:left"></div>
                     <div id="dat3" class="col-md-3 detal" style="float:left"></div>
                     <div id="dat4" class="col-md-3 detal" style="float:left"></div>
                     <div id="dat5" class="col-md-3 detal" style="float:left;font-size:16px;"></div>
                     </div>
                     </div>
                     </div>
			</div>
        
        
        
        
        
        
        
        
		<div class="row">
			<div class="col-lg-12 Transaction_wrap">
				<div class="panel panel-default">
					<div class="panel-heading">Sales report</div>
					<div class="panel-body">
						<div class="col-md-12">
<table class="table table-striped table-bordered bootstrap-datatable datatable tbl_cat index_table" id="viewcategory">
						 <thead>
						    <tr>
                            <th>Sl No</th>
                            <th>Sales ManName</th>
                           
                            <th>Merchant</th>
                            <th>Amount</th>
                            <th>Mode</th>
                            <th>Type</th>
                            <th>Bank</th>
                            <!--<th>Edit</th>
                            <th>Delete</th>-->
                         </tr>   
						</thead>
						<tbody id="dat">
                       
	                   
                	 <tr  >	<td>1</td>
                 		<td>Aneesh</td>
                  		<td>1345</td>
                   		<td>Sharjahmobile</td>
                        <td>5000 AED</td>
                        <td>cheqce</td>
                        <td>Yes Bank</td>
                        
                 </tr> 
                
                               <tr>
                		<td>2</td>
                 		<td>Mahesh</td>
                  		<td>1346</td>
                   		<td>Sharjahmobile</td>
                        <td>1000 AED</td>
                        <td>cash</td>
                        <td>Yout Bank</td>
                     

                 </tr> 
                       
                   <tr>
                		<td>3</td>
                 		<td>Rajeev</td>
                  		<td>1347</td>
                   		<td>Sharjahmobile</td>
                        <td>10000 AED</td>
                        <td>cheqce</td>
                        <td>Yout Bank</td>
                        

                 </tr> 
             
                 <tr>
                		<td>4</td>
                 		<td>Ramesh</td>
                  		<td>1348</td>
                   		<td>Sharjahmobile</td>
                        <td>500 AED</td>
                        <td>cash</td>
                        <td>Yout Bank</td>
                      

                 </tr> 
                  
				 </tbody>
   </table>
						</div>
				   </div>
                 </div>
                	 <div class="panel-footer"></div>
                     </div>
		</div><!-- /.row -->
	</div><!--/.main-->
<script>
$(document).ready(function() {
    $('#example').DataTable();
} );
						    $(function () {
						        $('#hover, #striped, #condensed').click(function () {
						            var classes = 'table';
						
						            if ($('#hover').prop('checked')) {
						                classes += ' table-hover';
						            }
						            if ($('#condensed').prop('checked')) {
						                classes += ' table-condensed';
						            }
						            $('#table-style').bootstrapTable('destroy')
						                .bootstrapTable({
						                    classes: classes,
						                    striped: $('#striped').prop('checked')
						                });
						        });
						    });
						
						    function rowStyle(row, index) {
						        var classes = ['active', 'success', 'info', 'warning', 'danger'];
						
						        if (index % 2 === 0 && index / 2 < classes.length) {
						            return {
						                classes: classes[index / 2]
						            };
						        }
						        return {};
						    }
		//$(document).ready(function(e) {	
		
		<!---- salesman wise report----->				
$("#selsalesman").change(function(e) {
	
	//alert(1);
	var sid=$( this).val();
	//alert(sid);
			 	$.ajax({
			   	type:"post",
			   	url:"<?php echo ADMIN_PATH;?>salesreport/getdetailsbysid",
			  	data:"sid="+sid,
				success:function(data){
					//alert(data);
					var divs = data.split('--');
					 $( '#dat' ).html( divs[0] );
					  $( '#dat1' ).html( divs[1] );
					   $( '#dat2' ).html( divs[2] );
					    $( '#dat3' ).html( divs[3] );
						$( '#dat4' ).html( divs[4] );
						$( '#dat5' ).html( divs[5] );
					  
					//$("#dat").html(data);
					}		   
			   			});
        });
	//	}
	<!---- date wise report----->				
$("#txtdate").change(function(e) {
	
	//alert(1);
	var date=$( this).val();
	//alert(date);
				$.ajax({
			   	type:"post",
			   	url:"<?php echo ADMIN_PATH;?>salesreport/getdetailsbydate",
			  	data:"date="+date,
				success:function(data){
					//alert(data);
					var divs = data.split('--');
					 $( '#dat' ).html( divs[0] );
					  $( '#dat1' ).html( divs[1] );
					   $( '#dat2' ).html( divs[2] );
					    $( '#dat3' ).html( divs[3] );
						$( '#dat4' ).html( divs[4] );
						$( '#dat5' ).html( divs[5] );
					//$("#dat").html(data);
					}		   
			   			});
        });
		
		<!---- area wise report----->				
$("#selarea").change(function(e) {
	
	//alert(1);
	var area=$( this).val();
	//alert(area);
				$.ajax({
			   	type:"post",
			   	url:"<?php echo ADMIN_PATH;?>salesreport/getdetailsbyarea",
			  	data:"area="+area,
				success:function(data){
					//alert(data);
					//$("#dat").html(data);
					var divs = data.split('--');
					 $( '#dat' ).html( divs[0] );
					  $( '#dat1' ).html( divs[1] );
					   $( '#dat2' ).html( divs[2] );
					    $( '#dat3' ).html( divs[3] );
						$( '#dat4' ).html( divs[4] );
						$( '#dat5' ).html( divs[5] );
					}		   
			   			});
        });
		
			<!---- merchant wise report----->				
$("#selmerchant").change(function(e) {
	
	//alert(1);
	var mid=$( this).val();
	//alert(mid);
				$.ajax({
			   	type:"post",
			   	url:"<?php echo ADMIN_PATH;?>salesreport/getdetailsbymid",
			  	data:"mid="+mid,
				success:function(data){
				//alert(data);
					//$("#dat").html(data);
					var divs = data.split('--');
					 $( '#dat' ).html( divs[0] );
					  $( '#dat1' ).html( divs[1] );
					   $( '#dat2' ).html( divs[2] );
					    $( '#dat3' ).html( divs[3] );
						$( '#dat4' ).html( divs[4] );
						$( '#dat5' ).html( divs[5] );
					}		   
			   			});
        });
						</script>
<script src="js/bootstrap-table.js"></script>                        
 <script src="datatables/DT_bootstrap.js" type="text/javascript"></script>
<script src="datatables/jquery.dataTables.min.js" type="text/javascript"></script>
<?php include("footer.php");?>