<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Department extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Department_model','model');
	 }	
	 public function index()
	{
		$data['allorg']=$this->model->getallorg();
		//$data['usegrp']=$this->model->getusergroup();
		$data['menu']='organization';
		$data['submenu']='vieworglist';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/organisation/vieworganisation',$data);
		$this->load->view('admin/footer');
	}
	public function depregistration()
	{
		$data['usegrp']=$this->model->getusergroup();
		$data['allorg']=$this->model->getallorg();
		$data['auth']=$this->model->getAuthperson();
		$data['menu']='organizer';
		$data['submenu']='orgreg';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/organisation/organisationregistration',$data);
		$this->load->view('admin/footer');
	}
	 public function addorg()
	{
		$this->model->addorg();	
	}
		public function orgedit($id=false)
	{ 
	    $data['usergroup']=$this->model->getusergroup();
	    $data['org']=$this->model->getorgbyid($id);
		$data['auth']=$this->model->getAuthperson();
		$data['allorg']=$this->model->getallorg();
		$data['menu']='organization';
		$data['submenu']='vieworglist';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/organisation/editorganisation',$data);
		$this->load->view('admin/footer');
	}
	public function updateorg()
	{
	$this->model->updateorg();	
	}
	
		public function getorganisation()
	{
	$this->model->getorganisation();	
	}
	
	 public function upemployeereg()
	{
		
			$this->model->upemployeereg();
		
	}
		public function deleteorganisation(){
		//echo $id;
		$this->model->deleteorganisation();
		}
 public function adminselectorg()
	{
		$adorgid=$this->input->post('adorgid');
		$this->session->set_userdata('org_id',$adorgid);
		
	}
	 public function permission()
	{
	//	$data['id']=decode($id);
	$data['allorg']=$this->model->getallorg();
		$data['menu']='organization';
		$data['submenu']='orgreg';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/organisation/orgpermission',$data);
		$this->load->view('admin/footer');
	}
	public function  updatepermission()
	{
		$this->model->updatepermission();
	}
	 public function editpermission($id=false)
	{

		$data['details']=$this->model->getgroupdetails($id);
		$data['allorg']=$this->model->getallorg();
		$data['menu']='organization';
		$data['submenu']='orgreg';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/organisation/orgpermissionedit',$data);
		$this->load->view('admin/footer');
	}
	public function  updatepermission2()
	{
		$this->model->updatepermission2();
	}
	
}
