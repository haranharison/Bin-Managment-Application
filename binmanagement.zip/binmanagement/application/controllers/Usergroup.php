<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usergroup extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Usergroup_model','model');
	 }	
	 public function index()
	{
		$data['group']=$this->model->getgroup();
		$data['menu']='organizer';
		$data['submenu']='usergroup';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/usergroup/groupadd',$data);
		$this->load->view('admin/footer');
	}
	 public function permission()
	{
	//	$data['id']=decode($id);
	$data['group']=$this->model->getgroup();
		$data['menu']='organizer';
		$data['submenu']='usergroup';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/usergroup/grouppermission',$data);
		$this->load->view('admin/footer');
	}
	public function  updatepermission()
	{
		$this->model->updatepermission();
	}
	
	public function  updatepermission2()
	{
		$this->model->updatepermission2();
	}
	
	 public function editpermission($id=false)
	{
	$data['id']=decode($id);
	$data['details']=$this->model->getgroupdetails($id);
	$data['group']=$this->model->getgroup();
		$data['menu']='organizer';
		$data['submenu']='usergroup';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/usergroup/editpermission',$data);
		$this->load->view('admin/footer');
	}
	
	public function  addgroup()
	{
		$this->model->addgroup();
	}
	public function  editgroup($id=false)
	{
		$data['group']=$this->model->getgroup();
		$data['edit']=$this->model->editgroup($id);
		$data['menu']='organizer';
		$data['submenu']='usergroup';
		$this->load->view('admin/header',$data);
		if(empty($data['edit']))
		{
			$data['heading']='Message';
			$data['message']='An uncaught Exception was encountered.Please try again';
			$this->load->view('errors/html/error_general',$data);
		}
		else{
		$this->load->view('admin/usergroup/edit',$data);
		}
		$this->load->view('admin/footer');
	}
	 	public function  updategroup()
		{
			$this->model->updategroup();
		}
		public function deletegroup()
		{
		$this->model->deletegroup();	
		}
		
		
		
		
}

