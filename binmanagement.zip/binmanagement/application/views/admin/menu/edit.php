
<style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
			 .panel-heading1 {
		 font-size: 18px;
    font-weight: 300;
    letter-spacing: 0.025em;
    height: 66px;
    line-height: 45px;
    background: ##ddd;
    border-bottom: 1px solid #eee;
    color: #333;
	padding: 10px 15px;
    /* background: #428bca; */
}
</style>


		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		</br>
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Edit Menu</div>
					<div class="panel-body">
						<div class="col-md-6">
							<form role="form" name="frmmenu" action="" method="post">
			<fieldset>				

	<input class="form-control form-control1" placeholder="Menu" name="txthiden" id="txthiden" type="hidden" value="<?php  echo $edit->menu_id?>" >
							  	<div class="form-group">
								<input class="form-control form-control1" placeholder="Menu" name="menuname" id="menuname" type="text" value="<?php  echo $edit->menu_name?>" >
                                <input class="form-control form-control1" placeholder="Menu" name="menuicon" id="menuicon" type="text" value="<?php  echo $edit->menu_icon?>" >
                                <input class="form-control form-control1" placeholder="Menu" name="menupath" id="menupath" type="text" value="<?php  echo $edit->menu_path?>" >
							</div>
                     
                            <div class="col-md-6" >
                              <a href="#" class="btn btn-primary btn-block lg" id="btnupdate" style="float:right:">Update</a></div>
                            	<div class="col-md-6">  <a href="" id="btncancel" class="btn btn-default btn-block lg" style="float:left;">Cancel</a></div>
								
                            
						<!--	    <div class="col-md-5"></div>   <div class="text-center "><a href="index.php" class="btn btn-primary btn-block lg">Submit</a>
                    <div class="col-md-4">
                    
                          
                         <a href="index.php" class="btn btn-primary btn-block lg">Submit</a>
                         
                          </div>
                            <div class="col-md-4">
                    
                          
                         <a href="index.php" class="btn btn-primary btn-block lg">Cancel</a>
                        </div></div>-->
                      
                            </fieldset>
								
								
								
							
								
							</form>	
								
								
							
						
					</div>
				</div>
                	 <div class="panel-footer"></div>
                     </div>
                     </div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->
    
    
    <script src="<?php echo ADMIN_STYLEPATH ?>js/jquery-1.11.1.min.js" type="text/javascript"></script>


<script type="text/javascript">

$(document).ready(function(e) {
   	//------insert -------------//
       	 $("#btnupdate").click(function(e) {
			//alert(1);
			var e=validation();
			if(e==0){
  			var url="<?php echo ADMIN_PATH?>menu/updatemenu";
  			var redirect = "<?php echo ADMIN_PATH?>menu";
  			var form = document.forms.namedItem("frmmenu");                        
			var oData = new FormData(document.forms.namedItem("frmmenu"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
					
				 if(oReq.responseText==1){
					  swal("Already Exist!", "Exist!", "Exist")
					  
					 }
					 else
					 {
						  swal("Sucessfully!", "Sucessfully Added!", "success")
 					document.location = redirect;
					 }}
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');

        $('input').removeClass('errorInput');

        $('select').removeClass('errors');

        $('select').removeClass('errorInput');
        

            var values = {
                                    'menu':$('#menuname').val(),
									'menu':$('#menuicon').val(),
									'menu':$('#menupath').val(),

                                 }

        if(values.menu == ''){
            $('#menuname').addClass('errors');
            $('#menuname').attr("placeholder", "Please enter menu.")
			$('#menuname').css({'border':'1px solid red'});
		    $('#menuname').addClass('errorInput');
            error=1;
        } 
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmmenu').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
	
	
	
	
	
	
	
	
	
	
	
});
</script>


    
    
    
    
    
    
    
    
    

