<style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
	float:right;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
.file-field .btn {
        float: right;
    position: relative;
}
/*.vname{
display:none;	
	}*/
	#vmid{
display:none;	
	}
.pan{    background: #43b0ef;
    color: white;
    height: 26px;
    border-radius: 5px;
    padding: 5px 5px;}
	
textarea{    background-color: transparent;
    border: none;
    border-bottom: 1px solid #9e9e9e;
    border-radius: 0;
    outline: none;
    height: 3rem;
    width: 100%;
    font-size: 1rem;
    margin: 0 0 20px 0;
    padding: 0;
    box-shadow: none;
    box-sizing: content-box;
    transition: all 0.3s;
}
 textarea:focus:not([readonly]) {
    border-bottom: 1px solid #ff9100;
    box-shadow: 0 1px 0 0 #ff9100;}
a .remove{
		cursor:pointer !important;
		}
a .addmore{
	cursor:pointer !important;
	}
td{
	width:20px !important;
	}
	
<?php /*?>.row .col.m5 {
    width: 18.666667%;
	}<?php */?>
	
</style>
<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m6 l6 ">
                <div class="card-panel">
				<h4 class="header2">Service SMS Settings</h4>
                  <div class="row">
<h6 class="pan">Add details</h6>
                       <form role="form" name="frmservice" id="frmservice"  method="post" enctype="multipart/form-data">

				<div class="row"> 
                          <div class="col s12"> 
                            <label for="first_name">Brand Name</label>
                              <select name="brand" id="brand">
                                <option value="">Choose brand....</option>
                                <?php foreach($brands as $bval) {?>
                                <option value="<?php echo encode($bval->man_id);?>"><?php echo $bval->man_title ;?></option>
                              <?php } ?>
                              </select>
                          </div>
                        </div>
<div class="row"> 
                          <div class="col s12 nmodel" > 
                            <label for="first_name">Model</label>
                              <select name="model" id="model" >
                                <option value="">Choose model....</option>
                              
                                <option value=""></option>
                               
                              </select>
                          </div>
                        </div>



                         <div class="row plusbox">  
                        
                         <div class="box" > 
                                     
                        <div class="input-field col s12 m6 s6" id="vname">
            <input  type="text" value="" class="form-conrol " id="settings" name="settings[]">  
            <label for="first_name">Settings</label>                        
                        </div>
                      <div class="input-field col s12 m5 s5" id="vname">
                            <input  type="text" value="" class="form-conrol " id="from" name="from[]"> 
							<label for="first_name">from</label>
                        </div>
                        <div class="input-field col s12 m5 s5" id="vname">
                            <input  type="text" value="" class="form-conrol " id="to" name="to[]"> 
							<label for="first_name">to</label>
                        </div>
                      <div class="input-field col s12 m1 s1" id="vname">
                       <a class="btnplus" style="right:12px"><i class="material-icons addmore">add_circle</i></a>                     
                        </div>
                        
                        
                     	 </div>
                      
                        </div> 
                          <div class="row">
                          <div class="input-field col s12">
                            <button class="btn cyan waves-effect waves-light right"  id="btnsub" type="button"  name="btnsub">Submit
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                        </div>
                      
                          
                           </form>
                        </div>
                       
                        </div>
                        </div>
                  <div class="col s12 m6 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Sms</h4>
                      <div class="row">
                      
                        <table id="datatable" class="mdl-data-table" cellspacing="0" >
                      <thead>
                        <tr>
                          <th style="text-align:center;">SN</th>
                          <th style="text-align:left;">Category</th>
                          <th style="text-align:left;">Start Range</th>
                          <th style="text-align:left;">End Range</th>
                          <th >Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php  if($sms){ $i=1; foreach($sms as $val  ){ ?>
                        <tr>
								<td style="text-align:center;"><?php echo $i ;?></td>
                                <td style="text-align:left;"><?php echo $val->category;?> </td>
                                <td style="text-align:left;"><?php echo $val->s_range;?> </td>
                                <td style="text-align:left;"><?php echo $val->e_range;?> </td>
                                <td > 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>Smssettings/editsms/<?php echo encode($val->sid); ?>">
										<i class="material-icons">mode_edit</i>
								</a>
                                <a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->sid);?>" href="#">
										<i class="material-icons">delete</i>
								</a>
                                </td>
							</tr>
					<?php $i=$i+1;}}?>
                      </tbody>
                    </table>
                    
                      </div>
                    </div>
                  </div>
                        </div>
                        </div>
                        </div>
                        </div>
                        
                        <script >
	
	
$(document).ready(function(e) {
	
	 $(document).on('change','#brand', function()
{

var brand=$(this).val();			
	
	$.ajax({
		type:'post',
		url:"<?php echo ADMIN_PATH ?>smssettings/get_model",
		data:"brand="+brand,
	
		success:function(data)
		{
			console.log(data);
			// $('.overlay').css({'display':'none'});
               $('#model').material_select('destroy');
               $('#model').html(data);
               $('#model').material_select();
			
		}
	
	});
				
});
	
	
	
	 $(document).on("click",".addmore",function() {
	 //date11();
		
        var tparent = $(this).parent();
        var rem='<i class="material-icons remove">cancel</i>';
        tparent.html(rem);
        var htm='<div class="box" > <div class="input-field col s12 m6 s6" id="vname"> <input type="text" value="" class="form-conrol " id="settings" name="settings[]"> <label for="first_name">Settings</label> </div><div class="input-field col s12 m5 s5" id="vname"> <input type="text" value="" class="form-conrol " id="from" name="from[]"> <label for="first_name">from</label> </div><div class="input-field col s12 m5 s5" id="vname"> <input type="text" value="" class="form-conrol " id="to" name="to[]"> <label for="first_name">to</label> </div><div class="input-field col s12 m1 s1" id="vname"> <a class="btnplus" style="right:12px"><i class="material-icons addmore">add_circle</i></a> </div></div>';

        $('.plusbox').append(htm);
    }) 
	 
	 
	  $(document).on("click",".remove",function() {
		 // alert('delet');
       $(this).parent().parent().parent().remove();
    });
	
	});	
		 $("#btnsub").click(function(e) {
	// alert(45645);
 var e=validation();
//var e=0;
	 if(e==0){
		 $('.overlay').css({'display':'flex'});
  		 var url="<?php echo ADMIN_PATH?>Smssettings/insertsms";
  		// var redirect = "<?php echo ADMIN_PATH?>services/";
  		 var form = document.forms.namedItem("frmservice");  
		 var oData = new FormData(document.forms.namedItem("frmservice"));           
         var oReq = new XMLHttpRequest();
          oReq.open("POST", url,  true);   
          oReq.onload = function(oEvent) { 
			$('.overlay').css({'display':'none'});
			//alert(oReq.responseText);
			var id=oReq.responseText;
		swal(
														'Success!',
														'Inserted Successfully',
														'success'
													 )
													 location.reload();
					//console.log(oReq.responseText);
					 }
                oReq.send(oData);
                //ev.preventDefault();   
      
						}
   			});
			function validation(){

        error=0;

        $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');
        

            var values = {
                                    'settings':$('#settings').val(),
									'from':$('#from').val(),
									'to':$('#to').val(),
			}
			if(values.settings == ''){
		   $('#settings').addClass('errors');
		   $('#settings').parent().children('label').addClass('active');
			$('#settings').attr("placeholder", "Please enter settings")
		    $('#settings').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.from == ''){
		   $('#from').addClass('errors');
		   $('#from').parent().children('label').addClass('active');
			$('#from').attr("placeholder", "start range")
		    $('#from').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.to == ''){
		   $('#to').addClass('errors');
		   $('#to').parent().children('label').addClass('active');
			$('#to').attr("placeholder", " end range")
		    $('#to').parent().children('label').addClass('labelerror');
            error=1;
        } 
		  return error;
    }
	
	$(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
				
 swal({
		title: 'Are you sure?',
		text: "You won't be able to revert this!",
		type: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#3085d6',
		cancelButtonColor: '#d33',
		confirmButtonText: 'Yes, delete it!'
	}).then(function () {
						 $.ajax({
                         type:"post",
                         url: "<?php echo ADMIN_PATH ?>Smssettings/deletesms",
                         data:"id="+id,
						 success:function(data){ 											
												 swal(
														'Deleted!',
														'Your file has been deleted.',
														'success'
													 )
														location.reload() ;
	
											   }
			    
	});
  	})                    
			  
});	
		
		
	</script>