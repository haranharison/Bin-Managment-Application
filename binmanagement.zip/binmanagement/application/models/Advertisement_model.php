<?php
class Advertisement_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        
		public function getadvertisement()
		{
		
		$array=array('status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_advertisement')->result();
		}
		
		public function addadvertisement()
		{
			
			
			$max=maxplus('tbl_advertisement','adv_id');
			
			//	$orgid=$this->session->userdata('org_id');
			
		$today= date("y-m-d");
		$wsite=$this->input->post('wsite');
		$title=$this->input->post('title');
		$pos=$this->input->post('pos');
		$publish=$this->input->post('publish');
		$exist=0;
		if($publish==1){
			$exist=fieldexist('tbl_advertisement','publish_status',$publish,'adv_position',$pos);
			if($exist==1){
				echo 1;
				
				}
		
		}
		if($exist==0){
		
				///////////////////////////////////////Attachment////////////////////////////		
		$config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('imgfile')) {
                $error = array('error'=>$this->upload->display_errors());
            } 
			else {
            $dataimg = array('upload_data'=>$this->upload->data());
            }
            $path='./uploads/'.$dataimg['upload_data']['file_name'];
			
			
		$data= array(
			   'adv_id' =>$max,
		       'adv_title'=>$title,
			   'adv_img'=>$path,
			   'adv_website'=>$wsite,
			   'adv_position'=>$pos,
			   'publish_status'=>$publish,
			   'created_date'=>$today,
			   'modified_date'=>$today
		);
		$this->db->insert('tbl_advertisement',$data);
		}
		}	
	public function editadvertisement($id){
		$cid=decode($id);
		$array=array('adv_id'=>$cid,'status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_advertisement')->row();
		}
			
	public function updateadvertisement()
	{
		$cid=decode($this->input->post('hidden'));
		$today= date("y-m-d");
		$wsite=$this->input->post('wsite');
		$title=$this->input->post('title');
		$pos=$this->input->post('pos');
		$publish=$this->input->post('publish');
			
			$exist=0;
		if($publish==1){
			$exist=fieldexistOnUpdate('tbl_advertisement','publish_status',$publish,'adv_position',$pos,'adv_id',$cid);
			if($exist==1){
				echo 1;
				
				}
		
		}
		if($exist==0){
			
				
	if($_FILES['imgfile']['name']!=''){
					
		$config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('imgfile')) {
                $error = array('error'=>$this->upload->display_errors());
            } 
			else {
            $dataimg = array('upload_data'=>$this->upload->data());
            }
            $path='./uploads/'.$dataimg['upload_data']['file_name'];
			
			
		$data= array(
		       'adv_title'=>$title,
			   'adv_img'=>$path,
			   'adv_website'=>$wsite,
			   'adv_position'=>$pos,
			   'publish_status'=>$publish,
			   'modified_date'=>$today
			 );
		}
		else{
				$data= array(
				   'adv_title'=>$title,
				   'adv_website'=>$wsite,
				   'adv_position'=>$pos,
			 	   'publish_status'=>$publish,
				   'modified_date'=>$today
				 );
					
				}
			   $array= array('adv_id'=>$cid,'status'=>0);
			   $this->db->where($array);
			   $this->db->update('tbl_advertisement',$data);
		}
			}
			
			  public function deleteadvertisement()
			  {
		 	$cid=decode($this->input->post('id'));
		   $data=array('status'=>1);
		   $array= array('adv_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_advertisement',$data);
		   }
	
}