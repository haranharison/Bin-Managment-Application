<?php
class Charge_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        public function getbrand()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_brand')->result();
		}
		
		public function get_mincharge(){

	$model=decode($this->input->post('model'));
	$brand=decode($this->input->post('brand'));


     $array=array('model_id'=>$model,'brand_id'=>$brand);
			$this->db->where($array);
			$this->db->select('*');
       		$result=$this->db->get('tbl_fare_settings');
       		 $rows=$result->row();


 $html='';
				if($result->num_rows() > 0)
				{
					
					 $html.=$rows->min_charge;
					
				}else{
					$html.='error';
						}
			echo $html;


}
	
public function getmodel()
			{
				 $brand=decode($this->input->post('brand'));
				// echo json_encode($cid);
				
				 $arr=array('tbl_model.brand_id'=>$brand);
				 $this->db->where($arr);
				 $this->db->select('*');
				 $this->db->from('tbl_model');
				$results=$this->db->get();
				 $rows=$results->result();
				 $html='';
				if($results->num_rows() > 0)
				{
					$html.='<option value="0">Select model</option>';
					foreach($rows as $key)
					{
					 $html.='<option value="'.encode($key->model_id).'">'.$key->model_name.'</option>';
					}
				}else{
					$html.='<option value="0">-- No result --</option>';
						}
			echo $html;
				
			}

			public function insert()
		{
			
			////////////////////owner mobile number////////////////////////
			$arr22=array('tbl_driverdetails.did'=>$this->session->userdata('emp_id'));
			$this->db->where($arr22);
			$this->db->select('tbl_driverdetails.did,tbl_driverdetails.regid,tbl_driverdetails.regno,tbl_servicereg.mobile,tbl_servicereg.servicereg_id');
			$this->db->from('tbl_driverdetails');
			$this->db->join('tbl_servicereg','tbl_servicereg.regid=tbl_driverdetails.regid');
       		$res22=$this->db->get()->row();
       		
			$mob=$res22->mobile;
			$regno=$res22->regno;
			$owner_id=$res22->servicereg_id;
			
			//////////////////////////////////////////////////////////////
			
		    $max=maxplus('tbl_mincharge','min_id');	
		    $today=date('Y-m-d');
			$model=decode($this->input->post('model'));
			$brand=decode($this->input->post('brand'));
			
			$array=array('model_id'=>$model,'brand_id'=>$brand,'owner_id'=>$owner_id);
			$this->db->where($array);
			$this->db->select('*');
       		$result=$this->db->get('tbl_fare_settings');
       		$rows=$result->row();
			
			$mincharge=$rows->min_charge;
			$min_km=$rows->min_charge_km;
			$rate=$rows->rate_per_km;
			$wait=$rows->wait_time;
			$aftwait=$rows->after_wait_time;
			$waitrate=$rows->after_wait_time_amt;
			/////////////////////////////////////////
			
			$ekm=$this->input->post('e_km');
			$skm=$this->input->post('s_km');
			$waittime=$this->input->post('w_time');
			$tkm=$ekm-$skm;
			$fkm=$tkm-$min_km;
			
			
			///////////////////////calculating waiting charge////////////////////////////////////
			if($waittime<=$wait)
			{
				$lwaitcharge=0;
			}
			else if($waittime>$wait)
			{
				$to_time = strtotime($waittime);
				$from_time = strtotime($wait);
				$t_wait_minute=round(abs($to_time - $from_time) / 60,2);
				
				$timesplit=explode(':',$aftwait);
   				$aft_wait=round(($timesplit[0]*60)+($timesplit[1]));
			 
			 	$rateperminut=$waitrate/$aft_wait;
				$lwaitcharge=$t_wait_minute*$rateperminut;
			}
			/////////////////////////////////////////////////////////////////////////////////////
			if($min_km>=$tkm)
			{
				$final=$lwaitcharge+$mincharge;
			}
			else if($min_km<$tkm)
			{
				$getrate=$fkm*$rate;
				$final=$getrate+$lwaitcharge+$mincharge;
			}
			
			$data= array(
			   'min_id' =>$max,'org_id'=>$this->session->userdata('org_id'),'driver_id'=>$this->session->userdata('emp_id'),				'brand_id'=>decode($this->input->post('brand')),'model_id'=>decode($this->input->post('model')),
			   'c_name'=>$this->input->post('sname'),'c_id'=>$this->input->post('cid'),'s_km'=>$this->input->post('s_km'),
			   'e_km'=>$this->input->post('e_km'),'w_time'=>$this->input->post('w_time'),
			   'min_charge'=>$this->input->post('m_charge'),
			   'totalfare'=>$final,'status'=>0,'created_date'=>$today,'modifi_date'=>$today,);
			$this->db->insert('tbl_mincharge',$data);
			
			
			 
			
			
			
			//////////////////// org mobile///////////////////
			$ar5=array('o_maxid'=>$this->session->userdata('org_id'));
			$this->db->where($ar5);
			$this->db->select('*');
       		$res5=$this->db->get('tbl_organisation');
       		$re5=$res5->row();
			$orgmob=$re5->org_mobile;
			
			
			
			//////////////////////////checking smssettings////////////////////////////
			
			$ar2=array('model_id'=>$model,'brand_id'=>$brand,'s_range<='=>$ekm,'e_range>='=>$ekm,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($ar2);
			$this->db->select('*');
       		$res=$this->db->get('tbl_sms');
       		$re2=$res->result();
			
			 $html='';
			 $cat='';
			 $html.='Dear user,';
			 $html.='Your vehicle with registeration no '.$regno.' had reached service time.';
			
			foreach($re2 as $bin)
			{  
			$cat.=$bin->category.',';
				
				} 
				$cate=rtrim($cat,',');
			$html.=$cate;
			$html.='. For avoiding delay in service.Please Book Service on ';
			$html.=$orgmob;
			////////////////////SMS//////////////////////////
			$smcount=checksms($this->session->userdata('org_id'));
			
			if($smcount>0){
			$mobval=mobilesms($mob,$html);
			
			///////////SUBSTRACT SMS COUNT///////////////
			$smsc=$smcount-1;
			
			$a23= array('org_id'=>$this->session->userdata('org_id'));
		   $this->db->where($a23);
			$data99= array('smscount'=>$smsc);
			$this->db->update('tbl_sms_orgsettings',$data99);
			}
			 echo $max;
			
		}
		//////////////////////pdf///////////////////////////////
		public function pdfdetails($id)
{
	$array=array('tbl_mincharge.status'=>0,'tbl_mincharge.min_id'=>$id);
		$this->db->where($array);
		$this->db->select('tbl_mincharge.*,tbl_brand.man_title,tbl_model.model_name');
		$this->db->from('tbl_mincharge');
		$this->db->join('tbl_brand','tbl_mincharge.brand_id=tbl_brand.man_id');
		$this->db->join('tbl_model','tbl_mincharge.model_id=tbl_model.model_id');
		return $rows=$this->db->get()->row();
		
	
	
}
public function viewone($id)
{
	$sid=decode($id);
	$array=array('tbl_mincharge.status'=>0,'tbl_mincharge.min_id'=>$sid);
		$this->db->where($array);
		$this->db->select('tbl_mincharge.*,tbl_brand.man_title,tbl_model.model_name');
		$this->db->from('tbl_mincharge');
		$this->db->join('tbl_brand','tbl_mincharge.brand_id=tbl_brand.man_id');
		$this->db->join('tbl_model','tbl_mincharge.model_id=tbl_model.model_id');
		return $rows=$this->db->get()->row();
		
	
	
}
/////////////////////////////////////////
public function getwaitcharge($brand,$model,$id)
{
	$array=array('model_id'=>$model,'brand_id'=>$brand);
			$this->db->where($array);
			$this->db->select('*');
       		$result=$this->db->get('tbl_fare_settings');
       		$rows=$result->row();
			
			$wait=$rows->wait_time;
			$aftwait=$rows->after_wait_time;
			$waitrate=$rows->after_wait_time_amt;
	
	
	$array1=array('min_id'=>$id);
			$this->db->where($array1);
			$this->db->select('*');
       		$result1=$this->db->get('tbl_mincharge');
       		$res=$result1->row();
	
			$waittime=$res->w_time;
	
	
	
	
	if($waittime<=$wait)
			{
				$lwaitcharge=0;
			}
			else if($waittime>$wait)
			{
				$to_time = strtotime($waittime);
				$from_time = strtotime($wait);
				$t_wait_minute=round(abs($to_time - $from_time) / 60,2);
				
				$timesplit=explode(':',$aftwait);
   				$aft_wait=round(($timesplit[0]*60)+($timesplit[1]));
			 
			 	$rateperminut=$waitrate/$aft_wait;
				$lwaitcharge=$t_wait_minute*$rateperminut;
			
			}
	
	return $lwaitcharge;
	
}

		///////////////////////gen pdf////////////////////////////////////////////////
	public function generatemypdf($id)
{
require('./pdf/fpdf.php');

$header = array('Room Type', 'No. of rooms', 'No. of children', 'No. of adults','Amount');
$data=array();
$pdf = new FPDF('P','mm','A4');
$pdf->AddPage();
//$u_name=$this->getorgname(); 
//$title=$this->getamenity();
  $w = array(48, 160, 185, 24,30);

 if($this->session->userdata('org_id'))
				{
				$iconz1=getmyicon($this->session->userdata('org_id'));
				}  
				else{$iconz1='assets/admin/images/logo/materialize-logos.png';
				}

$pdf->SetFont('Arial','',12);
   
// $pdf->Cell(array_sum($w),0,'','T');
$pdf->Image(SITE_PATH.$iconz1,75,13,40,10,'PNG');
$pdf->Ln(5);

$details=$this->pdfdetails($id);
$waitingcharge=$this->getwaitcharge($details->brand_id,$details->model_id,$id);


$totalkm=$details->e_km-$details->s_km;

 $fill = false;
$pdf->Cell(0,25,'Carbon Copy',0,0,'C');
$pdf->Line(0,30,210,30);
$date=date('Y-m-d');
$pdf->Cell(330,36,'Date : '.$date,'0',1,'C');
$pdf->SetTextColor(194,8,8);
//$pdf->Title('Service Id');
/*$pdf->SetFontSize(16);
$pdf->Text('150', '10', 'Service Id');
$pdf->SetFont('Arial','',11);
$pdf->SetTextColor(0,0,0);*/

$pdf->SetFontSize(10);
$pdf->Cell(0,-47, 'Trip Sheet Id : '.$details->min_id ,0,0,'L');
	$pdf->Cell(0,-47, 'Client Id : '.$details->c_id ,0,0,'R');


//$pdf->Cell(200,10,'Title',1,1,'C');

$pdf->SetTextColor(194,8,8);
//$pdf->Title('Service Id');
$pdf->SetFontSize(14);
$pdf->Text('10', '50', 'Basic Details');
$pdf->SetFont('Arial','',11);
$pdf->SetTextColor(0,0,0);

$pdf->Ln(1);

   $pdf->SetFillColor(178, 6, 8);
    $pdf->SetTextColor(255);
    $pdf->SetDrawColor(221, 221, 221);
    $pdf->SetLineWidth(.3);
    //$pdf->SetFont('','B');
    // Header
  
    /*for($i=0;$i<count($header);$i++)
        $pdf->Cell($w[$i],8,$header[$i],1,0,'C',true);
    $pdf->Ln();*/
    // Color and font restoration
    $pdf->SetFillColor(255, 243, 243);
    $pdf->SetTextColor(0);
    $pdf->SetFont('Arial','',11);
    // Data
    $fill = false;
    /*foreach($book_details_full as $row)
    {*/
	//$pdf->Cell(0,7,'Name : '.$book_details->c_name ,0,0,'L',$fill);
	//$pdf->Line(0,30,210,30);
        $pdf->Cell($w[0],8,'Brand ','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$details->man_title,'LRTB',0,'L',$fill);
		 $pdf->Cell($w[0],8,'Model ','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$details->model_name,'LRTB',0,'L',$fill);
		$pdf->Ln();
		$pdf->Cell($w[0],8,'Client Name (Office)','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$details->c_name,'LRTB',0,'L',$fill);
		 $pdf->Cell($w[0],8,'Client Id ','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$details->c_id,'LRTB',0,'L',$fill);
		$pdf->Ln();
		
		
		
		$pdf->SetTextColor(194,8,8);
//$pdf->Title('Service Id');
$pdf->SetFontSize(14);
$pdf->Text('10', '78', 'Fare Charges');
$pdf->SetFont('Arial','',11);
$pdf->SetTextColor(0,0,0);
$pdf->Ln(12);
 $pdf->Cell($w[0],8,'Minimum Charge ','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$details->min_charge,'LRTB',0,'L',$fill);
		 $pdf->Cell($w[0],8,'Total KM ','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$totalkm,'LRTB',0,'L',$fill);
		$pdf->Ln();
		 $pdf->Cell($w[0],8,'Waiting Time & Charge ','LRTB',0,'L',$fill);
        $pdf->Cell($w[3],8,$details->w_time,'LRTB',0,'L',$fill);
		 $pdf->Cell($w[3],8,$waitingcharge.' rs','LRTB',0,'L',$fill);
		 $pdf->Cell($w[0],8,'Total Fare ','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$details->totalfare.' rs','LRTB',0,'L',$fill);
		$pdf->Ln();
///////////////


        $pdf->Ln();
		
		 $pdf->SetFont('Arial','',9);
			$pdf->SetTextColor(194,8,8);
			$pdf->SetFontSize(14);
		 $pdf->Cell($w[1],18,'Total KM : ','',120,'R',$fill);
		  $pdf->Ln(-18);
		  $pdf->SetTextColor(0,0,0);
		  $pdf->SetFontSize(12);
		 $pdf->Cell($w[2],18,$totalkm.' km','',125,'R',$fill);
		
		
		  $pdf->Ln(0);
		 $pdf->SetFont('Arial','',9);
			$pdf->SetTextColor(194,8,8);
			$pdf->SetFontSize(14);
		 $pdf->Cell($w[1],0,'Total Amount:','',120,'R',$fill);
		
		  $pdf->SetTextColor(0,0,0);
		   $pdf->SetFontSize(12);
		 $pdf->Cell($w[2],0,$details->totalfare.' rs' ,'',125,'R',$fill);
		

		
		
        $fill = !$fill;
		 
	/*$pdf->Cell(210,10,'Total KM',1,1,'C');
	$pdf->Cell(260,10,$details->totalfare,1,1,'C');*/
    //}
 


$pdf->Output();




}	




		public function getalldetails()
		{
		$array=array('status'=>0,'driver_id'=>$this->session->userdata('emp_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_mincharge')->result();
		}
		
		
		
//////////////////////////////////////////////////////////////////		
		
		
		
		
		public function getmainservice()
		{
		$array=array('status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->group_by('ser_id');
		return $rows=$this->db->get('tbl_service')->result();
		}

		
	
		public function deleteService()
		  {
		   $cid=$this->input->post('id');
		   $mid=decode($cid);
		   $data=array('status'=>3);
		   $array= array('ser_id'=>$mid);
		   $this->db->where($array);
		   $this->db->update('tbl_service',$data);	
			
		}
		public function editservice($mid){ 
		    $id=$mid;
			$array=array('status'=>0,'ser_id'=>$id);
			$this->db->where($array);
			$this->db->select('*');
       		$result=$this->db->get('tbl_service');
       		return $rows=$result->result();
		}
		public function updateservice(){}
		
		
	
		

		
		
public function min_chargeinsert(){
	$max=maxplus('tbl_mincharge','min_id');	
	$sname=$this->input->post('sname');
	$cid=$this->input->post('cid');
	$s_km=$this->input->post('s_km');
	$e_km=$this->input->post('e_km');
	$w_time=$this->input->post('w_time');
	$today=date('Y-m-d');
	$dist=$e_km-$s_km;





$data= array('min_id'=>$max,
'c_name'=>$sname,
'c_id'=>$cid,
's_km'=>$s_km,
'e_km'=>$e_km,
'w_time'=>$max,
'min_charge'=>$max,
'created_date'=>$today,
'modifi_date'=>$today
);
$this->db->insert('tbl_mincharge',$data);	
}


















}