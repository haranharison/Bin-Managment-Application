<?php
class Registerreturn_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        
		public function getRegisterretrns()
		{
		$array=array('tbl_registerreturns.status'=>0,'tbl_registerreturns.org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('tbl_registerreturns.*,tbl_storage.storage_name');
		$this->db->from('tbl_registerreturns');
		$this->db->join('tbl_storage','tbl_storage.storage_id=tbl_registerreturns.storage_fac');
		return $rows=$this->db->get()->result();
		}
		public function getProductid(){
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('tbl_product.product_code,product_name');
			return $rows=$this->db->get('tbl_product')->result();
			}
		public function getStorage(){
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('tbl_storage.storage_name,storage_id');
			return $rows=$this->db->get('tbl_storage')->result();
			}
		public function getStoragedetails()
		{
			
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),);
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_storage');
				 $res= $rows->result();
				 $html='';
				 
				 if($rows->num_rows()>0){
					 
					 $html.='<select id="designation" name="designation" style="display:none;" ><option value="0" >Select Storage</option>';
					foreach($res as $val){
					 $html.='<option value="'.$val->storage_id.'">'.$val->storage_name.'</option>	';
					}
					$html.='</select>';
					 //$html.='</select><a class="addDynamicfield btnaddunit"><i class="material-icons">add_circle</i></a>';
					 }
					
					
						 
				echo $html;
		
		}
		public function insertstorage(){
			$exist=fieldexist('tbl_storage','storage_name',$this->input->post('dname'),'org_id',$this->session->userdata('org_id'));
		if($exist==1){
			echo 1;
		}else{
			$max=maxplus('tbl_storage','storage_id');
			$today= date("y-m-d");
			$storage_name=$this->input->post('dname');
			
			$data= array(
			'org_id'=>$this->session->userdata('org_id'),
			'storage_id' =>$max,
		    'storage_name'=>$storage_name,
			'created_date'=>$today,
			'modified_date'=>$today
		);
		$this->db->insert('tbl_storage',$data);
			
		}	   
		}	   
		
		/*public function getmainmarketing()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		$this->db->group_by('en_id');
		return $rows=$this->db->get('tbl_enquiry')->result();
		}*/
		
		public function registerreturnreg()
		{
		  	$max=maxplus('tbl_registerreturns','ret_id');	
		    $today=date('Y-m-d');
			$data= array(
			   'org_id'=>$this->session->userdata('org_id'),
			   'ret_id' =>$max,
 			   'item_id'=>$this->input->post('selItemid'),
			   'itemname'=>$this->input->post('selItem'),
			   'ret_date'=>$this->input->post('returndate'),
			   'expirydate'=>$this->input->post('expdate'),
			   'storage_fac'=>$this->input->post('designation'),
			   'retunqty'=>$this->input->post('itqty'),
			   'crea_date'=>$today,
			   'mod_date'=>$today,
			   'status'=>0,
			);
			$this->db->insert('tbl_registerreturns',$data);	
		}
		public function deleteReturn(){
		   $aid=$this->input->post('id');
		   $mid=decode($aid);
		   $data=array('status'=>1);
		   $array= array('ret_id'=>$mid);
		   $this->db->where($array);
		   $this->db->update('tbl_registerreturns',$data);	
			
		}
		public function editDetails($aid){ 
		    $id=$aid;
			$array=array('status'=>0,'ret_id'=>$id);
			$this->db->where($array);
			$this->db->select('*');
       		$result=$this->db->get('tbl_registerreturns');
       		return $rows=$result->row();
		}
		public function updatereturns(){
		    $id=$this->input->post('hdnId');
		    $today=date('Y-m-d');
			$data= array(
			   'org_id'=>$this->session->userdata('org_id'),
 			   'item_id'=>$this->input->post('selItemid'),
			   'itemname'=>$this->input->post('selItem'),
			   'ret_date'=>$this->input->post('returndate'),
			   'expirydate'=>$this->input->post('expdate'),
			   'storage_fac'=>$this->input->post('designation'),
			   'retunqty'=>$this->input->post('itqty'),
			   'crea_date'=>$today,
			   'mod_date'=>$today,
			   'status'=>0,
			);
			$array=array('org_id'=>$this->session->userdata('org_id'),'ret_id'=>$id);
			$this->db->where($array);
		    $this->db->update('tbl_registerreturns',$data);
		
		}
		public function insertnew(){
			$max=maxplus('tbl_enquiry_status','enquiry_status_id');	
		    $today=date('Y-m-d');
			$data= array(
			'org_id'=>$this->session->userdata('org_id'),
			   'enquiry_status_id' =>$max,
		       'status_name'=>$this->input->post('sname'),
			    'status'=>0,
			   'created_date'=>$today,
			   'modified_date'=>$today,
			   );
			   	$this->db->insert('tbl_enquiry_status',$data);
			}
			
			public function getnewstatus()
		{
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),);
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_enquiry_status');
				 $res= $rows->result();
				 $html='';
				 
				 if($rows->num_rows()>0){
					 
					 $html.='<select  id="status" name="status" style="display:block;" ><option value="0" >Select Status</option>';
					foreach($res as $val){
					 $html.='<option value="'.$val->enquiry_status_id.' ">'.$val->status_name.'</option>	';
					}
					$html.='</select>';
					 //$html.='</select><a class="addDynamicfield btnaddunit"><i class="material-icons">add_circle</i></a>';
					 }
					
					
						 
				echo $html;
		}
				public function getstatus()
		{
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_enquiry_status');
				return $res= $rows->result();
		}
		
		public function changevwstatus()
		{
			
		
		$enqid=decode($this->input->post('vid'));
		
		$array=array('status'=>0,'en_id'=>$enqid);
		$data=array('view_status'=>1);
		$this->db->where($array);
		
		$this->db->update('tbl_enquiry',$data);
		}
}