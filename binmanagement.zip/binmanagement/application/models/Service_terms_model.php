<?php
class Service_terms_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	
   /*function getitemstitle()
   {
	   
	   $this->db->where('org_id',$this->session->userdata('org_id'));
	   $this->db->select('*');
	  return $res= $this->db->get('tbl_s_items')->result();
	   
	}
	 function getamenitytitle()
   {
	   
	   $this->db->where('org_id',$this->session->userdata('org_id'));
	   $this->db->select('*');
	  return $res= $this->db->get('tbl_s_amenity')->result();
	   
	}*/
	 function gettermsandcon()
   {
	  if($this->session->userdata('org_id')=="")
		{
		   
		   $this->db->where('org_id','admin');
	   }
	   else
	   {
		   $this->db->where('org_id',$this->session->userdata('org_id'));
	   }
	   
	   $this->db->select('*');
	  return $res= $this->db->get('tbl_service_terms')->result();
	   
	}	
	
	public function insert() // addproduct
	{
		if($this->session->userdata('org_id')=="")
		{
			
		 $this->db->where('org_id','admin');
		$this->db->delete('tbl_service_terms');
		
				$max=maxplus('tbl_service_terms','terms_id');
				$today= date("y-m-d");
				$org=$this->session->userdata('org_id');
				
				
				$g_title=$this->input->post('general_title');
				$c=count($g_title);
				
				for($i=0;$i<$c;$i++){
				$data= array('terms_id'=>$max,
				             'org_id'=>'admin',
				             'titles'=>$g_title[$i],
							 'create_date'=>$today,
							 'modify_date'=>$today
				);
				
			$this->db->insert('tbl_service_terms',$data);
		
				}
			
		}
		else{
			$this->db->where('org_id',$this->session->userdata('org_id'));
		$this->db->delete('tbl_service_terms');
		
				$max=maxplus('tbl_service_terms','terms_id');
				$today= date("y-m-d");
				$org=$this->session->userdata('org_id');
				
				
				$g_title=$this->input->post('general_title');
				$c=count($g_title);
				
				for($i=0;$i<$c;$i++){
				$data= array('terms_id'=>$max,
				             'org_id'=>$org,
				             'titles'=>$g_title[$i],
							 'create_date'=>$today,
							 'modify_date'=>$today
				);
				
			$this->db->insert('tbl_service_terms',$data);
		
				}
			
		}
				
}

}