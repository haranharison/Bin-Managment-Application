/*================================================================================
	Item Name: jQuery & JavaScript  - Carbon Copy 
	Author: Rakesh Raj - @056
	Author URL: 
	All rights reserved : Carbon Copy
================================================================================*/
$(document).ready(function(e) {
	var nurExp=/^[0-9]+$/;
	var alphaExp=/^[a-zA-Z]+$/;

	//.keyup(function(e){
	$('.confirm-chr').bind({keydown: function(e) {
			   /* if (e.which === 32 ) {
					console.log(12)
					return false;
				}*/
			}
	});
//ALLOW NUMBERS		input_field-tax_properties
		$(document).on('keypress','.input_field-tax_properties', function(e) {	
				console.log(1);
				if ( event.keyCode == 46 || event.keyCode == 8 ) {//|| event.keyCode == 37	event.keyCode==37 for Percentage
							
				}
				 else {
            // Ensure that it is a number and stop the keypress
						if (event.keyCode < 48 || event.keyCode > 57) {
							event.preventDefault(); 
						}  
				 }
				//return isNumber(event, this)
			});
// THE SCRIPT THAT CHECKS IF THE KEY PRESSED IS A NUMERIC OR DECIMAL VALUE.
    function isNumber(evt, element) {

        var charCode = (evt.which) ? evt.which : event.keyCode
        if (
            (charCode != 45 || $(element).val().indexOf('-') != -1) &&      // “-” CHECK MINUS, AND ONLY ONE.
            (charCode != 46 || $(element).val().indexOf('.') != -1) &&      // “.” CHECK DOT, AND ONLY ONE.
            (charCode < 48 || charCode > 57))
            return false;
        return true;
    }   //END
});//MAIN QUERY END
//.cc-f-l-id
$('#btn-f-l-p').click(function(){
	$('.o-v-f-p').css('display','block');
	$('.f-p-p').css({'display':'block','opacity':'1','transform':'scale(1)'});
	});
	//f-p-p
	$('.o-v-f-p').click(function(){
		$('.o-v-f-p').css('display','none');
	});


$(document).on('focusout','input',function(){
		if($(this).val()!=''){$(this).removeClass('errors');$(this).parent().children('label').removeClass('labelerror');}
});
function datatablenew(){
	console.log(0)
 
    var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable( { pageLength: 10,
        dom: 'Bfrtip',
        buttons: ['csv', 'excel', 'pdf', 'print'],
        responsive: true} );

        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        var $datatable = $('#datatable-checkbox');

        $datatable.dataTable({
          'order': [[ 1, 'asc' ]],
          'columnDefs': [
            { orderable: false, targets: [0] }
          ]
        });
        $datatable.on('draw.dt', function() {
          $('input').iCheck({
            checkboxClass: 'icheckbox_flat-green'
          });
        });

        TableManageButtons.init();
      	
}



