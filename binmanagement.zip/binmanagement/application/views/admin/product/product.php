   
                  
       
<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  <div class="col s12 m12 l12">
                    <div class="card-panel">
                      <h4 class="header2">All Product</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
							  <tr class="text-center">
								  <th style="width:50px;">Sl.no</th>
                                  <th style="text-align:left;">Product name</th>
								  <th style="text-align:left;">Category name</th>
                                   
                                   
                                  <th></th>
							  </tr>
						  </thead>   
                      <tbody>
                         <?php if($product) { $i=1; foreach($product as $val  ){ ?>
							<tr>
								<td style="width:50px;text-align:center;"><?php echo $i ?></td>
                                	<td style="text-align:left;"><?php echo $val->product_name?> </td>
								<td style="text-align:left;"><?php echo $val->cat_name?> </td>
									
                                    
								<td style="width:150px;text-align:right;">
								
									<a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH.'product/proedit/'.encode($val->product_id)?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange btndlt" rel="<?php echo encode($val->product_id);?>" href="#">
										<i class="material-icons">delete</i>
									</a>
								</td>
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
                  <!-- Form with placeholder -->
                  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

  
<script type="text/javascript">
$(document).on('click', '.btndlt', function(){
$btn=$(this);$tr=$btn.parent().parent();var id=$(this).attr('rel');  
swal({
	  title: "Are you sure?",
	  text: "Your will not be able to recover this Data!",
	  type: "warning",
	  showCancelButton: true,
	  confirmButtonClass: "btn-danger",
	  confirmButtonText: "Yes, delete it!",
	  customClass: 'swal-delete',
	  cancelButtonText: "No, cancel!",
  
}).then(function(){
			 $.ajax({
                                            type:"post",
                       						url: "<?php echo ADMIN_PATH ?>product/deleteproduct",
                                            data:"id="+id,
                                            success:function(data){ //alert(data);
												/*swal({
												  title: '<div class="tst" >Deleted</div>',
												  html:'<div class="tst1" >Employee has been deleted</div>',
												  type: 'success',
												  customClass: 'swal-delete',
												})*/
												
												customSwalFunD("Success", "Data has been Deleted");
												$tr.remove();
											//	location.reload() ;
											 }
								});
			});
			/*
function(isConfirm) {
  if (isConfirm) {
	  alert(0)
	  $.ajax({
                    type:"post",
					url: "<?php  echo ADMIN_PATH ?>tax/deletetax",
					data:"id="+id,
					success:function(data){ 
					alert(data);
								swal("Sucessfully!", "Sucessfully Deleted!", "success");
								location.reload() ;
          						}
						});//AJAX END
  //  swal("Deleted!", "Your imaginary file has been deleted.", "success");
  } 
  else {
    swal("Cancelled", "Your imaginary file is safe :)", "error");*/
  });
</script>


    
    
    
    
    
    
    
    
    

