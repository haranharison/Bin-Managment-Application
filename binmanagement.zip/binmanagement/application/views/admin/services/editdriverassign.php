
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
  <style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
	float:right;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
.file-field .btn {
        float: right;
    position: relative;
}
/*.vname{
display:none;	
	}*/
	#vmid{
display:none;	
	}
	.pan{    background: #43b0ef;
    color: white;
    height: 26px;
    border-radius: 5px;
    padding: 5px 5px;}
	
	textarea{    background-color: transparent;
    border: none;
    border-bottom: 1px solid #9e9e9e;
    border-radius: 0;
    outline: none;
    height: 3rem;
    width: 100%;
    font-size: 1rem;
    margin: 0 0 20px 0;
    padding: 0;
    box-shadow: none;
    box-sizing: content-box;
    transition: all 0.3s;
}
 textarea:focus:not([readonly]) {
    border-bottom: 1px solid #ff9100;
    box-shadow: 0 1px 0 0 #ff9100;}
	a .remove{cursor:pointer !important;}a .addmore{cursor:pointer !important;}
	.row .col.m6 {
    width: 44%;}
	a .addmore {
    margin-top: 10px;
	}
	/*select*/
	.select2 .selection .select2-selection--single, .select2-container--default .select2-search--dropdown .select2-search__field {
    border-width: 0 0 1px 0 !important;
    border-radius: 0 !important;
    height: 2.05rem;
}

.select2-container--default .select2-selection--multiple, .select2-container--default.select2-container--focus .select2-selection--multiple {
    border-width: 0 0 1px 0 !important;
    border-radius: 0 !important;
}

.select2-results__option {
    color: #26a69a;
    padding: 8px 16px;
    font-size: 16px;
}

.select2-container--default .select2-results__option--highlighted[aria-selected] {
    background-color: #eee !important;
    color: #26a69a !important;
}

.select2-container--default .select2-results__option[aria-selected=true] {
    background-color: #e1e1e1 !important;
}

.select2-dropdown {
    border: none !important;
    box-shadow: 0 2px 5px 0 rgba(0,0,0,0.16),0 2px 10px 0 rgba(0,0,0,0.12);
}

.select2-container--default .select2-results__option[role=group] .select2-results__group {
    background-color: #333333;
    color: #fff;
}

.select2-container .select2-search--inline .select2-search__field {
    margin-top: 0 !important;
}

.select2-container .select2-search--inline .select2-search__field:focus {
    border-bottom: none !important;
    box-shadow: none !important;
}

.select2-container .select2-selection--multiple {
    min-height: 2.05rem !important;
}

.select2-container--default.select2-container--disabled .select2-selection--single {
    background-color: #ddd !important;
    color: rgba(0,0,0,0.26);
    border-bottom: 1px dotted rgba(0,0,0,0.26);
}

input[type=text],
input[type=password],
input[type=email],
input[type=url],
input[type=time],
input[type=date],
input[type=datetime-local],
input[type=tel],
input[type=number],
input[type=search],
textarea.materialize-textarea {
  &.valid + label::after,
  &.invalid + label::after,
  &:focus.valid + label::after,
  &:focus.invalid + label::after {
    white-space: pre;
  }
  &.empty {
    &:not(:focus).valid + label::after,
    &:not(:focus).invalid + label::after {
      top: 2.8rem;

    } 
  }
}
</style>


          <!--breadcrumbs end-->

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m6 l6 ">
                <div class="card-panel">
				<h4 class="header2">Driver Assigning</h4>
                  <div class="row">
                  <h6 class="pan"> Details</h6>
                  <?php //echo $this->session->userdata('org_id');?>
                  <form role="form" name="frmservice" id="frmservice"  method="post" enctype="multipart/form-data">
                      <div class="row">                    
                          <div class="input-field col s12 m6 s6" id="vname">                 
      
<select class="form-conrol selectpicker" data-live-search="true" id="ownerid" name="ownerid">
   
   <option value="" disabled selected>Owner ID</option>
   <?php foreach($services as $val) {  ?>
   
    <option  <?php if($res->regid==$val->regid)echo 'selected="selected"'; ?>value="<?php echo $val->regid;?>"><?php echo $val->regid;?></option>
  <?php }?>
    
   
</select>          

</div>


 <div class="input-field col s12 m6 s6" id="vname">                 
       
                      <select class="form-conrol selectpicker" data-live-search="true" id="vid" name="vid">
                       <option value="" disabled selected>Vehicle Reg.No</option>
                      
                         <?php foreach($vehicle as $val) {  ?>
                         
      <option <?php if($res->regno==$val->regno)echo 'selected="selected"'; ?> value="<?php echo $val->regno;?>"><?php echo $val->regno;?></option>

    <?php } ?>
</select>

</div>

  </div> 
                   
                        
                      
                     <h6 class="pan">Driver Details</h6>
                        
                       <div class="row">  
                        
                       <div class="input-field col s12 m6 s6" id="vname">
                         
                          	<input  type="text" class="form-conrol" id="sname" name="sname" value="<?php echo $res->dname; ?>">
                            
                          <label for="first_name">Driver Name</label>
                        </div>
                                                                    
                        <div class="input-field col s12 m6 s6">
                          	<textarea  type="text" class="form-conrol" id="address" name="address" ><?php echo $res->address; ?></textarea>
                          <label for="first_name">Address</label>
                        </div>
                       
                        <div class="input-field col s12 m6 s6">
                          	<input  type="number" name="telr" id="telr"  class="form-conrol" value="<?php echo $res->telno; ?>">
                          <label for="first_name">Telephone </label>
                        </div> 
                         <div class="input-field col s12 m6 s6">
                          	<input  type="number" name="mobile" id="mobile"  class="form-conrol" value="<?php echo $res->mobile; ?>">
                          <label for="first_name">Mobile</label>
                        </div>
                        
                          
                        <div class="input-field col s12 m6 s6">
                          	<input  type="email" name="lno" id="lno"  class="form-conrol" value="<?php echo $res->licenseno; ?>">
                          <label for="first_name">Driving License No</label>
                        </div>
                         
                        </div>    
                        <!--------------------->
                        
                        
                        
                        
                      <div class="row">
                       
                        <div class="row">
                          <div class="input-field col s12">
                            <button class="btn cyan waves-effect waves-light right"  id="btnsub" type="button"  name="btnsub">Update
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
			  <!--<div class="col s12 m6 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Registrations</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:20px;text-align:center;">SN</th>
             
                          <th style="text-align:left;">Name</th>
                         
                          <th style="text-align:left;">Mobile no</th>
                          <th style="width:75px"></th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php  //if($dri){ $i=1; foreach($dri as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:20px;text-align:center;"><?php //echo $i ?></td>
							
                                <td style="text-align:left;"><?php //echo $val->dname?> </td>
                                 
                       
                                 <td style="text-align:left;"><?php //echo $val->mobile?> </td>
								<td style="width:75px"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>services/edit/<?php echo encode($val->did); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->did);?>" href="#">
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php //$i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>-->
			  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>


	
	
	
<script >
	
	
$(document).ready(function(e) {
	///////////////////////////////////////////////////////////////////////////////////////////
	
	
	document.getElementById("mobile").maxLength = "10";
	 $('#mobile').keyup(function(){
		  
		   if(isNaN($(this).val())){
               $(this).val('');
			   $(this).focus();
			}
			
		  });
	$('select').select2({width: "100%"});
	 //selectbox();
	
	jQuery("#ownerid").change(function(t) {
    var e = $(this).val();
	  //alert(e);
    $.ajax({
        type: "post",
        url: "<?php echo ADMIN_PATH ?>services/getvehiclereg",
        data: "cid=" + e,
        success: function(t) {
			//alert(t);
			$('#vid').parent('.form-group').addClass('is-focused'); 
            $("#vid").html(t);
			  $("#vid").trigger('contentChanged');
			   $("#vid").material_select();
			  
        }
    })
});

/*$('#ownerid').change(function() {
        $.ajax({
            url: '<?php //echo ADMIN_PATH ?>services/getvehiclereg/',
            dataType: 'json',
            type: 'post',
            // This is query string i.e. country_id=123
            data: {cid : $('#ownerid').val()},
            success: function(data) {
                $('#vid').empty(); // clear the current elements in select box
                for (row in data) {
                    $('#vid').append($('<option></option>').attr('value', data[row].engineno).text(data[row].engineno));
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    });*/
	  $('.timepicker').pickatime({
    default: 'now', // Set default time: 'now', '1:30AM', '16:30'
    fromnow: 0,       // set default time to * milliseconds from now (using with default = 'now')
    twelvehour: true, // Use AM/PM or 24-hour format
    donetext: 'OK', // text for done-button
    cleartext: 'Clear', // text for clear-button
    canceltext: 'Cancel', // Text for cancel-button,
    container: undefined, // ex. 'body' will append picker to body
    autoclose: false, // automatic close timepicker
    ampmclickable: true, // make AM PM clickable
    aftershow: function(){} //Function for after opening timepicker
  });
	
	
date11();
	
	function date11(){
	$('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15, // Creates a dropdown of 15 years to control year,
    today: 'Today',
    clear: 'Clear',
    close: 'Ok',
    closeOnSelect: false, // Close upon selecting a date,
	format: 'yyyy-mm-dd',
    container: undefined // ex. 'body' will append picker to body
  });
	}
	
	$(document).on("click",".datepicker",function() {
		date11();
    });	
 $(document).on("click",".addmore",function() {
	 //date11();
		
        var tparent = $(this).parent();
        var rem='<i class="material-icons remove">cancel</i>';
        tparent.html(rem);
		var htm='<div class="box" > <div class="input-field col s12 m6 s6" id="vname"> <input type="text" value="" class="form-conrol " id="bname" name="bname[]"> <label for="first_name">Brand Name</label> </div><div class="input-field col s12 m6 s6" id="vname"> <input type="text" value="" class="form-conrol " id="model" name="model[]"> <label for="first_name">Model</label> </div><div class="input-field col s12 m6 s6" id="vname"> <input type="text" value="" class="form-conrol " id="engineno" name="engineno[]"> <label for="first_name">Engine No</label> </div><div class="input-field col s12 m6 s6" id="vname"> <input type="text" value="" class="form-conrol " id="chaiseno" name="chaiseno[]"> <label for="first_name">Chaise No</label> </div><div class="input-field col s12 m6 s6" id="vname"> <input type="text" value="" class="form-conrol " id="regno" name="regno[]"> <label for="first_name">Reg.No</label> </div><div class="input-field col s12 m6 s6" id="vname"> <select class="form-conrol" id="color" name="color[]"> <option value=""> Select Color</option> <option value="red">Red</option> <option value="blue">Blue</option> </select> </div><div class="input-field col s12 m1 s1" id="vname"> <a class="btnplus" style="right:12px"><i class="material-icons addmore">add_circle</i></a> </div></div></div>';
        /// htm+='<div class="box" ><div class="input-field col s12 m6 s6" id="vname"><input  type="text" value="" class="form-conrol " id="bname" name="bname"><label for="first_name">Brand Name</label></div><div class="input-field col s12 m6 s6" id="vname"><input  type="text" value="" class="form-conrol " id="bname" name="bname"><label for="first_name">Model</label></div><div class="input-field col s12 m6 s6" id="vname"><input  type="text" value="" class="form-conrol " id="engineno" name="engineno"><label for="first_name">Engine No</label></div><div class="input-field col s12 m6 s6" id="vname"><input  type="text" value="" class="form-conrol " id="chaiseno" name="chaiseno"><label for="first_name">Chaise No</label></div><div class="input-field col s12 m6 s6" id="vname"><input  type="text" value="" class="form-conrol " id="regno" name="regno"><label for="first_name">Reg.No</label></div>';
		 // htm+='<div class="input-field col s12 m6 s6" id="vname"><select class="form-conrol" id="color" name="color"><option value=""> Select Color</option><option value="red">Red</option><option value="blue">Blue</option></select> </div><div class="input-field col s12 m1 s1" id="vname"><a class="btnplus" style="right:12px"><i class="material-icons addmore">add_circle</i></a></div></div>';

        $('.plusbox').append(htm);
		 $('select').material_select();
		
    }) 
	 
	 
	  $(document).on("click",".remove",function() {
		 // alert('delet');
       $(this).parent().parent().parent().remove();
    });
	
	  
	
	///////////////////////////////////////////////////////////////////////////////////////////

		 $('#semail').blur(function(){
		
	
	 var pattern =/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
	// console.log(pattern.test($('#txtemail').val()))
					//	 console.log( pattern.test( $scope.chkemail));
						 if(pattern.test($('#email').val())==false){
							 $('#semail').addClass('errors');
			 				 $('#semail').parent().children('label').addClass('labelerror');
							 
						
						  }
						  else{
							  $('#semail').removeClass('errors');
			 				 $('#semail').parent().children('label').removeClass('labelerror');
							  }
	    });
	
	
 $("#btnsub").click(function(e) {
	  if($("#vid").attr("selectedIndex") == 0) {
    alert("You haven't selected anything!");
   }
	 //alert(45645);
 var e=validation();
	 if(e==0){
		 //alert(343534);
		 $('.overlay').css({'display':'flex'});
  		 var url="<?php echo ADMIN_PATH?>services/updatedriver/<?php echo encode($res->did);?>";
  		// var redirect = "<?php echo ADMIN_PATH?>services/";
  		 var form = document.forms.namedItem("frmservice");  
		 var oData = new FormData(document.forms.namedItem("frmservice"));           
         var oReq = new XMLHttpRequest();
          oReq.open("POST", url,  true);   
          oReq.onload = function(oEvent) { 
			$('.overlay').css({'display':'none'});
			//alert(oReq.responseText);
			var id=oReq.responseText;
			if(id==22)
			{swal({
  title: "Success!",
  text: "Updated successfully",
  icon: "success",
  button: "Ok",
});
location.reload() ;
			}
			else if(id==33)
			{
				swal({ 
    swal({ 
    title:"EXIST", 
    text:"Mobile Number alredy exist", 
    type:"info"  
});
			}
			//location.reload() ;
			//document.location="<?php //echo ADMIN_PATH?>services/printpdf/"+id;
					//console.log(oReq.responseText);
					 }
                oReq.send(oData);
                //ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');
        

            var values = {
                                    'sname':$('#sname').val(),
									'address':$('#address').val(),
									'mobile':$('#mobile').val(),
									'email':$('#semail').val(),
									'ownerid':$('#ownerid').val(),
									'vid':$('#vid').val(),
									'lno':$('#lno').val(),
									'password':$('#password').val(),
									'password1':$('#password1').val()
									
									
									

                                 }
								 
			if(values.sname == ''){
		   $('#sname').addClass('errors');
		   $('#sname').parent().children('label').addClass('active');
			$('#sname').attr("placeholder", "Please enter name")
		    $('#sname').parent().children('label').addClass('labelerror');
            error=1;
        } 
			if(values.address == ''){
		     $('#address').addClass('errors');
			 $('#address').parent().children('label').addClass('active');
			$('#address').attr("placeholder", "Please enter address")
		    $('#address').parent().children('label').addClass('labelerror');
            error=1;
        } 				 
			if(values.email == ''){
		   $('#semail').addClass('errors');
			$('#semail').attr("placeholder", "Please enter valid mail id")
			$('#semail').parent().children('label').addClass('active');
		    $('#semail').parent().children('label').addClass('labelerror');
            error=1;
        } 
		 if(values.mobile == ''){
            $('#mobile').addClass('errors');
            $('#mobile').attr("placeholder", "Please enter Mobile No.")
			 $('#mobile').parent().children('label').addClass('active');
		    $('#mobile').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.lno == ''){
            $('#lno').addClass('errors');
            $('#lno').attr("placeholder", "Please enter Licence No.")
			 $('#lno').parent().children('label').addClass('active');
		    $('#lno').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.ownerid == ''){
            $('#ownerid').addClass('errors');
            $('#ownerid').attr("placeholder", "Please select owner ID.")
			 $('#ownerid').parent().children('label').addClass('active');
		    $('#ownerid').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		if(values.vid == ''){
            $('#vid').addClass('errors');
            $('#vid').attr("placeholder", "Please select owner ID.")
			 $('#vid').parent().children('label').addClass('active');
		    $('#vid').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		if(values.password.trim() == ''){
			  $('#password').addClass('errors');
		   $('#password').parent().children('label').addClass('active');
			$('#password').attr("placeholder", "Please enter password")
		    $('#password').parent().children('label').addClass('labelerror');
            error=1;        } 
			
		if(values.password != values.password1 ){
 $('#password').addClass('errors');
		   $('#password').parent().children('label').addClass('active');
		    $('#password').val('');
			$('#password').attr("placeholder", "Password Mismatch")
		    $('#password').parent().children('label').addClass('labelerror');
            error=1;        } 
		 
		
		
		
      
        return error;
    }
	
	
});
	// ---------- < Delete service   > ---------- //

$(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
				
 swal({
		title: 'Are you sure?',
		text: "You won't be able to revert this!",
		type: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#3085d6',
		cancelButtonColor: '#d33',
		confirmButtonText: 'Yes, delete it!'
	}).then(function () {
						 $.ajax({
                         type:"post",
                         url: "<?php echo ADMIN_PATH ?>services/deletedri",
                         data:"id="+id,
						 success:function(data){ 											
												 swal(
														'Deleted!',
														'Your file has been deleted.',
														'success'
													 )
														location.reload() ;
	
											   }
			    
	});
  	})                    
			  
});	
		
		
	</script>
    
      





    




    
    
    
    
    
    
    
    
    

