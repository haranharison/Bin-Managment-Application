

  <style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
	float:right;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
.file-field .btn {
        float: right;
    position: relative;
}
/*.vname{
display:none;	
	}*/
	#vmid{
display:none;	
	}
</style>
 <!--breadcrumbs start-->
          <!--breadcrumbs end-->

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m6 l6 ">
                <div class="card-panel">
				<h4 class="header2">Trip Sheet</h4>
                  <div class="row">
                  <form role="form" name="frmservice" id="frmservice"  method="post" enctype="multipart/form-data">
                      <div class="row">                    
                            <div class="input-field col s12 m6 s6" id="vname">
                        <select name="brand" id="brand">
                          <option value="0">Select Brand</option>
                          <?php if(!empty($brand)){ foreach($brand as $val){ ?>
                          <option value="<?php echo encode($val->man_id);?>"><?php echo $val->man_title ?></option>
                         <?php } }?>
                          </select>
                        </div>   
                        
                         <div class="input-field col s12 m6 s6" id="vname">
                        <select name="model" id="model">
                          <option value="0">Select model</option>
                         
                          </select>
                        </div>                 
                        
                        <div class="input-field col s12 m6 s6" id="vname">
                        
                          	<input  type="text" placeholder="Name" id="sname" name="sname">
                            
                          <label for="first_name">Client Name</label>
                        </div>
                        
                        <div class="input-field col s12 m6 s6" id="vname">
                        
                          	<input  type="text" placeholder="Client Id" id="cid" name="cid">
                            
                          <label for="first_name">Client Id</label>
                        </div>
                                                                    
                        
                        <div class="input-field col s12 m6 s6">
                          	<input  type="number" placeholder="Starting km" id="s_km" name="s_km">
                          <label for="first_name">Starting km</label>
                        </div>
                        <div class="input-field col s12 m6 s6">
                          	<input  type="number" placeholder="Ending km" id="e_km" name="e_km">
                          <label for="first_name">Ending km</label>
                        </div>
                         <div class="input-field col s12 m6 s6">
                          	<input  type="text"  class="timepicker" placeholder="Waiting time" id="w_time" name="w_time">
                          <label for="first_name">Waiting time</label>
                        </div>
                         <div class="input-field col s12 m6 s6">
                          	<input readonly="readonly" type="number" placeholder="Minimum charge" id="m_charge" name="m_charge">
                          <label for="first_name">Minimum charge</label>
                        </div>
                       
                                  </div>
                      
                      <div class="row">
                       
                        <div class="row">
                          <div class="input-field col s12">
                            <button class="btn cyan waves-effect waves-light right"  id="btnsub" type="button"  name="btnsubmit">Submit
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
			  <div class="col s12 m6 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Trip Sheet</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:20px;text-align:center;">SN</th>
                          <th style="text-align:left;">Client Id</th>
                          <th style="text-align:left;">Client Name</th>
                         <th style="width:75px">Action</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php  if($details){ $i=1; foreach($details as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:20px;text-align:center;"><?php echo $i ?></td>
								<td style="text-align:left;"><?php echo $val->c_id?> </td>
                                <td style="text-align:left;"><?php echo $val->c_name?> </td>
                               
								<td style="width:75px"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>charge/view/<?php echo encode($val->min_id); ?>">
										<i class="material-icons">remove_red_eye</i>
									</a>
                                    
									<!--<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php /*echo encode($val->ser_id);*/?>" href="#">
										<i class="material-icons">delete</i>
									</a>-->
                                
                                </td>
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
			  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>


	
	
	
<script >




	
	
	
	
$(document).ready(function(e) {
	
  $(document).on('change','#model', function()
{


var brand=$('#brand').val();

  var model=$('#model').val();	
	$.ajax({
		type:'post',
		url:"<?php echo ADMIN_PATH ?>charge/get_mincharge",
		data:"brand="+brand+"&model="+model,
	
		success:function(data)
		{
			if(data=='error')
			{
				customSwalFunD("error", "minimum charge not available");	
				}
				else{
			console.log(data);
			// $('.overlay').css({'display':'none'});
               $('#m_charge').val(data);
				}
			
		}
	
	});
				
});

	
	
	 $('.timepicker').pickatime({
    default: 'now', // Set default time: 'now', '1:30AM', '16:30'
    fromnow: 0,       // set default time to * milliseconds from now (using with default = 'now')
    twelvehour: false, // Use AM/PM or 24-hour format
    donetext: 'OK', // text for done-button
    cleartext: 'Clear', // text for clear-button
    canceltext: 'Cancel', // Text for cancel-button,
    container: undefined, // ex. 'body' will append picker to body
    autoclose: false, // automatic close timepicker
    ampmclickable: true, // make AM PM clickable
    aftershow: function(){} //Function for after opening timepicker
  });
  
  
  
	 $('#brand').change(function(){
			var brand=$(this).val(); 
	$.ajax({
                         type:"post",
                         url: "<?php echo ADMIN_PATH ?>charge/getmodel",
                         data:"brand="+brand,
						 success:function(data){ 	
						 
						   $('#model').material_select('destroy');
               $('#model').html(data);
               $('#model').material_select();							
												
	
											   }
			    
	});
	
	 });
	
		 /*$('#w_time').change(function(){
			 
			  var brand=$('#brand').val();
			  var model=$('#model').val();
			// var w_time=$('#w_time').val();
			
			if(brand!='' && model!='' ){
			  $.ajax({
                         type:"post",
                         url: "<?php /*echo ADMIN_PATH*/ ?>charge/getmin_charge",
                         data:"brand="+brand+"&model="+model,
						 success:function(data){ 											
												 
	alert(data);
						  // $('#model').material_select('destroy');
               $('#m_charge').val(data);
              // $('#model').material_select();							
												
											   }
			    
	});
			}
			
			 });*/
		
		 
			 
	
       	 $("#btnsub").click(function(e) {
			 
			var e=validation();
		 
			if(e==0){
					$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>charge/insert";
  			var redirect = "<?php echo ADMIN_PATH?>charge";
  			var form = document.forms.namedItem("frmservice");  
		              
			var oData = new FormData(document.forms.namedItem("frmservice"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { 
					$('.overlay').css({'display':'none'});
					
					document.location="<?php echo ADMIN_PATH?>charge/mypdf/"+oReq.responseText;
					console.log(oReq.responseText);
					 }
                oReq.send(oData);
                //ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');
        

            var values = {
                                    'sname':$('#sname').val(),
									'cid':$('#cid').val(),
									's_km':$('#s_km').val(),
									'e_km':$('#e_km').val(),
									'w_time':$('#w_time').val(),
									'm_charge':$('#m_charge').val()

                                 }
								 
			if(values.sname == ''){
		   $('#sname').addClass('errors');
			$('#sname').attr("placeholder", "Please enter name")
		    $('#sname').parent().children('label').addClass('labelerror');
            error=1;
        } 
							 
			
			 if(values.cid == ''){
		     $('#cid').addClass('errors');
			$('#cid').attr("placeholder", "Please enter client id")
		    $('#cid').parent().children('label').addClass('labelerror');
            error=1;
        } 
			  if(values.product == ''){
            $('#product').addClass('errors');
			$('#product').attr("placeholder", "Please enter product")
		    $('#product').parent().children('label').addClass('labelerror');
            error=1;
        } 

        if(values.s_km == ''){
            $('#s_km').addClass('errors');
			$('#s_km').attr("placeholder", "Please enter starting km")
		    $('#s_km').parent().children('label').addClass('labelerror active');
            error=1;
        } 
		
		  if(values.e_km == ''){
            $('#e_km').addClass('errors');
			$('#e_km').attr("placeholder", "Please enter ending km")
		    $('#e_km').parent().children('label').addClass('labelerror active');
            error=1;
        } 
		
				
		if(values.w_time == ''){
            $('#w_time').addClass('errors');
            $('#w_time').attr("placeholder", "Please enter waiting time")
		    $('#w_time').parent().children('label').addClass('labelerror active');
            error=1;
        } 
		
         	if(values.m_charge == ''){
            $('#m_charge').addClass('errors');
            $('#m_charge').attr("placeholder", "Please enter minimum charge")
		    $('#m_charge').parent().children('label').addClass('labelerror active');
            error=1;
        } 
		
	

        return error;
    }
	
	
});
	// ---------- < Delete service   > ---------- //

$(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
				
 swal({
		title: 'Are you sure?',
		text: "You won't be able to revert this!",
		type: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#3085d6',
		cancelButtonColor: '#d33',
		confirmButtonText: 'Yes, delete it!'
	}).then(function () {
						 $.ajax({
                         type:"post",
                         url: "<?php echo ADMIN_PATH ?>service/deleteService",
                         data:"id="+id,
						 success:function(data){ 											
												 swal(
														'Deleted!',
														'Your file has been deleted.',
														'success'
													 )
														location.reload() ;
	
											   }
			    
	});
  	})                    
			  
});	
		
		
	</script>
    
      





    




    
    
    
    
    
    
    
    
    

