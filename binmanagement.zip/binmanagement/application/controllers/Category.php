<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Category_model','model');
	 }	
	 public function index()
	{
		$data['menu']='organizer';
		$data['submenu']='category';
		$data['category']=$this->model->getcategory();
		$this->load->view('admin/header',$data);
		$this->load->view('admin/category/categoryadd',$data);
		$this->load->view('admin/footer');
	}
	
	public function addcategory(){
	$this->model->addcategory();	
	}
	public function editCategories($id=false){
	$data['menu']='organizer';
	$data['submenu']='category';
	$data['edit']=$this->model->editcategory($id);
	$data['category']=$this->model->getcategory();
		$this->load->view('admin/header',$data);
		if(empty($data['edit']))
		{
			$data['heading']='Message';
			$data['message']='An uncaught Exception was encountered.Please try again';
			$this->load->view('errors/html/error_general',$data);
		}
		else{
		$this->load->view('admin/category/edit',$data);
		}
		$this->load->view('admin/footer');
		}
		
	public function updatecategory(){
		$this->model->updatecategory();	
	}

	public function deleteCategories(){
		$this->model->deleteCategories();
		}
	

	
}

