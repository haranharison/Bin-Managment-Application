<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Salesmanproduct extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->load->model('Salesmanproduct_model','model');
	 }	public function index()
	{
		$this->load->view('admin/header');
		$this->load->view('admin/salesmanproductsadd ');
		$this->load->view('admin/footer');
	}
}
