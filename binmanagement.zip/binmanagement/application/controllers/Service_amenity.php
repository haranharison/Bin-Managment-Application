<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Service_amenity extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Service_amenity_model','model');
	 }	
	 public function index()
	{
		//product list & adding page
		$headdata['status']='active';
		$data['item']=$this->model->getitemstitle();//fetch all category
		$data['am']=$this->model->getamenity();
	$data['amenity']=$this->model->getamenitytitle();//fetched all product from tables
	    $headdata['menu']='s_amenity';
		$headdata['submenu']='s_amenity';
		$this->load->view('admin/header',$headdata);
		$this->load->view('admin/serviceamenity/service_amenity',$data);
		$this->load->view('admin/footer');
	}
	 public function insert()
	{
		$this->model->insert();
		}
	
	
}

