<?php
class Salesmanlocation_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        
		  public function getsalesman(){
		 $array=array('tbl_salesmanreg.status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_salesmanreg');
		return $result = $this->db->get()->result(); 
		
		}     
		public function getarea(){
		 $array=array('tbl_area.status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_area');
		return $result = $this->db->get()->result(); 
		
		}    
		
		
public function getlocbysid(){
			$sid=$this->input->post('sid');
			$date=$this->input->post('date');
			$array=array('tbl_salesmanreg.status'=>0,'tbl_salesmanreg.salesmanid'=>$sid);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_salesmanreg');
		 $result = $this->db->get()->result(); 
		$uname=$result[0]->name;
		// echo $uname;
			
		 $array=array('tbl_routehistory.status'=>0,'tbl_routehistory.username'=>$uname,'tbl_routehistory.created_date'=>$date);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_routehistory');
		
		$result=$this->db->get();
       		$rows=$result->result();
			
		$html='';
				if($result->num_rows() > 0)
				{
						//$html.='<td></td>';
				$i=1;	
					foreach($rows as $val =>$key)
					{
						
						$html.='<tr><td>'.$i.'</td>';
						$html.='<td>'.$key->username.'</td>';
						$html.='<td>'.$key->latitude.'</td>';
						$html.='<td>'.$key->longitude.'</td>';
						$html.='<td>'.$key->created_time.'</td>';
						$html.='<td>'.$key->created_date.'</td>';
						$html.='<td><input type="button" name="vmap" value="View Map" class="vwmap"  /></td>';
						
						$i=$i+1;
					}
				}else{
					$html.='<td>-- No result  --</td>';
						}
						
			echo $html;
		
		}  
		
	
			
		
}