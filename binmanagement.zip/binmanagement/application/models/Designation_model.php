<?php
class Designation_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        public function getdesig()
		{
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_designation')->result();
		}
		
		public function adddesi(){
			
			$exist=fieldexist2('tbl_designation','desi_name',$this->input->post('desiname'));
		if($exist==1){
			echo 1;
		}else{
			
			
			$max=maxplus('tbl_designation','desi_id');
			$today= date("y-m-d");
			$desi_name=$this->input->post('desiname');
			
			$data= array(
			'org_id'=>$this->session->userdata('org_id'),
			'desi_id' =>$max,
		    'desi_name'=>$desi_name,
			'created_date'=>$today,
			'modified_date'=>$today
		);
		$this->db->insert('tbl_designation',$data);
		}
		}
public function getdesi()
	{
		$eid=decode($this->input->post('eid'));
		$array=array('desi_id'=>$eid,'status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('desi_name');
		$rows=$this->db->get('tbl_designation')->row();
		$a=array('name'=>$rows->desi_name);
		 echo json_encode($a);
	
		 
	}	
	
	public function updatedesi()
	{
		$eid=decode($this->input->post('eid'));
		$txtdname=$this->input->post('txtdname');
		$data=array('desi_name'=>$txtdname);
		$array=array('desi_id'=>$eid,'status'=>0);
		$this->db->where($array);
		$this->db->update('tbl_designation',$data);
		 echo 1;
		 
	}		
	//Delete Product incom	
		public function deletedesi(){
		 	$cid=$this->input->post('id');
		   $data=array('status'=>1);
		   $array= array('desi_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_designation',$data);
		}
}