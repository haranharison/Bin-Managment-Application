<?php
class Salesmanreport_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
      public function getsalesman(){
		 $array=array('tbl_salesmanreg.status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_salesmanreg');
		return $result = $this->db->get()->result(); 
		
		}     
		
		public function getarea(){
		 $array=array('tbl_area.status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_area');
		return $result = $this->db->get()->result(); 
		
		}     
		public function getmerchant(){
		 $array=array('tbl_merchant.status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_merchant');
		return $result = $this->db->get()->result(); 
		
		}  
		
		public function getdetailsbysid(){
			$sid=$this->input->post('sid');
		 $array=array('tbl_cashcollect.status'=>0,'tbl_cashcollect.salesman_id'=>$sid);
		$this->db->where($array);
		$this->db->select('tbl_cashcollect.*,tbl_salesmanreg.salesmanid,tbl_salesmanreg.name,tbl_merchant.merchant_id,tbl_merchant.merchantname,');
		$this->db->from('tbl_cashcollect');
		//$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesproduct.area' );
		$this->db->join ( 'tbl_salesmanreg as tbl_salesmanreg', 'tbl_salesmanreg.salesmanid = tbl_cashcollect.salesman_id' );
		$this->db->join ( 'tbl_merchant as tbl_merchant', 'tbl_merchant.merchant_id = tbl_cashcollect.merchant_id' );
		$result=$this->db->get();
       		$rows=$result->result();
			//echo $result;
		//$result = $this->db->get()->result(); 
		
		    //$this->db->from ( 'tbl_salesmanreg' );
			//$this->db->group_by('salesmanid');
		//	$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesmanreg.area' );
		$html='';
				if($result->num_rows() > 0)
				{
						//$html.='<td></td>';
						$i=1;
					foreach($rows as $val =>$key)
					{
						$type="";
						if($key->type==1)
						{
							$type="Check";
						}
						else{
							$type="Cash";
						}
						$html.='<tr><td>'.$i.'</td>';
						$html.='<td>'.$key->name.'</td>';
						$html.='<td>'.$key->merchantname.'</td>';
						$html.='<td>'.$key->amount.'</td>';
						$html.='<td>'.$type.'</td>';
						$html.='<td>'.$key->bank.'</td></tr>';
						
						$i=$i+1;
					}
				}else{
					$html.='<td>-- No result  --</td>';
						}
			echo $html;
		
		}  
		
			public function getdetailsbydate(){
				
				
				$date=$this->input->post('date');
		 $array=array('tbl_cashcollect.status'=>0,'tbl_cashcollect.create_date'=>$date);
		$this->db->where($array);
		$this->db->select('tbl_cashcollect.*,tbl_salesmanreg.salesmanid,tbl_salesmanreg.name,tbl_merchant.merchant_id,tbl_merchant.merchantname,');
		$this->db->from('tbl_cashcollect');
		//$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesproduct.area' );
		$this->db->join ( 'tbl_salesmanreg as tbl_salesmanreg', 'tbl_salesmanreg.salesmanid = tbl_cashcollect.salesman_id' );
		$this->db->join ( 'tbl_merchant as tbl_merchant', 'tbl_merchant.merchant_id = tbl_cashcollect.merchant_id' );
		$result=$this->db->get();
       		$rows=$result->result();
			//echo $result;
		//$result = $this->db->get()->result(); 
		
		    //$this->db->from ( 'tbl_salesmanreg' );
			//$this->db->group_by('salesmanid');
		//	$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesmanreg.area' );
		$html='';
				if($result->num_rows() > 0)
				{
						//$html.='<td></td>';
						$i=1;
					foreach($rows as $val =>$key)
					{
						$type="";
						if($key->type==1)
						{
							$type="Check";
						}
						else{
							$type="Cash";
						}
						$html.='<tr><td>'.$i.'</td>';
						$html.='<td>'.$key->name.'</td>';
						$html.='<td>'.$key->merchantname.'</td>';
						$html.='<td>'.$key->amount.'</td>';
						$html.='<td>'.$type.'</td>';
						$html.='<td>'.$key->bank.'</td></tr>';
						
						$i=$i+1;
					}
				}else{
					$html.='<td>-- No result  --</td>';
						}
			echo $html;
		
				
				}
	
		public function getdetailsbyarea(){
				
				
				$area=$this->input->post('area');
		 $array=array('tbl_cashcollect.status'=>0,'tbl_cashcollect.area_id'=>$area);
		$this->db->where($array);
		$this->db->select('tbl_cashcollect.*,tbl_salesmanreg.salesmanid,tbl_salesmanreg.name,tbl_merchant.merchant_id,tbl_merchant.merchantname,');
		$this->db->from('tbl_cashcollect');
		//$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesproduct.area' );
		$this->db->join ( 'tbl_salesmanreg as tbl_salesmanreg', 'tbl_salesmanreg.salesmanid = tbl_cashcollect.salesman_id' );
		$this->db->join ( 'tbl_merchant as tbl_merchant', 'tbl_merchant.merchant_id = tbl_cashcollect.merchant_id' );
		$result=$this->db->get();
       		$rows=$result->result();
			//echo $result;
		//$result = $this->db->get()->result(); 
		
		    //$this->db->from ( 'tbl_salesmanreg' );
			//$this->db->group_by('salesmanid');
		//	$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesmanreg.area' );
		$html='';
				if($result->num_rows() > 0)
				{
						//$html.='<td></td>';
						$i=1;
					foreach($rows as $val =>$key)
					{
						$type="";
						if($key->type==1)
						{
							$type="Check";
						}
						else{
							$type="Cash";
						}
						$html.='<tr><td>'.$i.'</td>';
						$html.='<td>'.$key->name.'</td>';
						$html.='<td>'.$key->merchantname.'</td>';
						$html.='<td>'.$key->amount.'</td>';
						$html.='<td>'.$type.'</td>';
						$html.='<td>'.$key->bank.'</td></tr>';
						
						$i=$i+1;
					}
				}else{
					$html.='<td>-- No result  --</td>';
						}
			echo $html;
		
				
				}
	public function getdetailsbymid(){
				
				
				$mid=$this->input->post('mid');
		 $array=array('tbl_cashcollect.status'=>0,'tbl_cashcollect.merchant_id'=>$mid);
		$this->db->where($array);
		$this->db->select('tbl_cashcollect.*,tbl_salesmanreg.salesmanid,tbl_salesmanreg.name,tbl_merchant.merchant_id,tbl_merchant.merchantname,');
		$this->db->from('tbl_cashcollect');
		//$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesproduct.area' );
		$this->db->join ( 'tbl_salesmanreg as tbl_salesmanreg', 'tbl_salesmanreg.salesmanid = tbl_cashcollect.salesman_id' );
		$this->db->join ( 'tbl_merchant as tbl_merchant', 'tbl_merchant.merchant_id = tbl_cashcollect.merchant_id' );
		$result=$this->db->get();
       		$rows=$result->result();
			//echo $result;
		//$result = $this->db->get()->result(); 
		
		    //$this->db->from ( 'tbl_salesmanreg' );
			//$this->db->group_by('salesmanid');
		//	$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesmanreg.area' );
		$html='';
				if($result->num_rows() > 0)
				{
						//$html.='<td></td>';
						$i=1;
					foreach($rows as $val =>$key)
					{
						$type="";
						if($key->type==1)
						{
							$type="Check";
						}
						else{
							$type="Cash";
						}
						$html.='<tr><td>'.$i.'</td>';
						$html.='<td>'.$key->name.'</td>';
						$html.='<td>'.$key->merchantname.'</td>';
						$html.='<td>'.$key->amount.'</td>';
						$html.='<td>'.$type.'</td>';
						$html.='<td>'.$key->bank.'</td></tr>';
						
						$i=$i+1;
					}
				}else{
					$html.='<td>-- No result  --</td>';
						}
			echo $html;
		
				
				}
}