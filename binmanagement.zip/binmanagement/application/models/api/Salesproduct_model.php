<?php
class Salesproduct_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
      
	 public function getmerchant(){
		 $merid=$this->input->post('merid');
		 $array=array('tbl_merchant.status'=>0,'tbl_merchant.merchantid_num'=>$merid);
		$this->db->where($array);
		$this->db->select('*');
		//$this->db->from('tbl_merchant');
		 $query = $this->db->get('tbl_merchant'); 
		$result=$query->result();
		if($query->num_rows() >0){
			$this->output->set_output(json_encode($result));	
		}
		else{
				$this->output->set_output(json_encode(2));
				}
		}  
		
		 public function getproductbyid(){
		 
		
		$array=array('tbl_salesmanproduct.status'=>0,'tbl_salesmanproduct.salesman_id'=>$this->input->post('salesmanid'));
		$this->db->where($array);
	
		$this->db->select('tbl_salesmanproduct.*,tbl_product.product_id,tbl_product.product_name,tbl_product.amount');
		$this->db->from('tbl_salesmanproduct');

		$this->db->join ( 'tbl_product as tbl_product', 'tbl_product.product_id = tbl_salesmanproduct.salesman_product' );
		 $result = $this->db->get()->result(); 
		
			$this->output->set_output(json_encode($result));	
		}  
	  public function getamountbyproid(){
		 $array=array('tbl_product.status'=>0,'tbl_product.product_id'=>$this->input->post('productid'));
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_product');
		 $result = $this->db->get()->result(); 
		
		
			$this->output->set_output(json_encode($result));	
		}  
	    
		public function addsalesproduct(){
				//$prodetails=$this->input->post('saleslist');
			 $prodetails=$this->input->post('saleslist');
			echo $prodetails;
			//$params = json_decode(file_get_contents('php://input'),true);
		$mode=$this->input->post('mode');
		//$exist=fieldexist('tbl_merchant','merchantname',$this->input->post('txtmerchantname'));
	if($mode==1){
		
	//date("Y-m-d H:i:s");
	

$date= date("Y-m-d");
	$today= $this->input->post('currentdate');
	$time = strtotime($today);
$newformat = date('H:i:s',$time);
//echo $date->format('Y-m-d');
		$max=maxplus('tbl_salesproduct','salesproduct_id');
		
		$salesmanid=$this->input->post('salesmanid');
		$merchant_id=$this->input->post('merchant');
		$area_id=$this->input->post('area');
		/*$product_id=$this->input->post('product');
		$proamount=$this->input->post('proamnt');
		$numofitem=$this->input->post('numofitem');*/
		$totalamount=$this->input->post('totalamnt');
		$mode=$this->input->post('mode');
		$termradio=$this->input->post('termradio');
		$data= array(
		       'salesproduct_id'=>$max,
			   'merchant_id'=>$merchant_id,
			   'salesman_id'=>$salesmanid,
			   'area_id'=>$area_id,
			   /*'product_id'=>$product_id,
			    'proamount'=>$proamount,
			   'numofitem'=>$numofitem,*/
			   'totalamount'=>$totalamount,
			    'terminal'=>$termradio,
			    'mode'=>$mode,
				 'type'=>'',
				 'chequeno'=>'',
			   'bank'=>'',
			   'branch'=>'',
			    'date'=>'',
				'create_time'=>$newformat,
			   'create_date'=>$date,
			   'modify_date'=>$date
		);
		$this->db->insert('tbl_salesproduct',$data);
		
		if($this->input->post('mode')==1){
			
			$merchant_id=$this->input->post('merchant');
			
			
		$opnbal=$this->input->post('opnbal')+$this->input->post('totalamnt');
		 $data=array('tbl_opening_balance.openingbalance'=>$opnbal);
		   $array= array('tbl_opening_balance.merchant'=>$merchant_id,'tbl_opening_balance.status'=>0);
		   $this->db->where($array);
		   $this->db->update('tbl_opening_balance',$data);	
			
			}
		  $this->output->set_output(json_encode(2)); 
		}
		$type=$this->input->post('type');
		if($mode==2 && $type ==1){
			$today= $this->input->post('currentdate');
	$time = strtotime($today);
$newformat = date('H:i:s',$time);
			$max=maxplus('tbl_salesproduct','salesproduct_id');
		$today= date("y-m-d");
		$salesmanid=$this->input->post('salesmanid');
		$merchant_id=$this->input->post('merchant');
		$area=$this->input->post('area');
		/*$product_id=$this->input->post('product');
		$proamount=$this->input->post('proamnt');
		$numofitem=$this->input->post('numofitem');*/
		$totalamount=$this->input->post('totalamnt');
		$mode=$this->input->post('mode');
		$termradio=$this->input->post('termradio');
		$type=$this->input->post('type');
		$data= array(
		       'salesproduct_id'=>$max,
			   'merchant_id'=>$merchant_id,
			   'salesman_id'=>$salesmanid,
			    'area_id'=>$area,
			   /*'product_id'=>$product_id,
			    'proamount'=>$proamount,
			   'numofitem'=>$numofitem,*/
			   'totalamount'=>$totalamount,
			    'mode'=>$mode,
				 'type'=>$type,
				 'chequeno'=>'',
			   'bank'=>'',
			   'branch'=>'',
			    'date'=>'',
				  'terminal'=>$termradio,
				  'create_time'=>$newformat,
			   'create_date'=>$today,
			   'modify_date'=>$today
		);
		$this->db->insert('tbl_salesproduct',$data);
		
		$this->output->set_output(json_encode(2));
			}
			$type=$this->input->post('type');
			$mode=$this->input->post('mode');
			
			if($mode==2 && $type==2){
			$today= $this->input->post('currentdate');
	$time = strtotime($today);
$newformat = date('H:i:s',$time);
			$max=maxplus('tbl_salesproduct','salesproduct_id');
		$today= date("y-m-d");
		$salesmanid=$this->input->post('salesmanid');
		$merchant_id=$this->input->post('merchant');
		$area_id=$this->input->post('area');
		/*$product_id=$this->input->post('product');
		$proamount=$this->input->post('proamnt');
		$numofitem=$this->input->post('numofitem');*/
		$totalamount=$this->input->post('totalamnt');
		$mode=$this->input->post('mode');
		$type=$this->input->post('type');
		$chequeno=$this->input->post('chequeno');
		$date=$this->input->post('date');
		$bank=$this->input->post('bank');
		$termradio=$this->input->post('termradio');
		$branch=$this->input->post('branch');
		$data= array(
		       'salesproduct_id'=>$max,
			   'merchant_id'=>$merchant_id,
			   'salesman_id'=>$salesmanid,
			 //  'product_id'=>$product_id,
			    'area_id'=>$area_id,
			 //  'proamount'=>$proamount,
			//   'numofitem'=>$numofitem,
			   'totalamount'=>$totalamount,
			   'mode'=>$mode,
			   'type'=>$type,
			   'chequeno'=>$chequeno,
			   'bank'=>$bank,
			   'branch'=>$branch,
			   'date'=>$date,
			    'terminal'=>$termradio,
				'create_time'=>$newformat,
			   'create_date'=>$today,
			   'modify_date'=>$today
		);
		$this->db->insert('tbl_salesproduct',$data);
		
	       $this->output->set_output(json_encode(2));
			}
		// $json = $this->input->post('saleslist');
		 
		 /*foreach($this->input->post('saleslist') as $tid){
			 //$data['empid'];
			 $maxid=maxplus('tbl_salesdetails','salesdetails_id');
			 $today= date("y-m-d");
			 
			$productid=$this->input->post('productid');
			$nofitem=$this->input->post('nofitem');
			 $totalamount=$this->input->post('totalamount');
			 
			 $data= array(
		       'sales_id'=>$max,
			   'salesdetails_id'=>$maxid,
			   'product_id'=>$productid,
			    'numofpro'=>$nofitem,
				'amount'=>$totalamount,
			   'create_date'=>$today,
			   'modify_date'=>$today
		);
		$this->db->insert('tbl_salesproduct',$data);
		
			 
			 }*/
		 
 //$obj = json_decode($json,true);
		//echo $this->output->set_output(json_decode($json));
		
		}  
		  public function getopeningbalbyid(){
	//	echo  $this->input->post('id');
		
		 $array=array('tbl_opening_balance.status'=>0,'tbl_opening_balance.merchant'=>$this->input->post('id'));
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_opening_balance');
		 $result = $this->db->get()->result(); 
		
		
			$this->output->set_output(json_encode($result));	
		}  
		
		 public function getlocationbyid(){
	//	echo  $this->input->post('id');
		
		$array=array('tbl_merchant.status'=>0,'tbl_merchant.merchant_id'=>$this->input->post('id'));
		$this->db->where($array);
	//$this->db->group_by('tbl_merchant.merchant_id');
		$this->db->select('tbl_merchant.*,tbl_area.area_id,tbl_area.area_name');
		$this->db->from('tbl_merchant');

		$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_merchant.location' );
		 $result = $this->db->get()->result(); 
			
			$this->output->set_output(json_encode($result));	
		}  
	  
}