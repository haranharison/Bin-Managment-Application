

          <!--breadcrumbs end-->
<style>
.picker__table th{
	color:#fff !important;
}
</style>
<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  <!-- Form with placeholder -->
                  <div class="col s12 m12 l4">
                <div class="card-panel">
                   <h4 class="header2">Route History</h4>
                  <div class="row">
                  <!--FORM Report ADD-->
                   <form role="form" action="" name="frmopeningbalance" id="frmopeningbalance">
                    <!-- Sales man-->
                 <div class="row">
                            <div class="input-field col s12">
									<select class="form-control form-control1" name="selsalesman" id="selsalesman">
                                    	<option value="0"> Salesman</option>
											  <?php foreach($salesman as $val){?>
											<option value="<?php  echo $val->salesmanid?>"><?php  echo $val->name?></option>
											<?php  }?>
									</select>
                              		<!--<label for="select Salesman">Salesman</label>-->
                            </div>
                             <div class="input-field col s12">
                             <input type="text" class="datepicker" id="date" name="date">
                              <label for="txtdate">Date</label>
                            </div>
                            
                        </div>
                     <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnsubmit" style="margin-right:9px;">Submit
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                            <div id="total" style="padding:10px;"></div>
                             <div id="directions-panel" style="padding:10px;"></div>
                          </div>
                    </form>
                  </div>
                </div>
              </div>
              
           <div class="col s12 m12 l8">
               <div class="card-panel">
                  <div class="row">
                      <div id="map" style="height:500px;width:100%;"></div>              		
                  </div>
             	</div>
          </div>
</div>     
        
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->
 
  
<script>

$(document).ready(function(e) {
	$('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15, // Creates a dropdown of 15 years to control year,
    today: 'Today',
    clear: 'Clear',
    close: 'Ok',
    closeOnSelect: false, // Close upon selecting a date,
	format: 'yyyy-mm-dd',
    container: undefined // ex. 'body' will append picker to body
  });


						
		$(document).ready(function(e) {	
		
		<!---- salesman wise report----->				
$("#selsalesman").change(function(e) {
	var sid=$( this).val();
			 	$.ajax({
			   	type:"post",
			   	url:"<?php echo ADMIN_PATH;?>currentlocation/location",
			  	data:"sid="+sid,
				success:function(data){
					//alert(data);
					$("#dat").html(data);
					}		   
			   			});
        });
	
		   });
						</script>
   <script>
    $(document).ready(function(e) {
		
		$('#btnsubmit').click(function(e) {
            initMap();
        });
		
        
    });
      function initMap() {
        var directionsService = new google.maps.DirectionsService;
        var directionsDisplay = new google.maps.DirectionsRenderer;
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 6,
          center: {lat: 8.8932, lng: 76.6141}
        });
        directionsDisplay.setMap(map);
       calculateAndDisplayRoute(directionsService, directionsDisplay);
        
      }

      function calculateAndDisplayRoute(directionsService, directionsDisplay) {
        var waypts = [];
		 waypts.push({
              location: {lat: 8.8932, lng: 76.6141},
              stopover: true
            });
			 
			 waypts.push({
              location: {lat: 9.0017, lng: 76.8002},
              stopover: true
            });
			waypts.push({
              location: {lat: 8.9602, lng: 76.6788},
              stopover: true
            });
			waypts.push({
              location: {lat: 8.9162, lng: 76.7668},
              stopover: true
            });
			
			
			
			  
			 
			 
        /*var checkboxArray = document.getElementById('waypoints');
        for (var i = 0; i < checkboxArray.length; i++) {
          if (checkboxArray.options[i].selected) {
            waypts.push({
              location: checkboxArray[i].value,
              stopover: true
            });
          }
        }*/

        directionsService.route({
          origin: {lat: 8.8932, lng: 76.6141},
          destination: {lat: 9.0654, lng: 76.5315},
          waypoints: waypts,
          optimizeWaypoints: true,
          travelMode: 'DRIVING'
        }, function(response, status) {
          if (status === 'OK') {
            directionsDisplay.setDirections(response);
            var route = response.routes[0];
            var summaryPanel = document.getElementById('directions-panel');
            summaryPanel.innerHTML = '';
            // For each route, display summary information.
			var distance=0;
            for (var i = 0; i < route.legs.length; i++) {
              var routeSegment = i + 1;
              summaryPanel.innerHTML += '<b>Route Segment: ' + routeSegment +
                  '</b><br>';
              summaryPanel.innerHTML += route.legs[i].start_address + ' to ';
              summaryPanel.innerHTML += route.legs[i].end_address + '<br>';
              summaryPanel.innerHTML += route.legs[i].distance.text + '<br><br>';
			  distance=parseFloat(distance)+parseFloat(route.legs[i].distance.text)
			  
            }
			$('#total').html('<b>Total Distance: ' + distance +
                  'Km</b><br>')
			console.log(distance);
          } else {
            window.alert('Directions request failed due to ' + status);
          }
        });
      }
    </script>
   