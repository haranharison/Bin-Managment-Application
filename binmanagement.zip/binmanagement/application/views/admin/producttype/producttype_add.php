

<!--start container-->
          <div class="container">
            <div class="section">
              <!-- Form with placeholder -->
              <div id="basic-form" class="section">
                <div class="row">
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2" style="letter-spacing:1">New Tax Type </h4>
                      <div class="row">
                       <form role="form" name="frmproducttype" action="" method="post">
                          <div class="row">
                            <div class="input-field col s12">
                              <input autofocus="autofocus" name="pro_type_name" id="pro_type_name" type="text">
                              <label for="first_name" class="active">Tax Type Name</label>
                            </div>
                          </div>
                          <div class="row">
                            <div class="input-field col s12">
                              <input autofocus="autofocus" class="number-check" name="pro_type_per" id="pro_type_per" type="text">
                              <label for="first_name" class="active">Tax Type Percentage</label>
                            </div>
                          </div>
                          
                          <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right"  type="button" name="action" id="btnsubmit">Submit
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                <!--Basic Form-->  
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Tax Types</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:20px;text-align:center;">SN</th>
                          <th style="text-align:left;">Tax Types</th>
                              <th style="text-align:left;">Percentage</th>
                          <th style="width:75px"></th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php  if($producttype) { $i=1; foreach($producttype as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:20px;text-align:center;"><?php  echo $i ?></td>
								<td style="text-align:left;"><?php  echo $val->pro_type_name?> </td>
                                <td style="text-align:left;"><?php  echo $val->pro_type_percentage?> </td>
								<td style="width:75px"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan btnedit"  data-id="<?php  echo encode($val->pro_type_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php  echo $val->pro_type_id?>" href="#">
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php  $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

  
<script type="text/javascript">

$(document).ready(function(e) {
	
	 $(document).on('keypress','.number-check', function(e) {	
				if ( event.keyCode == 46 || event.keyCode == 8 ) {//|| event.keyCode == 37	event.keyCode==37 for Percentage
							
				}
				 else {
						if (event.keyCode < 48 || event.keyCode > 57) {
							event.preventDefault(); 
						}  
				 }
			});

	
	
   	//------insert -------------//
       	 $("#btnsubmit").click(function(ev) {
			//alert(1);
			var e=validation();
			if(e==0){
					$('.overlay').css({'display':'flex'});
  			var url="<?php  echo ADMIN_PATH?>productType/addproducttype";
  			var redirect = "<?php echo ADMIN_PATH?>productType";
  			var form = document.forms.namedItem("frmproducttype");                        
			var oData = new FormData(document.forms.namedItem("frmproducttype"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
						$('.overlay').css({'display':'none'});
				 if(oReq.responseText==1){
					// alert("Exist");
					swal("Already Exist!", "Exist!", "error")
					  //alert("Exist");
					 }
					 else
					 {
						 customSwalFunD("Success", "Sucessfully Added!", "success")
						 setTimeout(function(){
    document.location = redirect;
},600)
 					
					 }
					
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){
        error=0;
		$('label').removeClass('labelerror');
        $('input').removeClass('errors');
      //  $('input').removeClass('errorInput');
        $('select').removeClass('errors');
     //   $('select').removeClass('errorInput');
        var values = {'pro_type_per':$('#pro_type_per').val(),
							'pro_type_name':$('#pro_type_name').val()
							}
        if(values.pro_type_per == ''){
			$('#pro_type_per').parent().children('label').addClass('labelerror active');
            $('#pro_type_per').addClass('errors');
            $('#pro_type_per').attr("placeholder", "Please enter Tax type percentage")
			//$('#txttax').css({'border':'1px solid red'});
		  //  $('#txttax').addClass('errorInput');
            error=1;
        } 
		 if(values.pro_type_name == ''){
			$('#pro_type_name').parent().children('label').addClass('labelerror active');
            $('#pro_type_name').addClass('errors');
            $('#pro_type_name').attr("placeholder", "Please enter Tax type name")
			//$('#txttax').css({'border':'1px solid red'});
		  //  $('#txttax').addClass('errorInput');
            error=1;
        } 
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmncat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	

	
	
	// ---------- < Delete tax Name   > ---------- //
$(document).on('click', '.btndlt', function(){
	$btn=$(this);
	$tr=$btn.parent().parent();
	console.log($tr);
	var id=$(this).attr('rel');  
	swal({
  title: "Are you sure?",
  text: "Your will not be able to recover this Data!",
  type: "warning",
  showCancelButton: true,
  confirmButtonClass: "btn-danger",
  confirmButtonText: "Yes, delete it!",
  customClass: 'swal-delete',
  cancelButtonText: "No, cancel!",
  
}).then(function(){
		$('.overlay').css({'display':'flex'});
			 $.ajax({
                                            type:"post",
                       						url: "<?php echo ADMIN_PATH ?>productType/deleteproducttype",
                                            data:"id="+id,
                                            success:function(data){
													$('.overlay').css({'display':'none'});
												 //alert(data);
												/*swal({
												  title: '<div class="tst" >Deleted</div>',
												  html:'<div class="tst1" >Employee has been deleted</div>',
												  type: 'success',
												  customClass: 'swal-delete',
												})*/
												customSwalFunD(
														  'Success!',
														  'Data has been Deleted',
														  'success'
														)
												$tr.remove();
												location.reload() ;
											 }
								});
			});
			

});


		// ---------- < Delete Category ENDS > ----------
	$(document).on('click', '.btnedit', function(){	
	  var eid=$(this).attr('data-id');
	    var name='';
		 var pper='';
	getval();
	function getval(){
	
			 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>productType/getdetails",
														data:"eid="+eid,
														success:function(data){  
														
														data=JSON.parse(data);
														//alert(data.name);
															name=data.name;
															pper=data.per;
														updateform()
												}
			 		
										 })
		
		
		}
	
	
	function updateform(){
		  					//  var name=$("#ad").val();
							
				swal({
						  title: 'Edit Tax Type ',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input role="tax-name-content" autofocus="autofocus" placeholder="Enter Tax Type Name" name="txtpname" spellcheck="false" id="txtpname" type="text" value="'+name+'" ><label for="first_name" class="active">Tax Type Name</label></div></div><div class="row"><div class="input-field col s12"><input role="tax-name-content" autofocus="autofocus" placeholder="Enter Tax Type Percentage" name="txtpper" spellcheck="false" id="txtpper" class="number-check" type="text" value="'+pper+'" ><label for="first_name" class="active">Tax Type Percentage</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Update',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var txtpname=$("#txtpname").val();
									var txtpper=$("#txtpper").val();
									
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors');
									if(txtpname==''){
											$('#txtpname').parent().children('label').addClass('labelerror');
											$('#txtpname').addClass('errors');
											$('#txtpname').attr("placeholder", "Please enter Tax type name");
										err=1;
										}
										if(txtpper==''){
											$('#txtpper').parent().children('label').addClass('labelerror');
											$('#txtpper').addClass('errors');
											$('#txtpper').attr("placeholder", "Please enter tax type percentage");
										err=1;
										}
									return err;	
							}
								if(ev==0){
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>productType/updateproducttype",
														data:"txtpname="+txtpname+"&eid="+eid+"&txtpper="+txtpper,
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
																resolve();	  
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
									swal({
		  title: '<div class="tst" >Success</div>',
		  html:'<div class="tst1" >Data has been Updated</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
		setTimeout(function(){
			location.reload() ;
			},600)
		
			 
			  	});
	}
	});
	});
</script>


    
    
    
    
    
    
    
    
    

