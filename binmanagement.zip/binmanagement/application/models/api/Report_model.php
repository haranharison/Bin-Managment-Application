<?php
class Report_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
      
	 public function getreport(){
		 $today= date("y-m-d");
		 $sid=$this->input->post('salesmanid');
		 $array=array('tbl_salesproduct.status'=>0,'tbl_salesproduct.salesman_id'=>$sid,'tbl_salesproduct.create_date'=>$today);
		$this->db->where($array);
		
		$this->db->select('tbl_salesproduct.*,tbl_merchant.merchant_id,tbl_merchant.merchantname');/*,tbl_salesmanreg.salesmanid,tbl_salesmanreg.name,tbl_product.product_id,tbl_product.product_name*/
		$this->db->from('tbl_salesproduct');
		//$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesproduct.area' );
		/*$this->db->join ( 'tbl_salesmanreg as tbl_salesmanreg', 'tbl_salesmanreg.salesmanid = tbl_salesproduct.salesman_id' );*/
		$this->db->join ( 'tbl_merchant as tbl_merchant', 'tbl_merchant.merchant_id = tbl_salesproduct.merchant_id' );
		/*$this->db->join ( 'tbl_product as tbl_product', 'tbl_product.product_id = tbl_salesproduct.product_id' );*/
		$result=$this->db->get();
       		$rows=$result->result();
			$this->output->set_output(json_encode($rows));	
		}  
		
	  
	   public function collectionreport(){
		 $today= date("y-m-d");
		 $sid=$this->input->post('salesmanid');
		 $array=array('tbl_cashcollect.status'=>0,'tbl_cashcollect.salesman_id'=>$sid,'tbl_cashcollect.create_date'=>$today);
		$this->db->where($array);
		
		$this->db->select('tbl_cashcollect.*,tbl_merchant.merchant_id,tbl_merchant.merchantname');/*,tbl_salesmanreg.salesmanid,tbl_salesmanreg.name,tbl_product.product_id,tbl_product.product_name*/
		$this->db->from('tbl_cashcollect');
		//$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesproduct.area' );
		/*$this->db->join ( 'tbl_salesmanreg as tbl_salesmanreg', 'tbl_salesmanreg.salesmanid = tbl_salesproduct.salesman_id' );*/
		$this->db->join ( 'tbl_merchant as tbl_merchant', 'tbl_merchant.merchant_id = tbl_cashcollect.merchant_id' );
		/*$this->db->join ( 'tbl_product as tbl_product', 'tbl_product.product_id = tbl_salesproduct.product_id' );*/
		$result=$this->db->get();
       		$rows=$result->result();
			$this->output->set_output(json_encode($rows));	
		}  
		
	  
	    
}