<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Servicereturn extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
	$this->load->model('Servicereturn_model','model');
	 }	
	 public function index()
	{
		$data['menu']='service';
		$data['submenu']='servicereturn';
		$data['service']=$this->model->getservice();
		//$data['mainservice']=$this->model->getmainservice();
		$this->load->view('admin/header',$data);
		$this->load->view('admin/servicereturn/viewallservice',$data);
		$this->load->view('admin/footer');
	}

	

     public function addservicereturn($id=false){
		$mid=decode($id);
			$data['menu']='service';
		$data['submenu']='servicereturn';
		$data['allparts']=$this->model->allparts();
		$data['protypes']=$this->model->getprotypes();
		$data['edit']=$this->model->addservicereturn($mid);
	//	$data['service']=$this->model->getservice();
		$this->load->view('admin/header',$data);
		$this->load->view('admin/servicereturn/addservicereturn',$data);
		$this->load->view('admin/footer'); 
		}
	 public function addpart(){
		$this->model->addpart();	 
		 
	 }
	  public function getnewparts(){
		$this->model->getnewparts();	 
		 
	 }
	   public function getpartdetails(){
		$this->model->getpartdetails();	 
		 
	 }
	    public function addnewservicereturn(){
		$this->model->addnewservicereturn();	 
		 
	 }
	 
	 
}

