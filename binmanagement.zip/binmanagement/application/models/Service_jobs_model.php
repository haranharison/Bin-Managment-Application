<?php
class Service_jobs_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	
   /*function getitemstitle()
   {
	   
	   $this->db->where('org_id',$this->session->userdata('org_id'));
	   $this->db->select('*');
	  return $res= $this->db->get('tbl_s_items')->result();
	   
	}
	 function getamenitytitle()
   {
	   
	   $this->db->where('org_id',$this->session->userdata('org_id'));
	   $this->db->select('*');
	  return $res= $this->db->get('tbl_s_amenity')->result();
	   
	}*/
	 function getserjobs()
   {
	  if($this->session->userdata('org_id')=="")
		{
		   
		   $this->db->where('org_id','admin');
	   }
	   else
	   {
		   $this->db->where('org_id',$this->session->userdata('org_id'));
	   }
	   
	   $this->db->select('*');
	  return $res= $this->db->get('tbl_service_jobs')->result();
	   
	}	
	
	public function insert() // addproduct
	{
		if($this->session->userdata('org_id')=="")
		{
			
		 $this->db->where('org_id','admin');
		$this->db->delete('tbl_service_jobs');
		
				
				$today= date("y-m-d");
				$org=$this->session->userdata('org_id');
				
				
				$g_title=$this->input->post('general_title');
				$c=count($g_title);
				
				for($i=0;$i<$c;$i++){
				$max=maxplus('tbl_service_jobs','jobs_id');
				$data= array('jobs_id'=>$max,
				             'org_id'=>'admin',
				             'titles'=>$g_title[$i],
							 'create_date'=>$today,
							 'modify_date'=>$today
				);
				
			$this->db->insert('tbl_service_jobs',$data);
		
				}
			
		}
		else{
			$this->db->where('org_id',$this->session->userdata('org_id'));
		$this->db->delete('tbl_service_jobs');
		
				
				$today= date("y-m-d");
				$org=$this->session->userdata('org_id');
				
				
				
				$g_title=$this->input->post('general_title');
				$c=count($g_title);
				
				for($i=0;$i<$c;$i++){
				$max=maxplus('tbl_service_jobs','jobs_id');
				$data= array('jobs_id'=>$max,
				             'org_id'=>$org,
				             'titles'=>$g_title[$i],
							 'create_date'=>$today,
							 'modify_date'=>$today
				);
				
			$this->db->insert('tbl_service_jobs',$data);
		
				}
			
		}
				
}

}