<?php
class Menu_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        
		public function getmenu()
		{
		$array=array('status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->group_by('menu_id');
		return $rows=$this->db->get('tbl_menu')->result();
		}
		public function getmainmenu()
		{
		$array=array('status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->group_by('menu_id');
		return $rows=$this->db->get('tbl_menu')->result();
		}
		
		public function addmenu()
		{
			$selmenutype=$this->input->post('selmenutype');
			if($selmenutype==1){
						$exist=fieldexist('tbl_menu','menu_name',$this->input->post('menuname'));
	if($exist==1){
		echo 1;
	}else{
	
		$today= date("y-m-d");
		
		$menu=$this->input->post('menuname');
		$icon=$this->input->post('menuicon');
		$path=$this->input->post('menupath');
		$data= array(
		
		       'menu_name'=>$menu,
			   'menu_icon'=>$icon,
			   'menu_path'=>$path,
			   'created_date'=>$today,
			   'modified_date'=>$today
		);
		$this->db->insert('tbl_menu',$data);
		}
	}
			else{
				
						$exist=fieldexist('tbl_submenu','submenu_name',$this->input->post('menuname'));
	if($exist==1){
		echo 2;
	}else{
	
		$today= date("y-m-d");
		$selmenu=$this->input->post('selmenu');
		
		$menu=$this->input->post('menuname');
		$icon=$this->input->post('menuicon');
		$path=$this->input->post('menupath');
		$data= array(
		 		'mainmenu_id'=>$selmenu,
		       'submenu_name'=>$menu,
			   'submenu_icon'=>$icon,
			   'submenu_path'=>$path,
			   'created_date'=>$today,
			   'modified_date'=>$today
		);
	
		$this->db->insert('tbl_submenu',$data);
		}
	
				
				
				}
		}	
		public function editcategory($id){
			$cid=$id;
				$array=array('category_id'=>$cid,'status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_menu')->row();
			}
			
			public function updatemenu()
			{
				$cid=$this->input->post('txthiden');
				$today= date("y-m-d");
		$category=$this->input->post('txtcategory');
				   $data=array(
				    'cat_name'=>$category,
			   'create_date'=>$today,
			   'modify_date'=>$today
				   
				   
				   );
		   $array= array('category_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_category',$data);
			}
			
			  public function deleteMenu(){
				  
		 	$mid=decode($this->input->post('id'));
		   $array= array('menu_id'=>$mid);
		   $this->db->where($array);  
		    $data=array('status'=>1);
		   $this->db->update('tbl_menu',$data);
		   }
	/*		
	   public function deleteCategories($id){
		   $cid=$id;
		   $data=array('status'=>1);
		   $array= array('cat_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_category',$data);
		   }
		*/
}