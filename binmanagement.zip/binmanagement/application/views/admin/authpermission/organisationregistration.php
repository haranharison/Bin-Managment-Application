
          <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/jquery-ui.js" type="text/javascript"></script>
    <link href="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/themes/blitzer/jquery-ui.css" rel="stylesheet" type="text/css" />  
<style>
.file-field .btn {
        float: right;
    position: relative;
}
.tdiv{
display:none;	
	}
	.file_wrap {
    border: 1px solid #CCC  ;
    border-radius: 4px;
    height: 37px;
    position: relative;
}
.file_wrap .write_textbox {
    bottom: 0;
    left: 0;
    position: absolute;
    right: 102px;
    top: 0;
}
.file_wrap input[type="text"] {
    background: none repeat scroll 0 0 transparent;
    border: medium none;
    color: #333333;
    font-size: 16px;
    height: 29px;
    line-height: 28px;
    outline: medium none;
    padding: 4px;
    width: 98%;
}
.file_wrap .iconw {
    border-radius: 0 5px 5px 0;
    border-right: 1px solid #01bdd6;
    bottom: -1px;
    right: -1px;
    position: absolute;
    top: -1px;
    width: 100px;
    padding: 10px 0 10px 0;
    background: #01bdd6;
    text-align: center;
    cursor: pointer;
    color: #fff;
}
.file_input_hidden {
    font-size: 20px;
    position: absolute;
    /*right: 0px;*/
	width:100%;
    top: 0px;
    bottom: 0;
    cursor: pointer;
    opacity: 0;
    filter: alpha(opacity=0);
    -ms-filter: "alpha(opacity=0)";
    -khtml-opacity: 0;
    -moz-opacity: 0;
}
.imageup
{
	text-align:center;
}
</style>


<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m6 l6">
                <div class="card-panel">
                 <h4 class="header2">Department Registration</h4>
                  <div class="row">
                   <form role="form" name="frmorganisation" id="frmorganisation">
                      <div class="row">
                        <div class="input-field col s12 m6">
                           <select class="form-control selsubcats" id="seldept" name="seldept">
                                   <option value="0">Select Department</option>
                                   <option value="cafe">Cafe</option>
                                   <option value="bakers">Bakers</option>
                                   <option value="meetandfish">Meet & Fish</option>
                                   <option value="hotfoodtakeaway">Hotfood Takeaway</option>
						   </select>
                          <label for="first_name">Department Name</label>
                        </div>
                         
                        <div class="input-field col s12 m6">
                          	<input  type="number"   name="orgphone" id="orgphone" rows="3" placeholder="Land Phone">
                          <label for="first_name">Land Phone</label>
                        </div>
                        <div class="input-field col s12 m6">
                          	<input  type="number" placeholder="Floor No." name="orgmobile" id="orgmobile"  >
                          <label for="first_name">Floor No</label>
                        </div>
                        <div class="input-field col s12 m6">
                          	<input  type="text" placeholder="Fax No." name="orgfax" id="orgfax" >
                          <label for="first_name">Fax No</label>
                        </div>
                        <div class="input-field col s12 m6">
                          	<input  type="email" placeholder="Email address." id="orgmail" name="orgmail" >
                          <label for="first_name">Email address</label>
                        </div>
                        
                           <div class="input-field col s12 m6">
                          	<input  type="password" placeholder="Password." name="orgpass" id="orgpass" >
                          <label for="first_name">Password</label>
                        </div>
                        <div class="input-field col s12 m6">
                          	<input  type="password" placeholder="Confirm Password." id="orgcpass" name="orgcpass" >
                          <label for="first_name">Confirm Password</label>
                        </div>
                        
                         
                        <!--<div class="input-field col m6 s12">
                          	<select  name="area" id="area">
                                    	<option value="0">Select Area</option>
										<?php foreach($area as $key){?>
											
											<option value="<?php echo $key->area_id;?>"><?php echo $key->area_name;?></option>
											
									<?php		}?>
									</select>
                                      <label for="first_name">Location</label>
                        </div>-->
                      
                          
                      <!--<div class="input-field col m6 s12">
                          	<select  name="orgusergrp" id="orgusergrp">
                                    	<option value="">Select Usergroup</option>
										<?php foreach($usegrp as $key){?>
											
											<option value="<?php echo $key->usergroup_id;?>"><?php echo $key->usergroup_name;?></option>
											
									<?php		}?>
									</select>
                                      <label for="first_name">Usergroup</label>
                        </div>-->
                        <div class="input-field col m6 s12">
                          <select id="selAuth" name="selAuth">
                            <option>Select Authorised person</option>
                            <?php if($auth){ foreach($auth as $val){ ?>
                            <option value="<?php echo $val->authid ?>"><?php echo $val->name; ?></option>
                            <?php }} ?>
                          </select>
                          <label for="first_name">Authorised Person</label>
                        </div>
               <div class="input-field col m6 s12 ">
                          	<input  type="text" class="number-check" placeholder="Enter User Limit" name="userlimit" id="userlimit" >
                          <label for="first_name">User Limit</label>
                        </div>
              
                     
              
                          
                        <div class="row">
                            <div class="col s6">
                            <label for="first_name" id="labelimg">Images</label>
                            
                                     <div class="fluid left_c_input file_wrap">
                                 <div class="write_textbox"> 
                                      <input type="text" readonly placeholder="No file selected" class="txtFilepath" style="border:none !important;">                                       
                                  </div>
                                 <div class="iconw"><i class="fa fa-download"></i>Icon</div>
                                 <input type="file" id="icon"  name="icon"  class="file_input_hidden" />                        
                                     </div>       
                            </div>
                            <div class="col s3">
                            <div class="imageup">
                            <img src="<?php echo SITE_PATH; ?>dummy.png" id="imgfiles" class="imgup"  style="width:70%;margin-bottom:10px;"/>
                            
                            </div>
                            </div>
                            
                            
                          </div>  
                          
                      <div class="row">
                       
                        <div class="row">
                          <div class="input-field col s12">
                            <button class="btn cyan waves-effect waves-light right"  id="btnnsubmit" type="button"  name="btnsubmit">Submit
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
                </div>
                <div class="col s12 m6 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Departments</h4>
                      <div class="row">
						
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
						  <thead>
							  <tr class="text-center">
								  <th style="width:50px;">Sl.no</th>
								 <!-- <th>Shop name</th>-->
                                   <th style="text-align:left;">Department name</th>
                                    <th style="text-align:left;">Action</th>
								  <!--<th>Edit</th>
                                  
                                  <th>Delete</th>-->
							  </tr>
						  </thead>   
						  <tbody>
                          
                          
                           <?php  if($allorg) { $i=1; foreach($allorg as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:50px;text-align:center;"><?php echo $i ?></td>
                                    	<td style="text-align:left;"><?php echo $val->org_name?> </td>
								      <td  style="width:100px;text-align:right;">
								
									<a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH?>Department/orgedit/<?php echo encode($val->org_maxid);?>">
										<i class="material-icons">mode_edit</i>
									</a>
                               
									<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange btndlt"  id="btndelt"rel="<?php echo encode($val->org_maxid);?>">
										<i class="material-icons">delete</i>
									</a>
								</td>
							</tr>
					<?php $i=$i+1;}}?>
							
						
							
							
						  </tbody>
					  </table>   
						
								
								
							
						
				</div>
                    </div>
                  </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

<script type="text/javascript">




$(document).ready(function(e) {
			
			function readURL(input) {
	
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
			
            $('#icon').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}
$("#icon").change(function(){

    readURL(this);
	$('.file_wrap').removeClass('errors');
	$('#labelimg').removeClass('labelerror');
	$('.txtFilepath').attr("placeholder", "File selected");
});
	
	
	
	
		 $('#orgmail').blur(function(){
		
	
	 var pattern =/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
	// console.log(pattern.test($('#txtemail').val()))
					//	 console.log( pattern.test( $scope.chkemail));
						 if(pattern.test($('#orgmail').val())==false){
							 $('#orgmail').addClass('errors');
			 				 $('#orgmail').parent().children('label').addClass('labelerror');
							 
						
						  }
						  else{
							  $('#orgmail').removeClass('errors');
			 				 $('#orgmail').parent().children('label').removeClass('labelerror');
							  }
	
	  });
	
	
	 $(document).on('keypress','.number-check', function(e) {	
				if ( event.keyCode == 46 || event.keyCode == 8 ) {
							
				}
				 else {
						if (event.keyCode < 48 || event.keyCode > 57) {
							event.preventDefault(); 
						}  
				 }
			});
	//GET Sub Categorie
//------insert -------------//
       	 $("#btnnsubmit").click(function(e) {
			//alert(1);
		/*	alert($('#orgpass').val());
			alert($('#orgcpass').val());*/
			var e=validation();
			if(e==0){
			$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>Department/addorg";
  			var form = document.forms.namedItem("frmorganisation");                        
			var oData = new FormData(document.forms.namedItem("frmorganisation"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { alert(oReq.responseText);
					$('.overlay').css({'display':'none'});
	
				 if(oReq.responseText==1){
					customSwalFunD( "Exist","Mobile Number Already Exist!", "error");
					 }
					 else if(oReq.responseText==2){
					customSwalFunD( "Exist!","Email Already Exist!", "error");
					 }
					 else
					 {
						 customSwalFunD("Sucess!", "Sucessfully Added!", "success")
 						document.location = "<?php echo ADMIN_PATH?>department/permission";
					 }
					 }
                oReq.send(oData);
                ev.preventDefault();   
			}
   			});
				function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#imgfiles').attr('src', e.target.result);
			Materialize.fadeInImage('#imgfiles');
        }
        reader.readAsDataURL(input.files[0]);
    }
}
$("#logofile").change(function(){
    readURL(this);
});	
function readUR(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#imagefile').attr('src', e.target.result);
			Materialize.fadeInImage('#imagefile');
        }
        reader.readAsDataURL(input.files[0]);
    }
}
$("#imgfile").change(function(){
    readUR(this);
});	
	//----end insert--------------------//	
function validation(){
//alert($('#area').val());
        error=0;
        $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');
            var values = {
									  'org_name':$('#orgname').val(),
									  'org_address':$('#orgaddress').val(),
  								      'org_phone':$('#orgphone').val(),
									  'orgmobile':$('#orgmobile').val(),
									  'org_mail':$('#orgmail').val(),
									  'orgfax':$('#orgfax').val(),
									  'org_pass':$('#orgpass').val(),
									  'orgcpass':$('#orgcpass').val(),
									  'org_gstno':$('#orggst').val(),
									  'orgweb':$('#orgweb').val(),
									  'org_pin':$('#orgpin').val(),
									  'org_state':$('#orgstate').val(),
									  'org_district':$('#orgdistrict').val(),
									  'org_nationality':$('#orgnat').val(),
									  'org_year':$('#orgyear').val(),
									  'org_usrgrp':$('#orgusergrp').val(),
									  'org_authperson':$('#orgperson').val(),
									  'appstatus':$('#appstatus').val(),
									   'trialdays':$('#trialdays').val(),
                                 }
							 
			 if(values.appstatus == 0){
         	   $('#appstatus').parent().children('.select-dropdown').addClass('errors');
			   $('#appstatus').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		if(values.appstatus==1){
			  if(values.trialdays == ''){
				$('#trialdays').addClass('errors');
				$('#trialdays').attr("placeholder", "Please enter Trial Days")
				$('#trialdays').parent().children('label').addClass('labelerror');
				error=1;
        } 
	}
	
      if(values.org_name == ''){
            $('#orgname').addClass('errors');
            $('#orgname').attr("placeholder", "Please enter Oraganisation Name.")
		  $('#orgname').parent().children('label').addClass('labelerror');
            error=1;
        } 
		   if(values.org_address == ''){
            $('#orgaddress').addClass('errors');
            $('#orgaddress').attr("placeholder", "Please enter Address.")
		  $('#orgaddress').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.orgmobile == ''){
            $('#orgmobile').addClass('errors');
            $('#orgmobile').attr("placeholder", "PleaseEnter Mobile number.")
		    $('#orgmobile').parent().children('label').addClass('labelerror');
            error=1;
        } 
		 if(values.org_phone == ''){
            $('#orgphone').addClass('errors');
            $('#orgphone').attr("placeholder", "PleaseEnter Land Line number.")
		    $('#orgphone').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		  if(values.orgfax == ''){
            $('#orgfax').addClass('errors');
            $('#orgfax').attr("placeholder", "Please Enter Fax number.")
		    $('#orgfax').parent().children('label').addClass('labelerror');
            error=1;
        } 
				  if(values.orgpass == ''){
            $('#orgpass').addClass('errors');
            $('#orgpass').attr("placeholder", "Please Enter Password.")
		    $('#orgpass').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
				  if(values.orgcpass == ''){
            $('#orgcpass').addClass('errors');
            $('#orgcpass').attr("placeholder", "Please ReEnter Password.")
		    $('#orgcpass').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
				  if($('#orgpass').val() != $('#orgcpass').val() ){
            $('#orgcpass').addClass('errors');
            $('#orgcpass').attr("placeholder", "Please ReEnter Password.")
		    $('#orgcpass').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		if(values.orgweb == ''){
            $('#orgweb').addClass('errors');
            $('#orgweb').attr("placeholder", "Please Enter Website.")
		    $('#orgweb').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		if(values.org_mail == ''){
            $('#orgmail').addClass('errors');
            $('#orgmail').attr("placeholder", "Please enter  mail.");
		   $('#orgmail').parent().children('label').addClass('labelerror');
            error=1;
        }
		
		 var pattern =/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
		 if(pattern.test($('#orgmail').val())==false){
							 $('#orgmail').addClass('errors');
			 				 $('#txteorgmailmail').parent().children('label').addClass('labelerror');
							 
						 error=1;
						  }		
		
		 if(values.org_gstno == ''){
			 $('#orggst').addClass('errors');
            $('#orggst').attr("placeholder", "Please enter GST No.");
		   $('#orggst').parent().children('label').addClass('labelerror');
            error=1;
        } 
        if(values.org_pin == ''){
            $('#orgpin').addClass('errors');
            $('#orgpin').attr("placeholder", "Please enter  Pincode.")
			$('#orgpin').parent().children('label').addClass('labelerror');
            error=1;
        } 
        if(values.org_state == ''){
            $('#orgstate').addClass('errors');
            $('#orgstate').attr("placeholder", "Please enter state.");
			$('#orgstate').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
        if(values.org_district == ''){
            $('#orgdistrict').addClass('errors');
            $('#orgdistrict').attr("placeholder", "Please enter District.");
		   $('#orgdistrict').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
        if(values.org_authperson == ''){
            $('#orgperson').addClass('errors');
            $('#orgperson').attr("placeholder", "Please enter Authorised Person.");
				 $('#orgperson').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
        if(values.org_nationality == ''){
            $('#orgnat').addClass('errors');
            $('#orgnat').attr("placeholder", "Please enter Nationality.");
			  $('#orgnat').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
      if(values.org_usrgrp ==''){
			$('#orgusergrp').parent().children('.select-dropdown').addClass('errors');
			$('#orgusergrp').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.org_year == ''){
            $('#orgyear').addClass('errors');
            $('#orgyear').attr("placeholder", "Please select Latitude.")
			 $('#orgyear').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
        return error;
    }

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmncat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
	
	   $(document).on('change', '#appstatus', function(){
		   
		   if( $('#appstatus').val()==1){
			   $('.tdiv').show();
			   }
			   else{
				     $('.tdiv').hide(); 
				   }
		   
		   })
	
	// ---------- < Delete Category   > ---------- //
		    $(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
 swal({
                             title: "Are you sure?",
							   text: "Delete this organisation",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:"swal-delete",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          }).then(function(){
						  
			$('.overlay').css({'display':'flex'});
			//alert(id);
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>Department/deleteorganisation",
					//redirect : "<?php echo ADMIN_PATH?>Department",

                                            data:"id="+id,

                                            success:function(data){//alert(data);
											$('.overlay').css({'display':'none'});	
											
                                               // $(".loader").remove();
                                 location.reload();
                                 // 	document.location = redirect;
	customSwalFunD("Sucessfully!", "Sucessfully deleted!", "success")
                                            }
           
     

                                        });
					

				          });

		
			  
        });
		// ---------- < Delete  ENDS > ----------
	
});
</script>
  
    
    




    
    
    
    
    
    
    
    
    

