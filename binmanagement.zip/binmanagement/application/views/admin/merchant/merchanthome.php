
<!--start container-->
     <!--    <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			

		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading1">Merchant</div>
                    <div class="box-icon">
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
						</div>
					<div class="panel-body">
						<div class="col-md-12">-->
						 <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  <div class="col s12 m12 l12">
                    <div class="card-panel">
                      <h4 class="header2">All Merchant</h4>
                      <div class="row">
						
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
						  <thead>
							  <tr class="text-center">
								  <th style="width:50px;">Sl.no</th>
								 <!-- <th>Shop name</th>-->
                                   <th>Merchant name</th>
								   <th>Merchant code</th>
                                   <th>Location</th>
                                    <th>Create date</th>
                                    <th></th>
								  <!--<th>Edit</th>
                                  
                                  <th>Delete</th>-->
							  </tr>
						  </thead>   
						  <tbody>
                          
                          
                           <?php  if($merchant) { $i=1; foreach($merchant as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:50px;text-align:center;"><?php echo $i ?></td>
								<!--<td class="center"><?php echo $val->shponame?> </td>-->
                                    	<td><?php echo $val->merchantname?> </td>
										<td><?php echo $val->merchantid_num?> </td>
                                        <td ><?php echo $val->area_name?> </td>
                                        <td ><?php echo $val->create_date?> </td>
								      <td  style="width:100px;text-align:right;">
								
									<a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH?>merchant/merchantedit/<?php echo encode($val->merchant_id);?>">
										<i class="material-icons">mode_edit</i>
									</a>
                               
									<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange btndlt"  id="btndelt"rel="<?php echo encode($val->merchant_id);?>">
										<i class="material-icons">delete</i>
									</a>
								</td>
							</tr>
					<?php $i=$i+1;}}?>
							
						
							
							
						  </tbody>
					  </table>   
						
								
								
							
						
				</div>
                    </div>
                  </div>
                  <!-- Form with placeholder -->
                  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

  
<script type="text/javascript">

$(document).ready(function(e) {
   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			//alert(1);
			var e=validation();
			if(e==0){
  			var url="<?php echo ADMIN_PATH?>category/addcategory";
  			var redirect = "<?php echo ADMIN_PATH?>category";
  			var form = document.forms.namedItem("frmncat");                        
			var oData = new FormData(document.forms.namedItem("frmncat"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
					
				 if(oReq.responseText==1){
					// alert("Exist");
					swal("Alreadt Exist!", "Exist!", "error")
					  //alert("Exist");
					 }
					 else
					 {
						 swal("Sucessfully!", "Sucessfully Added!", "success")
 					 document.location = redirect;
					 }
					
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');

        $('input').removeClass('errorInput');

        $('select').removeClass('errors');

        $('select').removeClass('errorInput');
        

            var values = {
                                    'category':$('#txtcategory').val(),

                                 }

        if(values.category == ''){
            $('#txtcategory').addClass('errors');
            $('#txtcategory').attr("placeholder", "Please enter category.")
			$('#txtcategory').css({'border':'1px solid red'});
		    $('#txtcategory').addClass('errorInput');
            error=1;
        } 
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmncat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
	
	
	
	// ---------- < Delete Merchant   > ---------- //
	
	
	   $(document).on('click', '#btndelt', function(){
                var id=$(this).attr('rel');  
 swal({
                            title: "Are you sure?",
							   text: "Delete this service",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:"swal-delete",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          }).then(function(){
						  
			
			//alert(id);
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>Merchant/deletemerchant",
					//redirect : "<?php echo ADMIN_PATH?>Merchant",

                                            data:"id="+id,

                                            success:function(data){// alert(data);
												
											
                                               // $(".loader").remove();
                                 location.reload() ;
                                 // 	document.location = redirect;
	swal("Sucessfully!", "Sucessfully deleted!", "success")
                                            }
           
     

                                        });
					

				          });

		
			  
        });
		// ---------- < Delete Category ENDS > ----------
	
	
	
	
	
	
});
</script>


    
    
    
    
    
    
    
    
    

