<?php
class Changepwd_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        
	
	public function changepwd()
	{		
		$txtopwd=$this->input->post('txtopwd');
		$txtnpwd=$this->input->post('txtnpwd');
		$txtcpwd=$this->input->post('txtcpwd');
		$uid=$this->session->userdata('emp_id');
		$array=array('status'=>0,'emp_id'=>$uid);
		$this->db->where($array);
		$this->db->select('password');
		$res=$this->db->get('tbl_login');
		$result=$res->row();
		
		if($res->num_rows()>0)
		{
				$txtoldpwd=$result->password;
				if($txtoldpwd!=$txtopwd)
				{
				echo 1;	
				} 
				else{
						if($this->input->post('txtnpwd')==$this->input->post('txtcpwd'))
						{
							$newpwd=$this->input->post('txtnpwd');
							$arr=array('password'=>$newpwd);
							$arrc=array('status'=>0,'emp_id'=>$uid);
							$this->db->where($arrc);
							$this->db->update('tbl_login',$arr);
							echo 3;
						}
						else{
							
						echo 2;	
						}
						
				} 
				
		}
		else{
			echo 0;
			
			}
		

		 
	}}