<?php
class Index_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
      
	 public function login(){
		
		$user= $this->input->post('email');
		$password  =  $this->input->post('password');
		$array=array('username'=>$user,'password'=>$password,'status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		$query = $this->db->get('tbl_login');
		$result=$query->row();
		$today=date('Y-m-d');
		$ex=0;
				if($query->num_rows() >0){
					
					
					$ugroup=$result->usergroup;
						$appstatus=$result->app_status;
						if($appstatus==1 && $ugroup=='org'){
							$trialdays=$result->trial_days;
								
							$d='+'.$trialdays.' days';
							$from=$result->created_date;
						//	$nfrm=date('Y-m-d',$from)	;
							$fr = new DateTime($from);
							$frm = $fr->format('Y-m-d');
							
							$to = date('Y-m-d',strtotime($d,strtotime($from)));
							
								if($today>=$frm && $today<=$to)
								{
									$ex=0;
								}
								else{
									$ex=1;
								}
							}
							
							//////////////////////////////////////////////////
							
							
							else if($appstatus==1 && $ugroup=='own'){
							$trialdays=$result->trial_days;
								
							$d='+'.$trialdays.' days';
							$from=$result->created_date;
						//	$nfrm=date('Y-m-d',$from)	;
							$fr = new DateTime($from);
							$frm = $fr->format('Y-m-d');
							
							$to = date('Y-m-d',strtotime($d,strtotime($from)));
							
								if($today>=$frm && $today<=$to)
								{
									$ex=0;
								}
								else{
									$ex=1;
								}
							}
							
							
							else if($appstatus==1 && $ugroup=='dri'){
							$trialdays=$result->trial_days;
								
							$d='+'.$trialdays.' days';
							$from=$result->created_date;
						//	$nfrm=date('Y-m-d',$from)	;
							$fr = new DateTime($from);
							$frm = $fr->format('Y-m-d');
							
							$to = date('Y-m-d',strtotime($d,strtotime($from)));
							
								if($today>=$frm && $today<=$to)
								{
									/////////////chech vechicle due dates////////
									
									$ex=0;
									
								}
								else{
									$ex=1;
								}
							}
							
							//////////////////////////////////////////////////////
							else if($ugroup!='org' && $ugroup!='0' ){
								
								$oid=$result->org_id;
								
									$arr=array('emp_id'=>$oid,'status'=>0);
									$this->db->where($arr);
									$this->db->select('*');
									$qu = $this->db->get('tbl_login');
									$res=$qu->row();
									
										if($qu->num_rows()>0){
										
												$ugroup=$res->usergroup;
												$appstatus=$res->app_status;
										
											if($appstatus==1 ){	
											$trialdays=$res->trial_days;
										
											$d='+'.$trialdays.' days';
											$from=$res->created_date;
										//	$nfrm=date('Y-m-d',$from)	;
											$fr = new DateTime($from);
											$frm = $fr->format('Y-m-d');
											
											$to = date('Y-m-d',strtotime($d,strtotime($from)));
												
												if($today>=$frm && $today<=$to)
												{
													$ex=0;
												
												}
												else{
													$ex=1;
												}
													
										}
										}
								
								}
								
							
						if($ex==0){
								$emp_id=$result->emp_id;
								$org_id=$result->org_id;
								$usergroup=$result->usergroup;
								$this->session->set_userdata(array('loggedIn'=> true,
																	'username' =>$user,
																	'emp_id' =>$emp_id,
																	'org_id' =>$org_id,
																	'usergroup'=>$usergroup));
																	
									if($usergroup=='dri')
									{
									$zid=$result->emp_id;
									checkduedate($zid,$org_id);	
									}								
								echo 1;
						
						}
						else{
							echo 3;	
							}
					
					
				}
				else{
					echo 2;
				}
		}  
	  
	  
	  
	public function counts() //counts
	{
		$merchant=$this->db->get('tbl_merchant')->num_rows();
		$salesman=$this->db->get('tbl_salesmanreg')->num_rows();
		$array=array(
		'merchant' => $merchant,
		'salesman' => $salesman,
		);
			return $array;
	}  
	 public function getmerchant(){
		 if($this->session->userdata('org_id')=='0'){
			$arr=array('status'=>0); 
			 }
			 else{
	$arr=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			 }
	$this->db->where($arr);
	$this->db->select('count(merchant_id) as mercount');
	$this->db->from('tbl_merchant');
	$res=$this->db->get()->row();
	return $res->mercount;
		 
	 } 
	public function getsalesman(){
		 if($this->session->userdata('org_id')=='0'){
		$arr=array('status'=>0); 	 
		 }
		 else{
	$arr=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		 }
	$this->db->where($arr);
	$this->db->select('count(salesmanid) as salecount');
	$this->db->from('tbl_salesmanreg');
	$res=$this->db->get()->row();
	return $res->salecount;
		
	}  
	public function getcategories(){
		 if($this->session->userdata('org_id')=='0'){
		$arr=array('status'=>0); 	 
		 }
		 else{
	$arr=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		 }
	$this->db->where($arr);
	$this->db->select('count(category_id) as catcount');
	$this->db->from('tbl_category');
	$res=$this->db->get()->row();
	return $res->catcount;
	}
	public function getsubcategories(){
		 if($this->session->userdata('org_id')=='0'){
		$arr=array('status'=>0); 	 
		 }
		 else{
	$arr=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		 }
	$this->db->where($arr);
	$this->db->select('count(subcategory_id) as subcount');
	$this->db->from('tbl_subcategory');
	$res=$this->db->get()->row();
	return $res->subcount;
	}
	public function gettotalbin(){
		 if($this->session->userdata('org_id')=='0'){
		$arr=array('status'=>0); 	 
		 }
		 else{
	$arr=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		 }
	$this->db->where($arr);
	$this->db->select('count(bin_id) as bincount');
	$this->db->from('tbl_bin');
	$res=$this->db->get()->row();
	return $res->bincount;
	}
	public function getcatbin(){
		 if($this->session->userdata('org_id')=='0'){
		$arr=array('tbl_bin.status'=>0); 	 
		 }
		 else{
	$arr=array('tbl_bin.status'=>0,'tbl_bin.org_id'=>$this->session->userdata('org_id'));
		 }
	$this->db->where($arr);
	$this->db->select('tbl_bin.pro_id,tbl_product.product_name, COUNT(pro_id) as total');
 	$this->db->group_by('pro_id'); 
	$this->db->from('tbl_bin');
	$this->db->join('tbl_product','tbl_bin.pro_id=tbl_product.product_id'); 
 	$this->db->order_by('total', 'desc'); 
 	$res=$this->db->get()->result();
	return $res;
	}
public function forpasssend(){
		$u_name = $this->input->post('i-n-p-f-p-u-t');
		$u_mail = $this->input->post('i-n-p-f-p-e-t'); 
     
			$chkresult=checkusermail('tbl_login','username',$u_name,'email',$u_mail);
			if($chkresult==0){//not found
				//echo 0;
				$arr=array('res'=>0,'errormsg'=>'The Username and Email you entered does not belong to your account');
				echo json_encode($arr);
			}
			else//success
			{
				
				/*$arr=array('username'=>$u_name,'email'=>$u_mail,'status'=>0);
				$this->db->where($arr);
				$this->db->select('password');
				$this->db->from('tbl_login');
				$res=$this->db->get()->row();
				//PASSEWORD SENT TO GMAIL 
				$pass=$res->password;
				$sub='Request to View Password';
				$msg= 'You told as you forgot your password. and request to view the password, Password is '.$pass; 
				send_passto_mail($u_name,$msg, $sub, $u_mail);*/
				$hided_mail=hide_email($u_mail);
				$arr=array('res'=>1,'successmsg'=>'Check Your email - we will send you an email to '.$hided_mail.' with your password');
				echo json_encode($arr);
			}

	//	echo 'v' ;
        /*
		$findemail = $this->usermodel->ForgotPassword($email);  
         if($findemail){
          $this->usermodel->sendpassword($findemail);        
           }
		   else{
          $this->session->set_flashdata('msg',' Email not found!');
          redirect(base_url().'user/Login','refresh');
		   }*/
		   //echo 1;
}
	 
	  
	  public function getadvtop()
		{
		
		$array=array('status'=>0,'publish_status'=>1,'adv_position'=>1);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_advertisement')->result();
		}
		  public function getadvbtm()
		{
		
		$array=array('status'=>0,'publish_status'=>1,'adv_position'=>2);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_advertisement')->result();
		}
		
	  
	public function getbarchart()
	{
	$oid=$this->session->userdata('org_id');
	
		$qu=$this->db->query("SELECT SUM( total_amount ) AS tamt , week(created_date) as sweek, month(created_date)  as smonth , year(created_date) as syear FROM tbl_sales WHERE org_id='".$oid."' AND STATUS =0 AND month(created_date)= month(now())  GROUP BY WEEK( created_date ) ORDER BY WEEK( created_date ),year(created_date)");
		
		return $qu->result();
		
	}
	 public function getradarchart()
	{
		$oid=$this->session->userdata('org_id');
		$qu=$this->db->query("SELECT tbl_category.cat_name,count(tbl_product.product_id) as pcount FROM tbl_product JOIN tbl_category ON tbl_category.category_id=tbl_product.cat_id WHERE  tbl_category.org_id='".$oid."' AND tbl_product.status=0 group by tbl_product.cat_id");
		return $qu->result();
		
		
	} 
	    
}