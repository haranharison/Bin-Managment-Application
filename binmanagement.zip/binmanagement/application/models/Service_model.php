<?php
class Service_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        
		public function getbin()
		{
		$array=array('tbl_bin.status'=>0,'tbl_bin.org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('tbl_bin.*,tbl_category.cat_name,tbl_subcategory.subcat_name,tbl_product.product_name');
		$this->db->from('tbl_bin');
		$this->db->join('tbl_category','tbl_bin.cat_id=tbl_category.category_id');
		$this->db->join('tbl_subcategory','tbl_bin.sub_id=tbl_subcategory.subcategory_id');
		$this->db->join('tbl_product','tbl_bin.pro_id=tbl_product.product_id');
		return $rows=$this->db->get()->result();
		}
		public function getsubcategory()
		{
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_subcategory')->result();
		}
		public function getproduct()
	{
		$array=array('tbl_product.status' =>0,'tbl_product.org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->group_by('product_id');
		$this->db->select('tbl_product.*');
		return $rows=$this->db->get('tbl_product')->result();
	}
	public function getmeasurement(){
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_measurement')->result();
		}
		public function getcategory()
		{
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_category')->result();
		}
		
		public function getmainservice()
		{
		$array=array('status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->group_by('ser_id');
		return $rows=$this->db->get('tbl_service')->result();
		}

		
		public function addservice()
		{
		    $max=maxplus('tbl_service','ser_id');	
		    $today=date('Y-m-d');
			$complaintno='SRN#'.$this->session->userdata('org_id').$this->session->userdata('emp_id').date('ymdHis').$max;
			$data= array(
			   'ser_id' =>$max,
			   'org_id'=>$this->session->userdata('org_id'),
			   'emp_id'=>$this->session->userdata('emp_id'),
			   'complaint_no'=>$complaintno,
		       'ser_name'=>$this->input->post('sname'),
			   'ser_address'=>$this->input->post('address'),
			   'ser_product'=>$this->input->post('product'),
			   'yr_of_manu'=>$this->input->post('yrofmanu'),
			   'ser_warranty'=>$this->input->post('warranty'),
			   'ser_delivery_date'=>$this->input->post('exdeldate'),
			   'ser_complaints'=>$this->input->post('cmplnts'),
			   'ser_mobile'=>$this->input->post('mobile'),
			   'ser_alternative'=>$this->input->post('altnumber'),
			   'ser_email'=>$this->input->post('semail'),
			   'status'=>0,
			   'created_date'=>$today,
			   'modified_date'=>$today,
			);
			$this->db->insert('tbl_service',$data);	
			$to=$this->input->post('sname');
			$msg='Complaint ID : ' .$complaintno;
			$sub='Complaint ID';
			$email=$this->input->post('semail');
			
			send_mail($to,$msg,$sub,$email);
			
			$mmsg="Your Complaint ID is : ".$complaintno;
			$mmob=$this->input->post('mobile');
			sentsms($mmsg,$mmob);	
			
			
		     echo $complaintno;
		}
		public function deleteService()
		  {
		   $cid=$this->input->post('id');
		   $mid=decode($cid);
		   $data=array('status'=>3);
		   $array= array('ser_id'=>$mid);
		   $this->db->where($array);
		   $this->db->update('tbl_service',$data);	
			
		}
		public function editservice($mid){ 
		    $id=$mid;
			$array=array('status'=>0,'ser_id'=>$id);
			$this->db->where($array);
			$this->db->select('*');
       		$result=$this->db->get('tbl_service');
       		return $rows=$result->result();
		}
		public function addbin(){
			    $max=maxplus('tbl_bin','bin_id');
				$today= date("y-m-d");
 				$category=$this->input->post('selcat');
				$subcategory=$this->input->post('selsubcat');
				$product=$this->input->post('selproduct');
				$unit=$this->input->post('selunit');
				$quantity=$this->input->post('quantity');
				$reason=$this->input->post('reason');
				$description=$this->input->post('description');
				$txtrack=$this->input->post('txtrack');
				 
				$data= array(
						'org_id'=>$this->session->userdata('org_id'),
						'bin_id'=>$max,
					   	'cat_id'=>$category,
						'sub_id'=>$subcategory,
					   	'pro_id'=>$product,
						'unit'=>$unit,
						'qty'=>$quantity,
						'bin_date'=>$today,
						'reason'=>$reason,
						'description'=>$description,
						'rack'=>$txtrack,
						'user_bin'=>$this->session->userdata('org_id'),
						'crea_date'=>$today,
						'mod_date'=>$today,
						'status'=>0,
				);
				
			$this->db->insert('tbl_bin',$data);
			}
		public function updateservice(){
		    $today=date('Y-m-d');
			$eid=decode($this->input->post('hdnid'));
			$array= array('ser_id'=>$eid);
			$data= array(
		       'ser_name'=>$this->input->post('sname'),
			   'ser_address'=>$this->input->post('address'),
			   'ser_product'=>$this->input->post('product'),
			   'yr_of_manu'=>$this->input->post('yrofmanu'),
			   'ser_warranty'=>$this->input->post('warranty'),
			   'ser_delivery_date'=>$this->input->post('exdeldate'),
			   'ser_complaints'=>$this->input->post('cmplnts'),
			   'ser_mobile'=>$this->input->post('mobile'),
			   'ser_alternative'=>$this->input->post('altnumber'),
			   'ser_email'=>$this->input->post('semail'),
			   'status'=>0,
			   'modified_date'=>$today,
			);	
			$this->db->where($array);
		    $this->db->update('tbl_service',$data);
		
		}
		
		public function newgetproduct(){
			$id= $this->input->post('id');
			$array=array('subcat_id'=>$id,'status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');//ptax_propery,ptax_u_id
			$result=$this->db->get('tbl_product');
			$rows=$result->result();
			$count=$result->num_rows();
			$html='';
				if($count > 0)
				{
					$html.='<option value="0" class="bt">Select Product</option>';
					foreach($rows as $val =>$key)
					{
						$html.='<option value="'.$key->product_id.'">'.$key->product_name.'</option>';
					}
				}else{
					$html.='<option value="0">-- No result  --</option>'; 
				}
			echo $html;
	}



}