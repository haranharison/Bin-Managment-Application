<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Salesman extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->load->model('Salesman_model','model');
	 }	
	 public function index()
	{
		$data['area']=$this->model->getarea();
		$data['salesman']=$this->model->getsalesman();
		$this->load->view('admin/header');
		$this->load->view('admin/salesman/salesmanregistration',$data);
		$this->load->view('admin/footer');
	}
	 public function salesmanreg()
	{
		
		$this->model->addsalesman();	
		
	}
	public function salesmanproductsadd()
	{
		
		$data['salesman']=$this->model->getsalesmanid();
		$data['productcat']=$this->model->getcategory();
		//var_dump($data['productcat']);
		$this->load->view('admin/header');
		$this->load->view('admin/salesman/salesmanproductsadd ',$data);
		$this->load->view('admin/footer');
	}
	public function getsubcategorybycategoryid()
	{ //fetching sucbcategory by category 
		$this->model->getsubcategorybycategoryid();
		
	}
	public function getproductsbysubcategoryid()
	{ //fetching products by sucbcategory 
		$this->model->getproductsbysubcategoryid();
		
	}
	public function addsalesmanproduct()
	{ //add salesman product
		$this->model->addsalesmanproduct();
		
	}
	public function editSalesmanreg($id=false)
	
	{ // editSalesmanregvar_dump($id);
	//$data['editsalesman']=	$this->model->editSalesmanreg($id);
	$data['salesman']=$this->model->getsalesmanbyid($id);
	//var_dump($datas['salesmans']);
	$data['area']=$this->model->getarea();
		$this->load->view('admin/header');
		$this->load->view('admin/salesman/editsalesmanregistration',$data);
		$this->load->view('admin/footer');
	}
	
	 public function upsalesmanreg()
	{
		
			$this->model->upSalesmanreg();
		
	}
	public function editsalesmanproducts($id=false)
	{ 
	$data['salesman']=$this->model->getsalesmanprobyid($id);
	$data['salesmancat']=$this->model->getsalesmancatbyid($id);
	$data['salesmansubcat']=$this->model->getsalesmansubcatbyid($id);
	    $data['salesmanid']=$id;
		$data['productcat']=$this->model->getcategory();
		$data['productsubcat']=$this->model->getsubcategory();
		$data['products']=$this->model->getproducts($data['salesmansubcat'][0]);
		$this->load->view('admin/header');
		$this->load->view('admin/salesman/editsalesmanproducts',$data);
		$this->load->view('admin/footer');
	}
	 public function upsalespro()
	{
		
			$this->model->upsalespro();
		
	}
	public function deleteSalesman(){
		//echo $id;
		$this->model->deleteSalesman();
		}
}
