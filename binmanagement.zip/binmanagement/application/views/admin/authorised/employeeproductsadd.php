

  <style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
</style>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
				<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Icons</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Sales Man</h1>
			</div>
		</div><!--/.row-->
		
		
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Sales man Products</div>
					<div class="panel-body">
						<div class="col-md-6">
							<form role="form" method="post" action="" name="frmsalesmanpro" id="frmsalesmanpro">
							
							<fieldset>
							  <div class="form-group">
									<input type="hidden" name="salesmanid" value="<?php echo $salesman->salesmanid ?>" />
									<select class="form-control form-control1" id="selcat" name="selcat">
                                    <option value="0">Product Category</option>
                                    	
										<?php foreach($productcat as $key){?>
											
											<option value="<?php echo $key->cat_id;?>"><?php echo $key->cat_name;?></option>
											
									<?php		}?>
									</select>
								</div>
							 <div class="form-group">
									
									<select class="form-control " id="selsubcat" name="selsubcat">
                                    	<option value="0">Product Subcategory</option>
										
									</select>
								</div>
                        
                        <div class="form-group">
									    <div class="chkbx1">
                                        <div class="chkbx2">
                                    <label>Products</label>
                                    </div>
                                    <div class="chkbx3">
									<div class="checkbox"  id="pro">
                                     
							<!--			<label>
											<input type="checkbox" value="">Mobiles
										</label>
                                        -->
                                        	<!--<label>
											<input type="checkbox" value="">Sim
										</label>
                                        
                                        <label>
											<input type="checkbox" value="">Nano Sim
										</label>-->
									</div>
								
									<!--<div class="checkbox">
										
									 
										<label >
											<input type="checkbox" value="">Reacharge Card
										</label>
									
										<label>
											<input type="checkbox" value="">Net Card
										</label>
									</div>-->
                                 </div>
                                 
                                    </div>
						
                          </div>
                           
							<!--<div class="text-center"><a href="index.html" class="btn btn-primary btn-block lg">Submit</a></div>-->
                            
                              <div class="col-md-6" >
                              <button type="button" name="btnsubmit" id="btnsubmit" class="btn btn-primary btn-block lg" style="float:right;">Submit</a></div>
                            	<div class="col-md-6" >  <button type="button" id="btncancel" class="btn btn-default btn-block lg " style="float:left;">Cancel</a></div>
								
                            
                            </fieldset>
							</form>	
							
								</div>								
								
                                </div>
                           
						 <div class="panel-footer"></div>
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->

<script type="text/javascript">

$(document).ready(function(e) {
	
	//-----changing subcategory on selecting category-------//
		$("#selcat").change(function(e) {
	//alert(1);
	var catid=$( this).val();
//	alert(catid);
			 	$.ajax({
			   	type:"post",
			   	url:"<?php echo ADMIN_PATH;?>salesman/getsubcategorybycategoryid",
			  	data:"catid="+catid,
				success:function(data){
				//	alert(data);
					$("#selsubcat").html(data);
					}		   
			   			});
        });
		
		//-----changing products on selecting subcategory-------//
		$("#selsubcat").change(function(e) {
	//alert(1);
	var catid=$( this).val();
//	alert(catid);
			 	$.ajax({
			   	type:"post",
			   	url:"<?php echo ADMIN_PATH;?>salesman/getproductsbysubcategoryid",
			  	data:"catid="+catid,
				success:function(data){
				//	alert(data);
					$("#pro").html(data);
					}		   
			   			});
        });
		
		//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			//alert(1);
			var e=validation();
			if(e==0){
  			var url="<?php echo ADMIN_PATH?>salesman/addsalesmanproduct";
  			var redirect = "<?php echo ADMIN_PATH?>salesman";
  			var form = document.forms.namedItem("frmsalesmanpro");                        
			var oData = new FormData(document.forms.namedItem("frmsalesmanpro"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
					
				 if(oReq.responseText==1){
					  alert("1");
					  alert("Exist");
					 }
					 else
					 {  swal("Success!", "Products added!", "success")
 					document.location = redirect;
					 }}
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
			function validation(){

        error=0;

        $('input').removeClass('errors');

        $('input').removeClass('errorInput');

        $('select').removeClass('errors');

        $('select').removeClass('errorInput');
        

            var values = {
                                    'merchantcategory':$('#selcat').val(),
									 'merchantsubcat':$('#selsubcat').val(),

                                 }

        if(values.merchantcategory ==0){
            $('#selcat').addClass('errors');
            $('#selcat').after( "Please select category.")
			$('#selcat').css({'border':'1px solid red'});
		    $('#selcat').addClass('errorInput');
            error=1;
        } 
		 if(values.merchantsubcat ==0){
            $('#selsubcat').addClass('errors');
            $('#selsubcat').after( "Please select subcategory.")
			$('#selsubcat').css({'border':'1px solid red'});
		    $('#selsubcat').addClass('errorInput');
            error=1;
        } 
        return error;
    }
	
			
			//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmsalesmanpro').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
});
	</script>