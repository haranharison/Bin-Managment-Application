

<!--start container-->
          <div class="container">
            <div class="section">
              <!-- Form with placeholder -->
              <div id="basic-form" class="section">
                <div class="row">
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2" style="letter-spacing:1">Education </h4>
                      <div class="row">
                       <form role="form" name="frmeducation" action="" method="post">
                          <div class="row">
                            <div class="input-field col s12">
                              <input autofocus="autofocus" name="ename" id="ename" type="text">
                              <label for="first_name">Education Name</label>
                            </div>
                          </div>
                  
                          
                          <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right"  type="button" name="action" id="btnsent">Submit
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                <!--Basic Form-->  
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Education Details</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:20px;text-align:center;">SN</th>
                          <th style="text-align:left;">Education Names</th>
                              
                          <th style="width:75px"></th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php  if($edu) { $i=1; foreach($edu as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:20px;text-align:center;"><?php  echo $i ?></td>
								<td style="text-align:left;"><?php  echo $val->educationname?> </td>
                              
								<td style="width:75px"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan btnedits"  data-id="<?php  echo encode($val->education_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btndelt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php  echo $val->education_id?>" href="#">
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php  $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

  
<script type="text/javascript">

$(document).ready(function(e) {
   	//------insert -------------//
       	 $("#btnsent").click(function(ev) {
			//alert(1);
			var e=validation();
			if(e==0){
					$('.overlay').css({'display':'flex'});
  			var url="<?php  echo ADMIN_PATH?>education/inserteducation";
  			var redirect = "<?php echo ADMIN_PATH?>education";
  			var form = document.forms.namedItem("frmeducation");                        
			var oData = new FormData(document.forms.namedItem("frmeducation"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //console.log(oReq.responseText);
				//console.log(oReq.responseText);
						$('.overlay').css({'display':'none'});
				 if(oReq.responseText==1){
					// alert("Exist");
					swal("Already Exist!", "Exist!", "error")
					  //alert("Exist");
					 }
					 else
					 {
						 customSwalFunD("Success", "Education has beeen Added!", "success")
 						document.location = redirect;
					 }
					
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){
        error=0;
		$('label').removeClass('labelerror');
        $('input').removeClass('errors');
      //  $('input').removeClass('errorInput');
        $('select').removeClass('errors');
     //   $('select').removeClass('errorInput');
        var values = {'eduname':$('#ename').val(),
						
							}
        if(values.eduname == ''){
			$('#ename').parent().children('label').addClass('labelerror active');
            $('#ename').addClass('errors');
            $('#ename').attr("placeholder", "Please Enter Education Name")
			//$('#txttax').css({'border':'1px solid red'});
		  //  $('#txttax').addClass('errorInput');
            error=1;
        } 
		
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmncat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	

	
	
	// ---------- < Delete tax Name   > ---------- //
$(document).on('click', '.btndelt', function(){
	$btn=$(this);
	$tr=$btn.parent().parent();
	console.log($tr);
	var id=$(this).attr('rel');  
	swal({
  title: "Are you sure?",
  text: "Your will not be able to recover this Data!",
  type: "warning",
  showCancelButton: true,
  confirmButtonClass: "btn-danger",
  confirmButtonText: "Yes, delete it!",
  customClass: 'swal-delete',
  cancelButtonText: "No, cancel!",
  
}).then(function(){
		$('.overlay').css({'display':'flex'});
			 $.ajax({
                                            type:"post",
                       						url: "<?php echo ADMIN_PATH ?>education/deleteeducation",
                                            data:"id="+id,
                                            success:function(data){
													$('.overlay').css({'display':'none'});
												 //alert(data);
												/*swal({
												  title: '<div class="tst" >Deleted</div>',
												  html:'<div class="tst1" >Employee has been deleted</div>',
												  type: 'success',
												  customClass: 'swal-delete',
												})*/
												customSwalFunD(
														  'Success!',
														  'Data has been Deleted',
														  'success'
														)
												$tr.remove();
											//	location.reload() ;
											 }
								});
			});
			/*
function(isConfirm) {
  if (isConfirm) {
	  alert(0)
	  $.ajax({
                    type:"post",
					url: "<?php  echo ADMIN_PATH ?>tax/deletetax",
					data:"id="+id,
					success:function(data){ 
					alert(data);
								swal("Sucessfully!", "Sucessfully Deleted!", "success");
								location.reload() ;
          						}
						});//AJAX END
  //  swal("Deleted!", "Your imaginary file has been deleted.", "success");
  } 
  else {
    swal("Cancelled", "Your imaginary file is safe :)", "error");
}*/

});


		// ---------- < Delete Category ENDS > ----------
	$(document).on('click', '.btnedits', function(){	
	  var eid=$(this).attr('data-id');
	    var name='';
		 var pper='';
	getval();
	function getval(){
	
			 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>education/getdetails",
														data:"eid="+eid,
														success:function(data){  
														
														data=JSON.parse(data);
														//alert(data.name);
															name=data.name;
															
														updateform()
												}
			 		
										 })
		
		
		}
	
	
	function updateform(){
		  					//  var name=$("#ad").val();
							
				swal({
						  title: 'Edit Education Name ',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input role="tax-name-content" autofocus="autofocus" placeholder="Enter education Name" name="txtname" spellcheck="false" id="txtname" type="text" value="'+name+'" ><label for="first_name" class="active">Education Name</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Update',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var txtpname=$("#txtname").val();
									
									
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors');
									if(txtpname==''){
											$('#txtname').parent().children('label').addClass('labelerror');
											$('#txtname').addClass('errors');
											$('#txtname').attr("placeholder", "Please enter Name");
										err=1;
										}
									
									return err;	
							}
								if(ev==0){
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
										url: "<?php echo ADMIN_PATH ?>education/updateeducation",
														data:"txtpname="+txtpname+"&eid="+eid,
														
														success:function(data){ 
														//console.log(data);
															$('.overlay').css({'display':'none'}); 
																resolve();	  
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
									swal({
		  title: '<div class="tst" >Success</div>',
		  html:'<div class="tst1" >Data has been Updated</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
		setTimeout(function(){
			location.reload() ;
			},600)
		
			 
			  	});
	}
	});
	});
</script>


    
    
    
    
    
    
    
    
    

