 <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDR07gIkjnjfMhUqqj5WPZ3oUAjoo49wKQ"></script>
          <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/jquery-ui.js" type="text/javascript"></script>
    <link href="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/themes/blitzer/jquery-ui.css" rel="stylesheet" type="text/css" />  
<style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
			 .panel-heading1 {
		 font-size: 18px;
    font-weight: 300;
    letter-spacing: 0.025em;
    height: 66px;
    line-height: 45px;
    background: ##ddd;
    border-bottom: 1px solid #eee;
    color: #333;
	padding: 10px 15px;
    /* background: #428bca; */
}
</style>


		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		</br>
				
		
		<!--<div class="row">
			  <div class="col s12 m12 l6">
				<div class="panel panel-default">-->
                 <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                <div class="col s12 m12 l6">
                 <!--   <div class="card-panel">
					<div class="panel-heading">Edit Area</div>-->
                    <div class="card-panel">
                      <h4 class="header2">Edit Area</h4>
						 <div class="row">
                        <form role="form" name="frmuparea" action="" method="post">
                         <div class="row">
                           <div class="input-field col s12">
                           <input  type="hidden" placeholder="area" name="txthiden" id="txthiden"  value="<?php if($edit){  echo encode($edit->area_id);}?>" >
                              <input placeholder="Enter Area Name" name="addarea" id="addarea" type="text" value="<?php if($edit){  echo $edit->area_name; }?>">
                              <label for="first_name">New Area</label>
                            </div>
                          </div>
                          <div class="row"> 
                         <i class="material-icons" id="maps" style="color: #00bdd5;margin-left:11px;cursor: pointer;">pin_drop</i>
                            <div class="input-field col s12">
                              <input placeholder="Latitude" name="latitude" id="latitude" type="text" value="<?php if($edit){ echo $edit->latitude; }?>">
                            <label for="first_name">Latitude</label>
                            </div>
                          </div>
                          <div class="row">
                            <div class="input-field col s12">
                              <input placeholder="Longitude" name="longitude" id="longitude" type="text" value="<?php if($edit){ echo $edit->longitude;}?>">
                              <label for="first_name">Longitude</label>
                            </div>
                          </div>
                          
                          
                          
                          
                          <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                              <a href="#" class="btn cyan waves-effect waves-light right" id="btnupdate" style="float:right:">Update    <i class="material-icons right">send</i></a>
<!--                              <a href="" id="btncancel" class="btn cyan waves-effect waves-light right" style="float:left;">Cancel</a>
-->                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btncancel">Cancel
                                 <!-- <i class="material-icons right">send</i>-->
                               </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
				</div>
                	<!-- <div class="panel-footer"></div>-->
                     </div>
                     
                    <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Area</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:20px;text-align:center;">SN</th>
                          <th style="text-align:left;">Area</th>
                          <th style="width:75px"></th>
                          
                        </tr>
                      </thead>
                      <tbody>
                          <?php if($area) { $i=1; foreach($area as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:20px;text-align:center;"><?php echo $i ?></td>
								<td style="text-align:left;"><?php echo $val->area_name?> </td>
								<td style="width:75px"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>area/editArea/<?php echo encode($val->area_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo $val->area_id?>" href="#">
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
                  </div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->
    </div>
   </section>
   	 <div class="panel-footer"></div>
                 
    <script src="<?php echo ADMIN_STYLEPATH ?>js/jquery-1.11.1.min.js" type="text/javascript"></script>


<script type="text/javascript">

$(document).ready(function(e) {
   	//------insert -------------//
       	 $("#btnupdate").click(function(e) {
			//alert(1);
			var e=validation();
			if(e==0){
				$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>area/updatearea";
  			var redirect = "<?php echo ADMIN_PATH?>area";
  			var form = document.forms.namedItem("frmuparea");                        
			var oData = new FormData(document.forms.namedItem("frmuparea"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
					$('.overlay').css({'display':'none'});
				 if(oReq.responseText==1){
					  customSwalFunD("Already Exist!", "Exist!", "Exist")
					  
					 }
					 else
					 {
						  customSwalFunD("Success", "Sucessfully updated!", "success")
 					document.location = redirect;
					 }}
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');

        $('input').removeClass('errorInput');

        $('select').removeClass('errors');

$('input').removeClass('errors');
		$('label').removeClass('labelerror');
        $('select').removeClass('errors');
       
        

            var values = {
                                    'addarea':$('#addarea').val(),
									'latitude':$('#latitude').val(),
									'longitude':$('#longitude').val(),

                                 }

       if(values.addarea == ''){
			
			  $('#addarea').addClass('errors');
              $('#addarea').attr("placeholder", "Please enter Area.");
			  $('#addarea').parent().children('label').addClass('labelerror');
		 error=1;
             } 
		  if(values.latitude == ''){
				 
            $('#latitude').addClass('errors');
            $('#latitude').attr("placeholder", "Please enter Latitude.");
			//$('#latitude').parent().children('label').addClass('labelerror');
	        error=1;
		  }
		    if(values.latitude == ''){
				
            $('#longitude').addClass('errors');
            $('#longitude').attr("placeholder", "Please enter Longitude.");
			//$('#longitude').parent().children('label').addClass('labelerror');
			 error=1;
			 }  
		  
        return error;
    }
	
$('#latitude').keyup(function(){
		   // $('#date').val('');
		   if(isNaN($(this).val())){
               $(this).val('');
			   $(this).focus();
			}
			
		  });
		  $('#longitude').keyup(function(){
		   // $('#date').val('');
		   if(isNaN($(this).val())){
               $(this).val('');
			   $(this).focus();
			}
    });

//---------Cancel------//
		$('#btncancel').click(function (){
          		var redirect="<?php echo ADMIN_PATH?>area";
					document.location = redirect;
				
        });
	//---------End cancel------//	
	
	
	    $(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
 swal({
                            title: "Are you sure?",
							   text: "Delete this Area",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:"swal-delete",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          }).then(function(){
						  $('.overlay').css({'display':'flex'});
			
			var redirect = "<?php echo ADMIN_PATH?>area";
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>area/deleteArea",
					//	 redirect : "<?php echo ADMIN_PATH?>category",

                                            data:"id="+id,

                                            success:function(data){ //alert(data);
											$('.overlay').css({'display':'none'});	
											
                                               // $(".loader").remove();

                                	document.location = redirect;
	customSwalFunD("Sucessfully!", "Sucessfully deleted!", "success")
                                            }
           
     

                                        });
					

				          });

		
			  
        });
	
	
	
	
	
	
	
	
});
</script>
<script type="text/javascript">
  
	$(document).ready(function(e) {
		if($('#latitude').val()=='' ||$('#longitude').val()==''  ){
			vlat=8.8932118;
			vlong=76.6141396;
			}
			else{
			vlat=$('#latitude').val();
			vlong=$('#longitude').val();
				}
		$('.ui-dialog').remove();
		$('.ui-widget-content').remove();
		$('.mapclass').each(function(index, element) {
            $(this).remove();
        });
    });
        $(function () {
			
			$(window).resize(function(){
           $('.ui-dialog').css({"width":"75%"});
		   $('.ui-dialog').css({"left":"12%"});
              });
			 $(document).delegate("#maps","click",function(){  
			 
				$('.ui-dialog').remove();
				$('.ui-widget-content').remove();
				$("#dialog").addClass("mapclass");
				 var map = ''; 
                $("#dialog").dialog({
                    modal: true,
                    title: "Pick your Google Map Value",
                    width: 900,
                    hright: 500,
                    buttons: {
                        Close: function () {
                            $(this).dialog('close');
                        }
                    },
                    open: function () {
					var map = ''; 
					$('.ui-dialog').css({"width":"75%"});
		                 $('.ui-dialog').css({"left":"12%"});
						 var markers = [];
						  var markers = "";
						  var styles =   [
					{
						"featureType": "all",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "all",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "administrative",
						"elementType": "geometry",
						"stylers": [
							{
								"color": "#ffebc5"
							},
							{
								"lightness": "-10"
							}
						]
					},
					{
						"featureType": "administrative",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "administrative.country",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#b70046"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4b"
							},
							{
								"weight": "0.50"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "administrative.locality",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "administrative.locality",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#ff850a"
							}
						]
					},
					{
						"featureType": "administrative.neighborhood",
						"elementType": "geometry",
						"stylers": [
							{
								"visibility": "on"
							}
						]
					},
					{
						"featureType": "administrative.neighborhood",
						"elementType": "labels",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "landscape",
						"elementType": "all",
						"stylers": [
							{
								"color": "#f2f2f2"
							}
						]
					},
					{
						"featureType": "landscape",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"saturation": "-71"
							},
							{
								"lightness": "-2"
							},
							{
								"color": "#ffebc5"
							}
						]
					},
					{
						"featureType": "poi",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "poi.park",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#70bfaf"
							}
						]
					},
					{
						"featureType": "road",
						"elementType": "all",
						"stylers": [
							{
								"saturation": -100
							},
							{
								"lightness": 45
							},
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#ffffff"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4c"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#ffffff"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "labels.icon",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "road.local",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "transit",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "all",
						"stylers": [
							{
								"color": "#7ccff0"
							},
							{
								"visibility": "on"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#cfeae4"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#109579"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					}
				];
                        var mapOptions = {
                            center: new google.maps.LatLng(vlat, vlong),
                            
				 zoomControl: true,
                  zoomControlOptions: {
                 position: google.maps.ControlPosition.LEFT_CENTER
                   },
				   fullscreenControl: true,
				   scrollwheel: false,
					navigationControl: false,
					mapTypeControl: false,
					scaleControl: false,
			         zoom: 6,
					 styles: styles,
			  disableDefaultUI: true,
			  mapTypeId: google.maps.MapTypeId.ROADMAP
                        }
                        var map = new google.maps.Map($("#dvMap")[0], mapOptions);
						 var haightAshbury = {lat:vlat, lng: vlong};
						addMarker(haightAshbury, map);
						/* marker = new google.maps.Marker({
                           map: map,
						   draggable: true,
						   position: new google.maps.LatLng(23.8859, 45.0792),
                          });
						  markers.push(marker);*/
				 google.maps.event.addDomListener(window, "resize", function() {
						 var map="";
						 var styles =   [
					{
						"featureType": "all",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "all",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "administrative",
						"elementType": "geometry",
						"stylers": [
							{
								"color": "#ffebc5"
							},
							{
								"lightness": "-10"
							}
						]
					},
					{
						"featureType": "administrative",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "administrative.country",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#b70046"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4b"
							},
							{
								"weight": "0.50"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "administrative.locality",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "administrative.locality",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#ff850a"
							}
						]
					},
					{
						"featureType": "administrative.neighborhood",
						"elementType": "geometry",
						"stylers": [
							{
								"visibility": "on"
							}
						]
					},
					{
						"featureType": "administrative.neighborhood",
						"elementType": "labels",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "landscape",
						"elementType": "all",
						"stylers": [
							{
								"color": "#f2f2f2"
							}
						]
					},
					{
						"featureType": "landscape",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"saturation": "-71"
							},
							{
								"lightness": "-2"
							},
							{
								"color": "#ffebc5"
							}
						]
					},
					{
						"featureType": "poi",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "poi.park",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#70bfaf"
							}
						]
					},
					{
						"featureType": "road",
						"elementType": "all",
						"stylers": [
							{
								"saturation": -100
							},
							{
								"lightness": 45
							},
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#ffffff"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4c"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#ffffff"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "labels.icon",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "road.local",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "transit",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "all",
						"stylers": [
							{
								"color": "#7ccff0"
							},
							{
								"visibility": "on"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#cfeae4"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#109579"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					}
				];
						  var mapOptions = {
							  
				 zoomControl: true,
                  zoomControlOptions: {
                 position: google.maps.ControlPosition.LEFT_CENTER
                   },
				   fullscreenControl: true,
				   scrollwheel: false,
					navigationControl: false,
					mapTypeControl: false,
					scaleControl: false,
			         zoom: 6,
                            center: new google.maps.LatLng( vlat, vlong),
                          styles: styles,
			  disableDefaultUI: true,
			  mapTypeId: google.maps.MapTypeId.ROADMAP
                        }
                        var map = new google.maps.Map($("#dvMap")[0], mapOptions);
						 var haightAshbury = {lat:vlat, lng: vlong};
						addMarker(haightAshbury, map);
						  });
		 google.maps.event.addListener(map, 'click', function(event) {
				addMarker(event.latLng, map);
				$('#longitude').val(event.latLng.lng());
	            $('#latitude').val(event.latLng.lat());
			  });
         function addMarker(location, map) {
			 
				clearMarkers();
                  markers = [];
			   marker = new google.maps.Marker({
				position: location,
				draggable: true,
				map: map
			  });
			   markers.push(marker);
			}
		function setMapOnAll(map) {
			for (var i = 0; i < markers.length; i++) {
			  markers[i].setMap(map);
			}
		  }
		  function clearMarkers() {
			setMapOnAll(null);
		  }
		 google.maps.event.addListener(marker, 'dragend', function (event) {
			$('#longitude').val(event.latLng.lng());
	        $('#latitude').val(event.latLng.lat());
			});
			
           
                    }
					
                });
				 
				
            });
        });
    </script>
  <div id="dialog" style="display: none">
        <div id="dvMap" style="height: 500px; width: 100%;">
        </div>
    </div>

    
    
    
    
    
    
    
    

