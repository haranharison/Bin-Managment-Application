<?php
class Merchantopeningbalance_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        
		public function getcategory()
		{
				$array=array('status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_merchant')->result();
		}
		
		public function addopeningbalance()
	{
		$exist=fieldexist('tbl_opening_balance','openingbalance',$this->input->post('txtopeningbalance'));
	if($exist==1){
		echo 1;
	}else{
		$max=maxplus('tbl_opening_balance','openbalance_id');
		$today= date("y-m-d");
		$openingbalance=$this->input->post('txtopeningbalance');
		$category=$this->input->post('selcat');
		$date=$this->input->post('txtdate');
		$data= array(
		       'openbalance_id'=>$max,
			   'openingbalance'=>$openingbalance,
			   'merchant'=>$category,
			    'date'=>$date,
			   'create_date'=>$today,
			   'modify_date'=>$today
		);
		$this->db->insert('tbl_opening_balance',$data);
		}
	}
	public function getopenigbalance()
		{
				$array=array('tbl_opening_balance.status'=>0);
		$this->db->where($array);
//	$this->db->group_by('tbl_merchant.merchant_id');
		$this->db->select('tbl_opening_balance.*,tbl_merchant.merchant_id,tbl_merchant.merchantname');
		$this->db->from('tbl_opening_balance');
		$this->db->join('tbl_merchant as tbl_merchant', 'tbl_opening_balance.merchant=tbl_merchant.merchant_id');
	
		return $result = $this->db->get()->result(); 
		}
		
		
		public function getopenigbalancebyid($id)
		{
				$array=array('tbl_opening_balance.status'=>0,'tbl_opening_balance.openbalance_id'=>$id);
		$this->db->where($array);
//	$this->db->group_by('tbl_merchant.merchant_id');
		$this->db->select('tbl_opening_balance.*,tbl_merchant.merchant_id,tbl_merchant.merchantname');
		$this->db->from('tbl_opening_balance');
		$this->db->join('tbl_merchant as tbl_merchant', 'tbl_opening_balance.merchant=tbl_merchant.merchant_id');
	
		return $result = $this->db->get()->result(); 
		}
		
		
		public function editopenigbalance()
		{
							$array=array('tbl_opening_balance.status'=>0);
		$this->db->where($array);
//	$this->db->group_by('tbl_merchant.merchant_id');
		$this->db->select('*');
		$this->db->from('tbl_opening_balance');
	
		return $result = $this->db->get()->row(); 
		}
		
		public function delete()
		{
				$cid=$this->input->post('id');
		   $data=array('status'=>1);
		   $array= array('openbalance_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_opening_balance',$data);
		}	
		
		
		
		public function update()
		{
				$cid=$this->input->post('txthiden');
					$category=$this->input->post('selcat');
		$date=$this->input->post('txtdate');
		$openingbalance=$this->input->post('txtopeningbalance');
		$data= array(
			   'openingbalance'=>$openingbalance,
			   'merchant'=>$category,
			    'date'=>$date,
			   'create_date'=>$today,
			   'modify_date'=>$today
		);
		  
		   $array= array('openbalance_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_opening_balance',$data);
		}
}