<?php
class Services_model extends CI_Model 
{	
    public function __construct()
	{
        $this->load->database(); 
    }	
	
	
	
	public function getbrand()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_brand')->result();
		}
		public function getmodelz()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_model')->result();
		}
		
public function getmodel()
			{
				 $brand=decode($this->input->post('brand'));
				
				//echo json_encode($brand);
				
				 $arr=array('tbl_model.brand_id'=>$brand);
				 $this->db->where($arr);
				 $this->db->select('*');
				 $this->db->from('tbl_model');
				$results=$this->db->get();
				 $rows=$results->result();
				 $html='';
				if($results->num_rows() > 0)
				{
					$html.='<option value="0">Select model</option>';
					foreach($rows as $key)
					{
					 $html.='<option value="'.encode($key->model_id).'">'.$key->model_name.'</option>';
					}
				}else{
					$html.='<option value="0">-- No result --</option>';
						}
			echo $html;
				
			}	
		
		public function getservices()
		{
			$ar2=array('org_id'=>$this->session->userdata('org_id'));
			$this->db->where($ar2);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_services_details')->result();
		}
		
		public function getservicereg()
		{
			$ar2=array('org_id'=>$this->session->userdata('org_id'));
			$this->db->where($ar2);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_servicereg')->result();
		}
		public function getamenity()
		{
			
			if($this->session->userdata('org_id')=="")
			{
		   		$this->db->where('tbl_service_amenity.org_id','admin');
	   		}
	   		else
	   		{
		   		$this->db->where('tbl_service_amenity.org_id',$this->session->userdata('org_id'));
	  		}
			
			
			/*$array=array('tbl_service_amenity.org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);*/
			
			$this->db->select('*');
			return $rows=$this->db->get('tbl_service_amenity')->row();
		}
		public function getbikedetails($mid)
		{
			$id=$mid;
			$array=array('tbl_services_amenity.se_id'=>$id);
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_services_amenity')->result();
		}
		public function getserjobs($mid)
		{
			$id=$mid;
			$array=array('tbl_services_job.servjob_id'=>$id);
			$this->db->where($array);
			$this->db->select('tbl_service_jobs.*,tbl_services_job.*');
			$this->db->from('tbl_services_job');
			$this->db->join('tbl_service_jobs','tbl_service_jobs.jobs_id=tbl_services_job.ser_job');
			return $rows=$this->db->get()->result();
		}
		
		public function getservicedetails($id)
		{$id=decode($id);
			$array=array('servicereg_id'=>$id);
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_servicereg')->row();
		}
		
		
		
		
		public function getvehicledetails($id)
		{$id=decode($id);
			$array=array('servicereg_id'=>$id);
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_vehicledetails')->result();
		}
		public function getbikeaccess($mid)
		{
			$id=$mid;
			$array=array('ser_id'=>$id);
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_services_item')->result();
		}
		//previous history
		public function gethistory($mid)
		{
			$id=$mid;
			$array=array('tbl_services_history.serv_id'=>$id);
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_services_history')->result();
		}
		//schedule
		public function getschedule($mid)
		{
			$id=$mid;
			$array=array('tbl_services_details.s_id'=>$id);
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_services_details')->row();
		}
		//
			public function getdriver()
			{
				$this->db->select('*');
			return $rows=$this->db->get('tbl_driverdetails')->result();
			}
		public function getamtitle()
		{
			$array=array('org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_s_amenity')->result();
		}
		
		public function getitemtitle()
		{
			$array=array('org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_s_items')->result();
		}
		
		function getservicejobs()
   		{
	 	 	if($this->session->userdata('org_id')=="")
			{
		   		$this->db->where('org_id','admin');
	   		}
	   		else
	   		{
		   		$this->db->where('org_id',$this->session->userdata('org_id'));
	  		}
	   		$this->db->select('*');
	  		return $res= $this->db->get('tbl_service_jobs')->result();	   
		}	
		public function insertdetails()
		{ 
		$max=maxplus('tbl_login','id');	
			$today=date('Y-m-d');
			$name=$this->input->post('sname');
			$no=$this->input->post('mobile');
			 $n=substr($name,0,2);
			 $regid=$n.$no;
			// echo json_encode($regid);
			if($this->session->userdata('org_id')=='')
			{
				$orgid='admin';
			}
			else
			{
				$orgid=$this->session->userdata('org_id');
			}
			
			$email=fieldexist2('tbl_servicereg','email',$this->input->post('semail'));
			$mob=fieldexist2('tbl_servicereg','mobile',$no);
			$email=$this->input->post('semail');
			if($email==0 && $mob==0)
			{
			$data=array('servicereg_id' =>$max,
					    'org_id'=>$orgid,
					    'name'=>$name,
					    'address'=>$this->input->post('address'),
					    'telno'=>$this->input->post('telr'),
					    'regid'=>$regid,
					    'mobile'=>$no,
					    'email'=>$email,
					    'created_on'=>$today,
					    'modified_on'=>$today);
						
			$this->db->insert('tbl_servicereg',$data);
			
			
			$data=array('emp_id' =>$max,
					    'org_id'=>$orgid,
					    'username'=>$no,
					    'password'=>$this->input->post('password'),
					    'usergroup'=>'own',
						'email'=>$email,
					    'app_status'=>0,
						'created_date'=>$today,
					    'modified_date'=>$today);
						$this->db->insert('tbl_login',$data);


			
			
			
			
			 $brandname=$this->input->post('bname');
			$model=$this->input->post('model');
					  $engno=$this->input->post('engineno');
					    
					  $chaiseno =$this->input->post('chaiseno');
					    $regno=$this->input->post('regno');
						
						 $insurancedudate =$this->input->post('insurancedudate');
					    $motorvehicletest=$this->input->post('motorvehicletest');
						$pollutiontest=$this->input->post('pollutiontest');
						$color=$this->input->post('color');
			$c1=count($brandname);
			for($j=0;$j<$c1;$j++)
			{
			$max1=maxplus('tbl_vehicledetails','vehicleid');
			$datas=array('vehicleid' =>$max1,
					    
						'servicereg_id'=>$max,
					   'brandname'=>decode($brandname[$j]),
					     'model'=>decode($model[$j]),
					    'engineno'=>$engno[$j],
					    
					    'chaiseno'=>$chaiseno[$j],
					    'regno'=>$regno[$j],
						'color'=>$color[$j],
						
						 'insurancedudate'=>$insurancedudate[$j],
					    'motorvehicletest'=>$motorvehicletest[$j],
						'pollutiontest'=>$pollutiontest[$j],
					    
					    'created_on'=>$today,
					    'modified_on'=>$today);
			$this->db->insert('tbl_vehicledetails',$datas);
			}
			echo 22;
			}
			else if(!empty($email))
			{
				echo 33;
			}
			elseif(!empty($mob))
			{
				echo 44;
			}
			
	
			
			}
			public function insertdriver()
			{
				if($this->session->userdata('org_id')=='')
			{
				$orgid='admin';
			}
			else
			{
				$orgid=$this->session->userdata('org_id');
			}
				$today=date('Y-m-d');
				$max=maxplus('tbl_driverdetails','did');
				$no=$this->input->post('mobile');
				$mob=fieldexist2('tbl_driverdetails','mobile',$no);	
				if($mob==0)
				{
				$data=array(
				        'did'=>$max,
					    'dname'=>$this->input->post('sname'),
					    'address'=>$this->input->post('address'),
					    'telno'=>$this->input->post('telr'),
					    'mobile'=>$no,
					    'regid'=>$this->input->post('ownerid'),
						'regno'=>$this->input->post('vid'),
					    'licenseno'=>$this->input->post('lno'),
					    'created_on'=>$today,
					    'modified_on'=>$today);
						$this->db->insert('tbl_driverdetails',$data);
						
						$data=array('emp_id' =>$max,
					    'org_id'=>$orgid,
					    'username'=>$no,
					    'password'=>$this->input->post('password'),
					    'usergroup'=>'dri',
						'email'=>'null',
					    'app_status'=>0,
						 'created_date'=>$today,
					    'modified_date'=>$today
						);
						$this->db->insert('tbl_login',$data);
				echo 22;
				}
				else
				{
				echo 33;
				}
			}
			
			public function updatedriver($id)
			{
				$today=date('Y-m-d');
				//$max=maxplus('tbl_driverdetails','did');	
				$arr=array('did'=>$id);
				$data=array(
				         
					    'dname'=>$this->input->post('sname'),
					    'address'=>$this->input->post('address'),
					    'telno'=>$this->input->post('telr'),
					    
					    'mobile'=>$this->input->post('mobile'),
					    'regid'=>$this->input->post('ownerid'),
						'regno'=>$this->input->post('vid'),
					    'licenseno'=>$this->input->post('lno'),
					   // 'created_on'=>$today,
					    'modified_on'=>$today);
						$this->db->where($arr);
						$this->db->update('tbl_driverdetails',$data);
				echo 22;
			}
			
			public function vehicle($id)
		{
		$array1=array('did'=>$id);
			$this->db->where($array1);
			$this->db->select('*');
		$rows=$this->db->get('tbl_driverdetails')->row();
		
		$array2=array('regid'=>$rows->regid);
			$this->db->where($array2);
			$this->db->select('*');
		$row=$this->db->get('tbl_servicereg')->row();
		
		$array3=array('servicereg_id'=>$row->servicereg_id);
			$this->db->where($array3);
			$this->db->select('*');
		 return $row1=$this->db->get('tbl_vehicledetails')->result();	
		 //var_dump($row1);
		}
			public function getdriverdetails($id)
		{
			$array=array('did'=>$id);
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_driverdetails')->row();
		}
			public function getvehiclereg()
			{
				 $cid=$this->input->post('cid');
				// echo json_encode($cid);
				$arr1=array('regid'=>$cid);
				$this->db->where($arr1);
				 $this->db->select('servicereg_id');
				$id= $this->db->get('tbl_servicereg')->row();
				 
				
				 $arr=array('tbl_vehicledetails.servicereg_id'=>$id->servicereg_id);
				 $this->db->where($arr);
				 $this->db->select('regno');
				 $this->db->from('tbl_vehicledetails');
				$results=$this->db->get();
				 $rows=$results->result();
				 $html='';
				if($results->num_rows() > 0)
				{
					$html.='<option selected="true" disabled="disabled" value="0">Vehicle Reg.No</option>';
					foreach($rows as $key)
					{
					 $html.='<option value="'.$key->regno.'">'.$key->regno.'</option>';
					}
				}else{
					$html.='<option value="0">-- No result --</option>';
						}
			echo $html;
				
			}
			
			
			
			
			
			public function updatedetails($id)
		{ //$max=maxplus('tbl_servicereg','servicereg_id');	
			$today=date('Y-m-d');
			
			if($this->session->userdata('org_id')=='')
			{
				$orgid='admin';
			}
			else
			{
				$orgid=$this->session->userdata('org_id');
			}
			$arr=array('tbl_servicereg.servicereg_id'=>$id);
			
			$data=array(
					    'name'=>$this->input->post('sname'),
					    'address'=>$this->input->post('address'),
					    'telno'=>$this->input->post('telr'),
					    
					    'mobile'=>$this->input->post('mobile'),
					    'email'=>$this->input->post('semail'),
					    
					    
					    'modified_on'=>$today);
						$this->db->where($arr);
			$this->db->update('tbl_servicereg',$data);
			
			
			
			
			
			 $brandname=$this->input->post('bname');
			$model=$this->input->post('model');
					  $engno=$this->input->post('engineno');
					    
					  $chaiseno =$this->input->post('chaiseno');
					    $regno=$this->input->post('regno');
						 $vid=$this->input->post('vid');
						 $insurancedudate =$this->input->post('insurancedudate');
					    $motorvehicletest=$this->input->post('motorvehicletest');
						$pollutiontest=$this->input->post('pollutiontest');
						$color=$this->input->post('color');
			$c1=count($brandname);
			for($j=0;$j<$c1;$j++)
			{
			
			$arr=array('tbl_vehicledetails.servicereg_id'=>$id,'tbl_vehicledetails.vehicleid'=>$vid[$j]);
			
			$datas=array(
					   'brandname'=>decode($brandname[$j]),
					     'model'=>decode($model[$j]),
					    'engineno'=>$engno[$j],
					    
					    'chaiseno'=>$chaiseno[$j],
					    'regno'=>$regno[$j],
						'color'=>$color[$j],
					    
					    'insurancedudate'=>$insurancedudate[$j],
					    'motorvehicletest'=>$motorvehicletest[$j],
						'pollutiontest'=>$pollutiontest[$j],
					    'modified_on'=>$today);
			$this->db->where($arr);
			
			$this->db->update('tbl_vehicledetails',$datas);
			}
		echo 22;
			}
		public function insert()
		{
		    $max=maxplus('tbl_services_details','s_id');	
		    $today=date('Y-m-d');
			
			if($this->session->userdata('org_id')=='')
			{
				$orgid='admin';
			}
			else
			{
				$orgid=$this->session->userdata('org_id');
			}
			$date=date('YmdHis');
			$service='SER#'.$max.$orgid.$date;
			$data=array('s_id' =>$max,
					    'org_id'=>$orgid,
					    'c_name'=>$this->input->post('sname'),
					    'c_address'=>$this->input->post('address'),
					    'tele_o'=>$this->input->post('telo'),
					    'tele_r'=>$this->input->post('telr'),
					    'mob'=>$this->input->post('mobile'),
					    'mail'=>$this->input->post('semail'),
					    's_details'=>$this->input->post('servicedet'),
					    's_feedback'=>$this->input->post('feedback'),
					    'time_in'=>$this->input->post('timein'),
					    'team'=>$this->input->post('team'),
					    'delivary_date'=>$this->input->post('delivarydate'),
					    'delivary_time'=>$this->input->post('deltime'),
					    'amt'=>$this->input->post('amt'),
						'service_id'=>$service,
					    'created_date'=>$today,
					    'modified_date'=>$today);
			$this->db->insert('tbl_services_details',$data);	
			
			$am_title=$this->input->post('amtitle');
			$am_label=$this->input->post('amlabel');
			$c=count($am_title);
			
			for($i=0;$i<$c;$i++)
			{
				$data1=array('se_id' =>$max,
							 'org_id' =>$orgid,
							 'am_label' =>$am_label[$i],
							 'am_det' =>$am_title[$i],
							 'created_date'=>$today,
							 'modified_date'=>$today);
				$this->db->insert('tbl_services_amenity',$data1);	
			}
			
			$item_title=$this->input->post('itemtitle');
			$item_label=$this->input->post('itemlabel');
			$c1=count($item_title);
			
			for($j=0;$j<$c1;$j++)
			{
				$data2= array('ser_id' =>$max,
							  'org_id' =>$orgid,
							  'item_label' =>$item_label[$j],
							  'item_det' =>$item_title[$j],
							  'created_date'=>$today,
							  'modified_date'=>$today);
				$this->db->insert('tbl_services_item',$data2);	
			}			
			
			$hdate=$this->input->post('historydate');
			$hdesc=$this->input->post('historydes');
			$c2=count($hdate);
			
			for($k=0;$k<$c2;$k++)
			{
				$data3= array('serv_id' =>$max,
							  'org_id' =>$orgid,
							  'history_date' =>$hdate[$k],
							  'history_desc' =>$hdesc[$k],
							  'created_date'=>$today,
							  'modified_date'=>$today);
				$this->db->insert('tbl_services_history',$data3);	
			}
			
			$checkjob=$this->input->post('itemjobs');
			
			$c3=count($checkjob);
			
			for($k=0;$k<$c3;$k++)
			{
				$data3= array('servjob_id' =>$max,
							  'org_id' =>$orgid,
							  'ser_job' =>$checkjob[$k],
							  'created_date'=>$today,
							  'modified_date'=>$today);
				$this->db->insert('tbl_services_job',$data3);	
			}
			echo encode($max);
		}
		
		
		
		public function getsms()
		{
			//$array=array('servicereg_id'=>$id);
			//$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_sms')->result();
		}
		public function getsms1($id)
		{
			$id=decode($id);
			$array=array('sid'=>$id);
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_sms')->row();
		}
		public function insertsms()
		{
		    $max=maxplus('tbl_sms','sid');	
		    $today=date('Y-m-d');
			
			if($this->session->userdata('org_id')=='')
			{
				$orgid='admin';
			}
			else
			{
				$orgid=$this->session->userdata('org_id');
			}
			$settings=$this->input->post('settings');
			$from=$this->input->post('from');
			$to=$this->input->post('to');
			$c3=count($to);
			
			for($k=0;$k<$c3;$k++)
			{
			$data1=array('sid' =>$max,
							 'org_id' =>$orgid,
							 'category' =>$settings[$k],
							 's_range' =>$from[$k],
							 'e_range'=>$to[$k],
							 'created_on'=>$today,
							 'modified_on'=>$today);
				$this->db->insert('tbl_sms',$data1);
			}
		}
		
		
		public function updatesms($id)
		{
		    //$max=maxplus('tbl_sms','sid');	
		    $today=date('Y-m-d');
			$id=decode($id);
			$arr=array('sid'=>$id);
			$settings=$this->input->post('settings');
			$from=$this->input->post('from');
			$to=$this->input->post('to');
			var_dump($to);
			$data1=array(
							
							 'category' =>$settings,
							 's_range' =>$from,
							 'e_range'=>$to,
							
							 'modified_on'=>$today);
							 $this->db->where($arr);
				$this->db->update('tbl_sms',$data1);
			
		}
		
		public function editservice($mid)
		{ 
		    $id=$mid;
			$array=array('status'=>0,'s_id'=>$id);
			$this->db->where($array);
			$this->db->select('*');
       		$result=$this->db->get('tbl_services_details');
       		return $rows=$result->row();
		}
		
		
		public function update()
		{
		    $max=decode($this->input->post('hdid'));	
		    $today=date('Y-m-d');
			$orgid=$this->session->userdata('org_id');
			
			$data=array('org_id'=>$this->session->userdata('org_id'),
			  			'c_name'=>$this->input->post('sname'),
			   			'c_address'=>$this->input->post('address'),
			   			'tele_o'=>$this->input->post('telo'),
			   			'tele_r'=>$this->input->post('telr'),
			   			'mob'=>$this->input->post('mobile'),
			  			'mail'=>$this->input->post('semail'),
			  			's_details'=>$this->input->post('servicedet'),
			  			's_feedback'=>$this->input->post('feedback'),
			 		 	'time_in'=>$this->input->post('timein'),
			  			'team'=>$this->input->post('team'),
			  			'delivary_date'=>$this->input->post('delivarydate'),
			  			'delivary_time'=>$this->input->post('deltime'),
			  			'amt'=>$this->input->post('amt'),
				 		'modified_date'=>$today);
			    $this->db->where('s_id',$max);
				$this->db->update('tbl_services_details',$data);	
				
			$del1=array('se_id'=>$max);
			$this->db->where($del1);
			$this->db->delete('tbl_services_amenity');
			
			$am_title=$this->input->post('amtitle');
			$am_label=$this->input->post('amlabel');
			$c=count($am_title);
			
			for($i=0;$i<$c;$i++)
			{
				$data1= array('se_id' =>$max,
							  'org_id' =>$orgid,
							  'am_label' =>$am_label[$i],
							  'am_det' =>$am_title[$i],
							  'created_date'=>$today,
							  'modified_date'=>$today);
				$this->db->insert('tbl_services_amenity',$data1);	
			}
			
			$del2=array('ser_id'=>$max);
			$this->db->where($del2);
			$this->db->delete('tbl_services_item');
			
			
			$item_title=$this->input->post('itemtitle');
			$item_label=$this->input->post('itemlabel');
			$c1=count($item_title);
			
			for($j=0;$j<$c1;$j++)
			{
				$data2= array('ser_id' =>$max,
							  'org_id' =>$orgid,
							  'item_label' =>$item_label[$j],
							  'item_det' =>$item_title[$j],
							  'created_date'=>$today,
							  'modified_date'=>$today);
				$this->db->insert('tbl_services_item',$data2);	
			}
			
			$del3=array('serv_id'=>$max);
			$this->db->where($del3);
			$this->db->delete('tbl_services_history');
			
			
			$hdate=$this->input->post('historydate');
			$hdesc=$this->input->post('historydes');
			$c2=count($hdate);
			
			for($k=0;$k<$c2;$k++)
			{
				$data3= array('serv_id' =>$max,
							  'org_id' =>$orgid,
							  'history_date' =>$hdate[$k],
							  'history_desc' =>$hdesc[$k],
							  'created_date'=>$today,
							  'modified_date'=>$today);
				$this->db->insert('tbl_services_history',$data3);	
			}
			
			$del4=array('servjob_id'=>$max);
			$this->db->where($del4);
			$this->db->delete('tbl_services_job');
			
			$checkjob=$this->input->post('itemjobs');
			$c3=count($checkjob);
			
			for($k=0;$k<$c3;$k++)
			{
				$data3= array('servjob_id' =>$max,
							  'org_id' =>$orgid,
							  'ser_job' =>$checkjob[$k],
							  'created_date'=>$today,
							  'modified_date'=>$today);
				$this->db->insert('tbl_services_job',$data3);	
			}
		}		
		//////////////////////////////////////////////////////////////
	public function deletedri()
	    {
		    $cid=$this->input->post('id');
		    $max=decode($cid);
		    $del0=array('did'=>$max);
		    $this->db->where($del0);
			$this->db->delete('tbl_driverdetails');
		}
		public function deletesms()
	    {
		    $cid=$this->input->post('id');
		    $max=decode($cid);
		    $del0=array('sid'=>$max);
		    $this->db->where($del0);
			$this->db->delete('tbl_sms');
		}
		public function delete()
	    {
		    $cid=$this->input->post('id');
		    $max=decode($cid);
		    $del0=array('s_id'=>$max);
		    $this->db->where($del0);
			$this->db->delete('tbl_services_details');
		 
		    $del1=array('se_id'=>$max);
			$this->db->where($del1);
			$this->db->delete('tbl_services_amenity');
			
			$del2=array('ser_id'=>$max);
			$this->db->where($del2);
			$this->db->delete('tbl_services_item');
			
			$del3=array('serv_id'=>$max);
			$this->db->where($del3);
			$this->db->delete('tbl_services_history');
			
			$del4=array('servjob_id'=>$max);
			$this->db->where($del4);
			$this->db->delete('tbl_services_job');
			
		}		
		///////////////////////////////////////////////////////////////
		
			public function deletereg()
	    {
			 $cid=$this->input->post('id');
			  $max=decode($cid);
		    $del0=array('servicereg_id'=>$max);
		    $this->db->where($del0);
			$this->db->delete('tbl_servicereg');
			$del0=array('servicereg_id'=>$max);
		    $this->db->where($del0);
			$this->db->delete('tbl_vehicledetails');
		}
public function getorgname()
{
	
	
	
		$array=array('o_maxid'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('org_name');
			 $rows=$this->db->get('tbl_organisation')->row();
			return $res=$rows->org_name;
			
}
	
		
public function generatepdf($id)
{
	
	
	
require('./pdf/fpdf.php');

$header = array('Room Type', 'No. of rooms', 'No. of children', 'No. of adults','Amount');
$data=array();
$pdf = new FPDF('P','mm','A4');
$pdf->AddPage();
$u_name=$this->getorgname(); 
$title=$this->getamenity();
 if($this->session->userdata('org_id'))
				{
				$iconz1=getmyicon($this->session->userdata('org_id'));
				}  
				else{$iconz1='assets/admin/images/logo/materialize-logos.png';
				}
				
$pdf->SetFont('Arial','',12);
  
// $pdf->Cell(array_sum($w),0,'','T');
$pdf->Image(SITE_PATH.$iconz1,75,13,40,10,'PNG');
$pdf->Ln(5);
$book_details=$this->editservice($id);
$book_details_full=$this->getbikedetails($id);
 $fill = false;
$pdf->Cell(0,25,$u_name ,0,0,'C');
$pdf->Line(0,30,210,30);
$date=date('Y-m-d');
$pdf->Cell(330,36,'Date : '.$date,'0',1,'C');
$pdf->SetTextColor(194,8,8);
//$pdf->Title('Service Id');
/*$pdf->SetFontSize(16);
$pdf->Text('150', '10', 'Service Id');
$pdf->SetFont('Arial','',11);
$pdf->SetTextColor(0,0,0);*/
$pdf->SetFontSize(10);
	$pdf->Cell(0,-47, 'Service Id : '.$book_details->service_id ,0,0,'R');


//$pdf->Cell(200,10,'Title',1,1,'C');

$pdf->SetTextColor(194,8,8);
//$pdf->Title('Service Id');
$pdf->SetFontSize(14);
$pdf->Text('10', '50', 'Customer Details');
$pdf->SetFont('Arial','',11);
$pdf->SetTextColor(0,0,0);


/*$pdf->SetFont('Arial','',9);
$pdf->Cell(0,7,'Name : '.$book_details->c_name,0,0,'L');
$pdf->Cell(0,7,'Mobile Phone : '.$book_details->mob,0,0,'R');
$pdf->Ln();
$pdf->Cell(0,7,'Address : '.$book_details->c_address,0,0,'L');
$pdf->Cell(0,7,'Email : '.$book_details->mail,0,0,'R');
$pdf->Ln();
$pdf->Cell(0,8,'Checkin Date : '.$book_details->service_id,0,0,'L');*/
//$pdf->Cell(0,8,'Checkout Date : '.$book_details->Item_title,0,0,'R');

// $pdf->Cell(0,10,'Center text:',0,0,'C');
// $pdf->Cell( 0, 10, 'Right text', 0, 0, 'R' ); 
/*
*/$pdf->Ln(1);

   $pdf->SetFillColor(178, 6, 8);
    $pdf->SetTextColor(255);
    $pdf->SetDrawColor(221, 221, 221);
    $pdf->SetLineWidth(.3);
    //$pdf->SetFont('','B');
    // Header
    $w = array(48, 96, 40, 45,30);
    /*for($i=0;$i<count($header);$i++)
        $pdf->Cell($w[$i],8,$header[$i],1,0,'C',true);
    $pdf->Ln();*/
    // Color and font restoration
    $pdf->SetFillColor(255, 243, 243);
    $pdf->SetTextColor(0);
    $pdf->SetFont('Arial','',9);
    // Data
    $fill = false;
    /*foreach($book_details_full as $row)
    {*/
	//$pdf->Cell(0,7,'Name : '.$book_details->c_name ,0,0,'L',$fill);
	//$pdf->Line(0,30,210,30);
	
        $pdf->Cell($w[0],8,'Name ','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$book_details->c_name,'LRTB',0,'L',$fill);
		 $pdf->Cell($w[0],8,'Address ','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$book_details->c_address,'LRTB',0,'L',$fill);
		$pdf->Ln();
		$pdf->Cell($w[0],8,'Telephone (Office)','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$book_details->tele_o,'LRTB',0,'L',$fill);
		 $pdf->Cell($w[0],8,'Telephone (residency) ','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$book_details->tele_r,'LRTB',0,'L',$fill);
		$pdf->Ln();
		$pdf->Cell($w[0],8,'Mobile ','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$book_details->mob,'LRTB',0,'L',$fill);
		 $pdf->Cell($w[0],8,'Email','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$book_details->mail,'LRTB',0,'L',$fill);
		$pdf->Ln();
		//$pdf->Line(10,52,200,52);
		//next heading
		$pdf->SetTextColor(194,8,8);
//$pdf->Title('Service Id');
//$pdf->Ln(-14);
$titles=$title->amenity_title;
$pdf->SetFontSize(14);
$pdf->Text('10', '85', $titles);
$pdf->SetFont('Arial','',11);

$pdf->SetTextColor(0,0,0);

$bikes=$this->getbikedetails($id);
	$pdf->Ln(12);
 foreach($bikes as $row)
    {
		
		 $pdf->Cell($w[1],8,$row->am_label,'LRTB',0,'L',$fill);
        $pdf->Cell($w[1],8,$row->am_det,'LRTB',0,'L',$fill);
		
		$pdf->Ln();
	}
	
		////
		//////
		$pdf->SetTextColor(194,8,8);
//$pdf->Title('Service Id');
$pdf->SetFontSize(14);
$pdf->Text('10', '120', 'Service Details');
$pdf->SetFont('Arial','',11);
$pdf->SetTextColor(0,0,0);
$pdf->Ln(12);
 $pdf->Cell($w[0],8,'Details ','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$book_details->s_details,'LRTB',0,'L',$fill);
		 $pdf->Cell($w[0],8,'Feedback ','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$book_details->s_feedback,'LRTB',0,'L',$fill);
		$pdf->Ln();
///////////////
//////////////
$pdf->SetTextColor(194,8,8);
$Item_title=$title->Item_title;
$pdf->SetFontSize(14);
$pdf->Text('10', '140', $Item_title);
$pdf->SetFont('Arial','',11);

$pdf->SetTextColor(0,0,0);

$bikeaccess=$this->getbikeaccess($id);

	$pdf->Ln(12);
	$count=count($bikeaccess);
 foreach($bikeaccess as $row)
    {
		
		$pdf->Cell($w[1],8,$row->item_label,'LRTB',0,'L',$fill);
        $pdf->Cell($w[1],8,$row->item_det,'LRTB',0,'L',$fill);
			
		$pdf->Ln();
	}
////////////

//////////////
$pdf->SetTextColor(194,8,8);
$pdf->SetFontSize(14);
$pdf->Text('10', '180', 'Jobs');
$pdf->SetFont('Arial','',11);

$pdf->SetTextColor(0,0,0);

$serjobs=$this->getserjobs($id);
	$pdf->Ln(14);
 foreach($serjobs as $row)
    {
		
		 $pdf->Cell($w[1],8,$row->titles,'LRTB',0,'L',$fill);
         
		
		$pdf->Ln();
	}
		$pdf->Ln(10);
////////////
//////////////	
//$pdf->Ln(28);
$pdf->SetTextColor(194,8,8);
$pdf->SetFontSize(14);
$pdf->Text('10', '210', 'Previous History');
$pdf->SetFont('Arial','',11);

$pdf->SetTextColor(0,0,0);

$hist=$this->gethistory($id);
	$pdf->Ln(9);
 foreach($hist as $row)
    {
		 $pdf->Cell($w[1],8,'Description ','LRTB',0,'L',$fill);
		 $pdf->Cell($w[1],8,$row->history_desc,'LRTB',0,'L',$fill);

		
		$pdf->Ln();
	}
////////////
$pdf->Ln(10);
	//next heading
		$pdf->SetTextColor(194,8,8);
//$pdf->Title('Service Id');
$pdf->Ln(10);
$pdf->SetFontSize(14);
$pdf->Text('10', '250', 'Job Schedule');
$pdf->SetFont('Arial','',11);

$pdf->SetTextColor(0,0,0);

$schedule=$this->getschedule($id);
	$pdf->Ln(15);
       $pdf->Cell($w[0],8,'Time in :  ','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$schedule->time_in,'LRTB',0,'L',$fill);
		 $pdf->Cell($w[0],8,'Team ','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$schedule->team,'LRTB',0,'L',$fill);
			$pdf->Ln();
		 $pdf->Cell($w[0],8,'Delivery date ','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$schedule->delivary_date,'LRTB',0,'L',$fill);
		 $pdf->Cell($w[0],8,'Delivary time ','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$schedule->delivary_time,'LRTB',0,'L',$fill);
		$pdf->Ln();
			 $pdf->Cell($w[0],8,'Estimated Amount','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,$schedule->amt,'LRTB',0,'L',$fill);
		 $pdf->Cell($w[0],8,'','LRTB',0,'L',$fill);
        $pdf->Cell($w[0],8,'','LRTB',0,'L',$fill);
	
		////

        $pdf->Ln();
        $fill = !$fill;
		
    //}
 


$pdf->Output();
}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
}