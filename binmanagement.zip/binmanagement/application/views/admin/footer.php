<!-- START FOOTER -->
    <footer class="page-footer">
   
      <footer class="page-footer">
        <div class="footer-copyright">
          <div class="container">
            <span>Copyright © <script type="text/javascript" language="javascript">document.write(new Date().getFullYear()); </script>  
               <a class="grey-text text-lighten-4">Bin Management - A basic smart Digital Manager</a> All rights reserved.</span>
            <span class="right hide-on-small-only">Design and Developed by 
            <a class="grey-text text-lighten-4" href="#">Haran</a>
            </span>
          </div>
        </div>
      </footer>
    </footer>
    <!-- END FOOTER -->
    <!-- ================================================
    Scripts
    ================================================ -->
    <!-- jQuery -->
     <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>js/custom-script.js"></script>
    <!--materialize js-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>js/materialize.min.js"></script>
    <!--prism-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>vendors/prism/prism.js"></script>
    <!--scrollbar-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <!-- data-tables -->
<!--    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>vendors/data-tables/js/jquery.dataTables.min.js"></script>
-->    <!--data-tables.js - Page Specific JS codes -->
<!--    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>js/scripts/data-tables.js"></script>
-->     <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>vendors/sweetalert/dist/sweetalert2.min.js"></script>

    <!--extra-components-sweetalert.js - Some Specific JS-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>js/scripts/extra-components-sweetalert.js"></script>
    <!--plugins.js - Some Specific JS codes for Plugin Settings-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>js/plugins.js"></script>
    <!--custom-script.js - Add your own theme custom JS-->
     <script src="<?php echo ADMIN_STYLEPATH; ?>vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo ADMIN_STYLEPATH; ?>vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo ADMIN_STYLEPATH; ?>vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo ADMIN_STYLEPATH; ?>vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo ADMIN_STYLEPATH; ?>vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo ADMIN_STYLEPATH; ?>vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo ADMIN_STYLEPATH; ?>vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo ADMIN_STYLEPATH; ?>vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo ADMIN_STYLEPATH; ?>vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo ADMIN_STYLEPATH; ?>vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo ADMIN_STYLEPATH; ?>vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo ADMIN_STYLEPATH; ?>vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
   <script src="<?php echo ADMIN_STYLEPATH; ?>vendors/pdfmake/build/pdfmake.min.js"></script>
  
    <script src="<?php echo ADMIN_STYLEPATH; ?>vendors/pdfmake/build/pdfmake.js"></script>
    <script src="<?php echo ADMIN_STYLEPATH; ?>vendors/pdfmake/build/vfs_fonts.js"></script>
     
    <script>
	$(document).ready(function(e) {
 
    var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable( { pageLength: 10,
        dom: 'Bfrtip',
        buttons: ['csv', 'excel', 'pdf', 'print'],
        responsive: true} );
		$('#datatablesub').dataTable( { pageLength: 10,
        dom: 'Bfrtip',
        buttons: ['csv', 'excel', 'pdf', 'print',{
                text: 'All',
				className:'btnall'
            }],
        responsive: true} );

        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        var $datatable = $('#datatable-checkbox');

        $datatable.dataTable({
          'order': [[ 1, 'asc' ]],
          'columnDefs': [
            { orderable: false, targets: [0] }
          ]
        });
        $datatable.on('draw.dt', function() {
          $('input').iCheck({
            checkboxClass: 'icheckbox_flat-green'
          });
        });

        TableManageButtons.init();
      });
    </script>
  </body>

</html>