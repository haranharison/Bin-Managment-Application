<?php
class Subcategory_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	
	public function getcategory()
	{
	$oid=$this->session->userdata('org_id');
			$array=array('status'=>0,'org_id'=>$oid);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_category')->result();

	}
	
	public function getsubcategory()
	{
		$oid=	$this->session->userdata('org_id');
		$array=array('tbl_subcategory.status' =>0,'tbl_subcategory.org_id'=>$oid);
		$this->db->where($array);
		$this->db->group_by('subcategory_id');
		$this->db->select('tbl_category.cat_name,tbl_category.category_id,tbl_subcategory.*');
		$this->db->from('tbl_subcategory');
		$this->db->join('tbl_category as tbl_category', 'tbl_category.category_id=tbl_subcategory.cat_id');
		return $rows=$this->db->get()->result();
	}
	
	
	
	public function addsubcategory()
	{
			$exist=fieldexist('tbl_subcategory','subcat_name',$this->input->post('txtsubcategory'),'org_id',$this->session->userdata('org_id'));
	if($exist==1){
		echo 1;
	}else{
		$max=maxplus('tbl_subcategory','subcategory_id');
		$today= date("y-m-d");
		$subcategory=$this->input->post('txtsubcategory');
		$orgid=$this->session->userdata('org_id');
		$category=decode($this->input->post('selcat'));
		$data= array(
			 'subcategory_id'=>$max,
			 'org_id'=>$orgid,
		      'subcat_name'=>$subcategory,
			   'cat_id'=>$category,
			   'create_date'=>$today,
			   'modify_date'=>$today
		);
		$this->db->insert('tbl_subcategory',$data);
		}
		
	}
        
		public function editcategory($id){
			$cid=$id;
				$array=array('subcategory_id'=>$cid,'status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_subcategory')->row();
			}
			
			public function updatesubcategory()
			{
				$cid=decode($this->input->post('txthiden'));
				$today= date("y-m-d");
		$subcategory=$this->input->post('txtsubcategory');
			$category=$this->input->post('selcat');
				   $data=array(
				   'subcat_name'=>$subcategory,
			   'cat_id'=>$category,
			   'create_date'=>$today,
			   'modify_date'=>$today
				   
				   
				   );
		   $array= array('subcategory_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_subcategory',$data);
			}
			
			 public function deletesubategories(){
		 	$cid=	decode($this->input->post('id'));
		   $data=array('status'=>1);
		   $array= array('subcategory_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_subcategory',$data);
		   }	
//New 
	public function getexistsubcategoriey(){
		$cid=decode($this->input->post('catid'));	
		$oid=	$this->session->userdata('org_id');
			$array=array('status'=>0);
		$array=array('cat_id'=>$cid,'status'=>0,'org_id'=>$oid);
		$this->db->where($array);
		$this->db->select('subcat_name,subcategory_id');//ptax_propery,ptax_u_id
		$result=$this->db->get('tbl_subcategory');
		$rows=$result->result();
		$html='';
		$i=1;
				if($result->num_rows() > 0)
				{
					//$html='<span style="display:block;color:#6495ed;padding-left: 5px;font-size: 12px;letter-spacing: 0.5px;user-select: none;cursor: default;">Already Added</span>';
					foreach($rows as $val =>$key){
							//$html.='<tr><td>'.$i.'</td><td>'.($key->subcat_name).'</td><tr>';
							
								$html.='<tr><td style="width:10% !important;text-align:center;">' .$i .'</td>
								<td style="width:100% !important;text-align:left;" >'.($key->subcat_name).'</td>
								<td style="width:20% !important;"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="'.ADMIN_PATH.'subcategory/editsubcategories/'.encode($key->subcategory_id).'">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange btndlt" rel="'.encode($key->subcategory_id).'" >
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>';
							$i=$i+1;
					}
					
					
					$html .="<script> $('#datatablesub').dataTable( { pageLength: 10,
        dom: 'Bfrtip',
        buttons: ['csv', 'excel', 'pdf', 'print',{
                text: 'All',
				className:'btnall'
            }],
        responsive: true} );</script>";
					
				}
				echo $html;	
	}
	
	public function getallsubcategoriey(){
		$oid=$this->session->userdata('org_id');
			$array=array('status'=>0);
		$array=array('status'=>0,'org_id'=>$oid);
		$this->db->where($array);
		$this->db->select('subcat_name,subcategory_id');//ptax_propery,ptax_u_id
		$result=$this->db->get('tbl_subcategory');
		$rows=$result->result();
		$html='';
		$i=1;
				if($result->num_rows() > 0)
				{
					//$html='<span style="display:block;color:#6495ed;padding-left: 5px;font-size: 12px;letter-spacing: 0.5px;user-select: none;cursor: default;">Already Added</span>';
					foreach($rows as $val =>$key){
							//$html.='<tr><td>'.$i.'</td><td>'.($key->subcat_name).'</td><tr>';
							
								$html.='<tr><td style="width:10% !important;text-align:center;">' .$i .'</td>
								<td style="width:100% !important;text-align:left;" >'.($key->subcat_name).'</td>
								<td style="width:20% !important;"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="'.ADMIN_PATH.'subcategory/editsubcategories/'.encode($key->subcategory_id).'">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange btndlt" rel="'.encode($key->subcategory_id).'" >
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>';
							$i=$i+1;
					}
					
					
					$html .="<script> $('#datatablesub').dataTable( { pageLength: 10,
        dom: 'Bfrtip',
        buttons: ['csv', 'excel', 'pdf', 'print',{
                text: 'All',
				className:'btnall'
            }],
        responsive: true} );</script>";
					
				}
				echo $html;	
	}	
		
		
}