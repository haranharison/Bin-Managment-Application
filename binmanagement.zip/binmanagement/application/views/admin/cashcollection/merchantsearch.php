 <!--breadcrumbs start-->
 <style>
 .viewcash{
	display:none; 
 }
 .viewcheque{
	 display:none;
 }
 
 </style>
 <div class="content" style="min-height:490px;">
          
          <!--breadcrumbs end-->

<!--start container-->
          <div class="container hidecash">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row" >
                <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Search Merchant</h4>
                      <div class="row">
                       <form role="form" name="frmsermerchant" id="frmsermerchant" method="post" action="">
                       
                         <div class="row">
                            <div class="input-field col s12">
                              <input placeholder="Enter Merchant Number" name="mer_num" id="mer_num"  type="text">
                              <label for="first_name"> Merchant Number</label>
                            </div>
                          </div>
                       
                       
                          <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnsubmit" style="margin-right:9px;">Search
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  <div class="col s12 m12 l6 " id="vwdetails">
                  
                  </div>
                  </div>
                 <!-- Form with placeholder -->
                  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
           
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
          
          
          <div class="container viewcash"  >
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m12 l12">
                <div class="card-panel">
                  <div class="row">
                   <form role="form" name="frmcash" id="frmcash">
                      <div class="row">
                        <div class="input-field col s6">
                        <input type="hidden" name="mid"  id="mid"value="" /> 
                     <input  type="text" placeholder="Credits" id="credits" name="credits" readonly >
                          <label for="first_name">Credits</label>
                        </div>
                        <div class="input-field col s6">
                          	<input  type="text" placeholder="Amount Received" id="amount" name="amount" >
                          <label for="first_name">amount</label>
                        </div>
                        <div class="input-field col s6">
                          	<input  type="text"   name="balance" id="balance"  placeholder="Balance" readonly >
                          <label for="first_name">Balance</label>
                        </div>
                        <div class="input-field col s6">
                       <select name="method" id="method">
                       <option value="0"> Select Payment Method</option>
                        <option value="1"> Cash</option>
                         <option value="2"> Cheque</option>
                       </select>
                        </div>
                      
                        <div class="viewcheque">
                        <div class="input-field col s4">
                          	<input  type="text" placeholder="Check  No" name="check" id="check" >
                          <label for="first_name">Check</label>
                        </div>
                        <div class="input-field col s4">
                        <input  type="text" placeholder="Bank" name="bank" id="bank" >
                          <label for="first_name">Bank</label>
                          	 <!--<select name="bank" id="bank">
                       <option value="0"> Select Bank</option>
                       <?php // if($bank ) { foreach($bank as $val) { ?>
                        <option value="<?php //echo $val->b_uid ;?>"><?php // echo $val->b_bname;?></option>
                        
                     <?php // } }?>
                       </select>-->
                        </div>
                         <div class="input-field col s4">
                          	<input type="text" class="datepicker" id="datepicker" name="cdate">
                          <label for="first_name" > Date</label>
                        </div>
                        </div>
                        </div>
                         
                               
                     <div class="row">
                        <div class="row">
                          <div class="input-field col s12">
                           <a  class="btn cyan waves-effect waves-light right" id="btnupdate" style="float:right:">Submit</a>
                              <a href="" id="btncancel" class="btn cyan waves-effect waves-light right" style="float:left;">Cancel</a>
                           <!-- <button class="btn cyan waves-effect waves-light right"  id="btnnsubmit" type="submit" name="action">Submit
                              <i class="material-icons right">send</i>-->
                            </button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        </div>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->


<script type="text/javascript">

function placeorder(){
	
	document.getElementsByClassName('hidecash')[0].style.display="none";
	  document.getElementsByClassName('viewcash')[0].style.display="block";
	document.getElementById('credits').value=document.getElementById('merchantid').value;
}
$(document).ready(function(e) {
	
	$('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15, // Creates a dropdown of 15 years to control year,
    today: 'Today',
    clear: 'Clear',
    close: 'Ok',
    closeOnSelect: false, // Close upon selecting a date,
	format: 'yyyy-mm-dd',
    container: undefined // ex. 'body' will append picker to body
  });
   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			 
			 
			  var e=validation1();
			  
			if(e==0){
				$('.overlay').css({'display':'flex'});
 			var url="<?php echo ADMIN_PATH?>Cash/merchantsearch";
  		
  			var form = document.forms.namedItem("frmsermerchant");                        
			var oData = new FormData(document.forms.namedItem("frmsermerchant"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
					$('.overlay').css({'display':'none'});
					
					
					 if(oReq.responseText==1){
				customSwalFunD("Alert!", "Merchant not found", "success")
					}
					
				else if(oReq.responseText==2){
					
					 customSwalFunD("Alert!", "Merchant has no credit", "success")
				}
				else {
				$('#vwdetails').html(oReq.responseText);
				}
				/* if(oReq.responseText==1){
					  customSwalFunD("Error","Already Exist");
						//swal("Alreadt Exist!", "Exist!", "error");
					 }
					 else
					 {
						 document.location = redirect;
						   customSwalFunD("Sucess","Succesfully Added");
						// swal("Succesfully Added!", "Sucess!", "sucess")
 					
					 }*/}
                oReq.send(oData);
			}
               // ev.preventDefault();   
   			});
			
			
			function validation1(){

        error=0;

        $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');
			
			 var values = {
                                   
									 'mechantno':$('#mer_num').val(),
			 }
			  if(values.mechantno == ''){
            $('#mer_num').addClass('errors');
            $('#mer_num').attr("placeholder", "Please enter merchant number.")
		  $('#mer_num').parent().children('label').addClass('labelerror');
            error=1;
        } 
		return error;
	}

				 $("#btnupdate").click(function(e) {
					 
					 if($('#balance').val()>=0){
					 var e=validation();
			if(e==0){
				 $('.overlay').css({'display':'flex'});
 			var url="<?php echo ADMIN_PATH?>Cash/insertcash";
  			var redirect = "<?php echo ADMIN_PATH?>Cash";
  			var form = document.forms.namedItem("frmcash");                        
			var oData = new FormData(document.forms.namedItem("frmcash"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { 
				 $('.overlay').css({'display':'none'});
				//alert(oReq.responseText);
				
				swal("Succesfully Added!", "Sucess!", "sucess")
				 document.location = redirect;
					}	
                oReq.send(oData);
			}
		}
		else{
			swal("Error", "Entered amount greater than credit amount", "sucess")
			
			}
			function validation(){

        error=0;

        $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');
		
		   var values = {
                                   																													
									 'amount':$('#amount').val(),
									  'method':$('#method').val(),
  								     'check':$('#check').val(),
									 'bank':$('#bank').val(),
									 'datepicker':$('#datepicker').val(),
									 'balance':$('#balance').val(),
									 }
		  if(values.amount == ''){
            $('#amount').addClass('errors');
            $('#amount').attr("placeholder", "Please enter amount.")
		  $('#amount').parent().children('label').addClass('labelerror');
            error=1;
        } 
		  if(values.method == 0){
           // $('#method').addClass('errors');
          $('#method').parent().parent().children('label').addClass('labelerror');
		  $('#method').parent().children('.select-dropdown').addClass('errors');
            error=1;
        } 
		if($('#method').val()==2){
		  if(values.check == ''){
            $('#check').addClass('errors');
            $('#check').attr("placeholder", "Please enter check  number.")
		  $('#check').parent().children('label').addClass('labelerror');
            error=1;
        } 
		  if(values.bank ==''){
             $('#bank').parent().parent().children('label').addClass('labelerror');
		  $('#bank').parent().children('.select-dropdown').addClass('errors');
            error=1;
        } 
		  if(values.datepicker == ''){
            $('#datepicker').addClass('errors');
            $('#datepicker').attr("placeholder", "Please select date.")
		  //$('#datepicker').parent().children('label').addClass('labelerror');
            error=1;
        }
		}
		if(values.balance == ''){
            $('#balance').addClass('errors');
            $('#balance').attr("placeholder", "Please find balance.")
		  $('#balance').parent().children('label').addClass('labelerror');
            error=1;
        }  
		 return error;
			}

   			});
			
			$('#method').change(function(){
			if($('#method').val()==2){
				$('.viewcheque').css({'display':'block'});
			}
			else{
			$('.viewcheque').css({'display':'none'});	
			}
				
			});
			
			$('#amount').keyup(function(){
			var a=$('#credits').val();
			var b=$('#amount').val();
			$('#balance').val(parseInt(a)-parseInt(b));
            });
			});
	//----end insert--------------------//	

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmsubcat').each (function(){  
                    this.reset();
               }); 	
        });
		
	//---------End cancel------//	
	
	
	
	

		 		  
</script>










