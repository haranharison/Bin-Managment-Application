

 <!--breadcrumbs start-->
          <div id="breadcrumbs-wrapper">
            <!-- Search for small screen -->
            <div class="header-search-wrapper grey lighten-2 hide-on-large-only">
              <input type="text" name="Search" class="header-search-input z-depth-2" placeholder="Explore Materialize">
            </div>
            <div class="container">
              <div class="row">
                <div class="col s10 m6 l6">
                  <h5 class="breadcrumbs-title">Product</h5>
                  <ol class="breadcrumbs">
                    <li><a href="<?php echo ADMIN_PATH?>index/home">Dashboard</a>
                    </li>
                    <li><a href="#">Product Edit</a>
                    </li>
                  </ol>
                </div>
                
              </div>
            </div>
          </div>
          <!--breadcrumbs end-->

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m12 l12">
                <div class="card-panel">
                  <div class="row">
                  <style>
				  .addDynamicfield{
						    position: absolute;
							top: 10px;
							right: -52px;
							color: #0092d3;
							cursor:pointer;
				  }
                  .addDynamicfield i{
					font-size: 35px;  
				  }
				  
                  </style>
                   <form role="form" aria-describedby="frmsubtaxproperty" name="frmsubtaxproperty" id="subtaxproperty">
                      <div class="row">
                        <div class="input-field col s6">
                          <select class="form-control form-control1" id="selcat" name="selcat">
                                    	<option value="0">Select Tax</option>
										<?php foreach($tax as $key){?>
													<option value="<?php echo encode($key->tax_id);?>"><?php echo $key->tax_name;?></option>	
                                                <?php }?>
									</select> 
                          <label for="first_name">Tax Names</label><a class="addDynamicfield"><i class="material-icons">add_circle</i></a>
                        </div>
                        <div class="input-field col s12">
                         
                        </div>
                      </div>
                      <div class="row">
                        <div class="input-field col s12">
                           <input type="hidden" name="txthidden" value="<?php  ?>" />
								<input  class="form-control "  value="<?php  ?>" id="txtproduct" name="txtproduct" type="text" >
                          <label for="email">Product Name</label>
                        </div>
                      </div>
                      
                      
                        <div class="row">
                          <div class="input-field col s12">
                            <button class="btn cyan waves-effect waves-light right" type="submit" name="action">Submit
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                        </div>
                    </form>
                  </div>
                </div>
              </div>
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

  
<script type="text/javascript">

$(document).ready(function(e) {
   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			//alert(1);
			var e=validation();
			if(e==0){
  			var url="<?php echo ADMIN_PATH?>category/addcategory";
  			var redirect = "<?php echo ADMIN_PATH?>category";
  			var form = document.forms.namedItem("frmncat");                        
			var oData = new FormData(document.forms.namedItem("frmncat"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
					
				 if(oReq.responseText==1){
					// alert("Exist");
					swal("Alreadt Exist!", "Exist!", "error")
					  //alert("Exist");
					 }
					 else
					 {
						 swal("Sucessfully!", "Sucessfully Added!", "success")
 					 document.location = redirect;
					 }
					
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');

        $('input').removeClass('errorInput');

        $('select').removeClass('errors');

        $('select').removeClass('errorInput');
        

            var values = {
                                    'category':$('#txtcategory').val(),

                                 }

        if(values.category == ''){
            $('#txtcategory').addClass('errors');
            $('#txtcategory').attr("placeholder", "Please enter category.")
			$('#txtcategory').css({'border':'1px solid red'});
		    $('#txtcategory').addClass('errorInput');
            error=1;
        } 
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmncat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
	
	
	
	// ---------- < Delete Category   > ---------- //
		    $(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
 swal({
                            title: "Are you sure?",
							   text: "Delete this Category",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          },
						   function(isConfirm) {
                              if (isConfirm) { 
			
			//	alert(id);
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>category/deleteCategories",
					//	 redirect : "<?php echo ADMIN_PATH?>category",

                                            data:"id="+id,

                                            success:function(data){ //alert(data);
												
											
                                               // $(".loader").remove();
location.reload() ;
                                 // 	document.location = redirect;
	swal("Sucessfully!", "Sucessfully Deleted!", "success")
                                            }

                                        });
					   }

				          });

		
			  
        });
		// ---------- < Delete Category ENDS > ----------
	
	
	
	
	
	
	
});
</script>


    
    
    
    
    
    
    
    
    

