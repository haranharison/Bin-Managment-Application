
  <style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
	float:right;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
.file-field .btn {
        float: right;
    position: relative;
}
.addDynamicfield,.removeDynamicfield{
						    position: absolute;
							top: 16px;
							right: -10px;
							padding:0px;
							color: #0092d3;
							cursor:pointer;
							opacity:0.7;
							transition:opacity 0.2s;
							  -webkit-touch-callout: none; /* iOS Safari */
							-webkit-user-select: none; /* Safari */
							 -khtml-user-select: none; /* Konqueror HTML */
							   -moz-user-select: none; /* Firefox */
								-ms-user-select: none; /* Internet Explorer/Edge */
									user-select: none; /* Non-prefixed version, currently
														  supported by Chrome and Opera */
				  }
				   .addDynamicfield:hover,.removeDynamicfield:hover{
					   opacity:1;
				   }
				  .removeDynamicfield{
						color:#F30;  
				  }
                  .addDynamicfield i,.removeDynamicfield i{
					font-size: 22px;  
				  }
				  .removeDynamicfield i.removing{
					  animation:spin 2s linear infinite;
				  }
</style>

 <style>
					  		.merchant-reg-image{
								text-align:center;width: 150px;height: 181px;margin: 0 auto;overflow: hidden;
							}
                      		.merchant-reg-image img{
								border:none;width: 150px;height: 150px;/*float: right;border-radius:50%*/		
							}
							.merchant-reg-image .file-field .btn{
								float:none;	
							}
							.merchant-reg-image .file-field.input-field{
								margin-top:0rem;
							}
							.merchant-reg-image .btn{
								border-radius: 0;height: 2.1rem;line-height: 1;padding: 0.5rem 1.2rem;width: 150px;font-size: 14px;font-weight: 600;
							}
							.vdetails{
							display:none;	
								}
                      </style>
<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m12 l6">
                <div class="card-panel">
                                      <h4 class="header2">Advertisement</h4>

                  <div class="row">
                  <form role="form" name="frmadv" id="frmadv"  method="post" enctype="multipart/form-data">
                      <div class="row">
                      <div class="input-field col m12 s12">
                              			<div class="merchant-reg-image">
                                        <img src="<?php echo SITE_PATH.$edit->adv_img ?>" id="imgfiles"/>
                                        <div class="file-field input-field">
                            <div class="btn">
                            <span>Photo</span>
                             <input type="hidden"  name="hidden" value="<?php echo encode($edit->adv_id) ?>" >
                            <input type="file" id="imgfile"  name="imgfile" >
                            </div>
                            <div class="file-path-wrapper" style="display:none;" >
                            <input class="file-path validate" type="text">
                            </div>
                            </div>
                                        </div>
                              </div>
                      
                      
                      
                      <div style="height:20px; clear:both;"></div>
                        <div class="input-field col s12 m6">
                        
                          	<input  type="text" placeholder="EnterTitle" id="title" name="title" value="<?php echo $edit->adv_title ?>" >
                            
                          <label for="first_name">Title</label>
                        </div>
                        
                        <div class="input-field col s12 m6">
                        
                          	<input  type="text" placeholder="Enter Website" id="wsite" name="wsite"  value="<?php echo $edit->adv_website ?>" >
                            
                          <label for="first_name">Website</label>
                        </div>
                          <div class="input-field col s12 m6">
                        
                            <select id="pos" name="pos" >
                            <option value="0">Select Position</option>
                             <option value="1" <?php if( $edit->adv_position==1 ) echo "selected";?>>Top</option>
                             <option value="2" <?php if( $edit->adv_position==2 ) echo "selected";?>>Bottom</option>
                            </select>
                          <label for="first_name">Position</label>
                        </div>
                        <div class="input-field col s12 m6">
                        
                            <select id="publish" name="publish" >
                            <option value="0">Select Publish Status</option>
                             <option value="1" <?php if( $edit->publish_status==1 ) echo "selected";?>>Publish </option>
                             <option value="2" <?php if( $edit->publish_status==2 ) echo "selected";?>>Unpublish</option>
                            </select>
                          <label for="first_name">Publish Status</label>
                        </div>
                  </div>
                      
                      <div class="row">
                       
                        <div class="row">
                          <div class="input-field col s12">
                            <button class="btn cyan waves-effect waves-light right"  id="btnsub" type="button"  name="btnsubmit">Update
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                  
                </div>
              </div>
              
              
              
              <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Advertisement List</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:10% !important;text-align:center;">SN</th>
                          <th style="width:100% !important;text-align:left;">Category</th>
                          <th style="width:20% !important;">Action</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php if($advertisement) { $i=1; foreach($advertisement as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:10% !important;text-align:center;"><?php echo $i ?></td>
								<td style="width:100% !important;text-align:left;"><?php echo $val->adv_title?> </td>
								<td > 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>advertisement/advertisementedit/<?php echo encode($val->adv_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class=" btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->adv_id);?>" id="btndelt" >
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
              
              
              
              
              
              
              
              
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>


	
	
	
<script >
	//------insert -------------//
$(document).ready(function(e) {
	
	
		
	function readURL(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#imgfiles').attr('src', e.target.result);
			Materialize.fadeInImage('#imgfiles');
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$("#imgfile").change(function(){
    readURL(this);
});	


	
			 
		 
   
       	 $("#btnsub").click(function(e) {
				//alert();
			var ev=validation();
			
			if(ev==0){
				$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>advertisement/updateadvertisement";
  			var redirect = "<?php echo ADMIN_PATH?>advertisement";
  			var form = document.forms.namedItem("frmadv");  
		              
			var oData = new FormData(document.forms.namedItem("frmadv"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //console.log(oReq.responseText); 
				$('.overlay').css({'display':'none'});	
						if(oReq.responseText==1){
					
					  customSwalFunD("Error","Already  published an ad in this position please unpublish it to publish new");
					}
					else{
				
							
					  customSwalFunD("Success","Sucessfully Updated");
 				document.location = redirect;
					}
					 }
                oReq.send(oData);
                e.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');
        

            var values = {
                                    'wsite':$('#wsite').val(),
									'title':$('#title').val(),
									 'pos':$('#pos').val(),
									'publish':$('#publish').val(),

                                 }
								 
			if(values.wsite == ''){
		   $('#wsite').addClass('errors');
			$('#wsite').attr("placeholder", "Please enter Website ")
		    $('#wsite').parent().children('label').addClass('labelerror');
            error=1;
        } 
			if(values.title == ''){
		   $('#title').addClass('errors');
			$('#title').attr("placeholder", "Please enter Title ")
		    $('#title').parent().children('label').addClass('labelerror');
            error=1;
        } 
			if(values.publish == 0){
		  	$('#publish').parent().children('.select-dropdown').addClass('errors');
			$('#publish').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 	if(values.pos == 0){
		   	$('#pos').parent().children('.select-dropdown').addClass('errors');
			$('#pos').parent().parent().children('label').addClass('labelerror');
            error=1;
        }
        return error;
    }
	
});

	
	</script>
    
   <script type="text/javascript">

$(document).ready(function(e) {
   	
	// ---------- < Delete Employee   > ---------- //
	
	
	   $(document).on('click', '#btndelt', function(){
		 
                var id=$(this).attr('rel');  
 swal({
                            title: "Are you sure?",
							   text: "Delete this Advertisement",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:"swal-delete",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          }).then(function(){
						  
			$('.overlay').css({'display':'flex'});
			//alert(id);
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>advertisement/deleteadvertisement",
					//redirect : "<?php echo ADMIN_PATH?>Merchant",

                                            data:"id="+id,

                                            success:function(data){// alert(data);
											$('.overlay').css({'display':'none'});	
											
                                               // $(".loader").remove();
                               //  location.reload() ;
                                 // 
	customSwalFunD("Sucessfully!", "Sucessfully deleted!", "success");
	var redirect = "<?php echo ADMIN_PATH?>advertisement";
		document.location = redirect;
                                            }
           
     

                                        });
					

				          });

		
			  
        });
		// ---------- < Delete Category ENDS > ----------
	
	
	
	
	
	
});
</script>
 
    

        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->


    
