<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Service_jobs extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Service_jobs_model','model');
	 }	
	 public function index()
	{
		//product list & adding page
		$headdata['status']='active';
		//$data['item']=$this->model->getitemstitle();//fetch all category
		//$data['am']=$this->model->getamenity();
	    $data['jobs']=$this->model->getserjobs();//fetched all product from tables
	    $headdata['menu']='s_jobs';
		$headdata['submenu']='s_jobs';
		$this->load->view('admin/header',$headdata);
		$this->load->view('admin/service_jobs/service_jobs',$data);
		$this->load->view('admin/footer');
	}
	 public function insert()
	{
		$this->model->insert();
		}
	
	
}

