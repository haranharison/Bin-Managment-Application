
   <style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
	
	 .panel-heading1 {
		 font-size: 18px;
    font-weight: 300;
    letter-spacing: 0.025em;
    height: 66px;
    line-height: 45px;
    background: ##ddd;
    border-bottom: 1px solid #eee;
    color: #333;
	padding: 10px 15px;
    /* background: #428bca; */
}
</style>
        
   
          
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Edit Sub Category</h4>
                      <div class="row">
                       <form role="form" name="frmsubcat" method="post" action="">
                       
                         <div class="row">
                            <div class="input-field col s12">
                            <input type="hidden" name="txthiden" id="txthiden" value="<?php if($edit){echo encode($edit->subcategory_id);}?>">
                              <select  name="selcat" id="selcat">
                                    <option value="0"> Category</option>
                                    	<?php foreach($category as $key){
											if($edit->cat_id==$key->category_id){?>
                                                 <option  selected="selected" value="<?php   echo $edit->cat_id;?>"><?php echo $key->cat_name;?></option>
											<?php	} else {?>
											<option value="<?php echo $key->category_id?>"><?php echo $key->cat_name?></option>
									<?php	}	}?>
										
										 
									</select>
                              <label for="first_name">SelectCategory</label>
                            </div>
                          </div>
                       
                       
                          <div class="row">
                            <div class="input-field col s12">
                              <input placeholder=" Sub Category " name="txtsubcategory" id="txtsubcategory"  type="text" value="<?php if($edit){ echo  $edit->subcat_name; }?>">
                             
                              <label for="first_name">Sub Category Name</label>
                            </div>
                          </div>
                          
                          
                          <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnupdate">Update
                                  <i class="material-icons right">send</i>
                                </button>
                                 <button class="btn cyan waves-effect waves-light right" type="reset" name="action" id="btncancel">Cancel</button>
                                 
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Sub Category</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                         <th style="width:10% !important;text-align:center;">SN</th>
                          <th style="width:100% !important;text-align:left;">Sub Category</th>
                          <th style="width:20% !important;">Action</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                      <?php if($subcategory) { $i=1; foreach($subcategory as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:10% !important;text-align:center;"><?php echo $i ?></td>
								<td style="width:100% !important;text-align:left;" ><?php echo $val->subcat_name?> </td>
								<td style="width:20% !important;"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH.'subcategory/editsubcategories/'.encode($val->subcategory_id);?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange btndlt" rel="<?php echo encode($val->subcategory_id)?>" >
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
                  <!-- Form with placeholder -->
                  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
          
	</div>



<script type="text/javascript">

$(document).ready(function(e) {
   	//------insert -------------//
       	 $("#btnupdate").click(function(e) {
			
			var e=validation();
			if(e==0){
				$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>subcategory/updatesubcategory";
  			var redirect = "<?php echo ADMIN_PATH?>subcategory";
  			var form = document.forms.namedItem("frmsubcat");                        
			var oData = new FormData(document.forms.namedItem("frmsubcat"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
				$('.overlay').css({'display':'none'});
				
				
			
				 	 customSwalFunD("Success"," Sub category Updated successfully");
				 setTimeout(function(){
  	document.location = redirect;
},600)
 					
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

       $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');
        

        var values = {
                                    'category':$('#selcat').val(),
									'sucategory':$('#txtsubcategory').val(),

                                 }

       if(values.category == 0){
				

           	$('#selcat').parent().children('.select-dropdown').addClass('errors');
			$('#selcat').parent().parent().children('label').addClass('labelerror');
            error=1;

        } 
		if(values.sucategory == ''){

            $('#txtsubcategory').addClass('errors');
			$('#txtsubcategory').attr("placeholder", "Please enter subcategory")
		    $('#txtsubcategory').parent().children('label').addClass('labelerror');
			
            error=1;

        } 
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	var redirect = "<?php echo ADMIN_PATH?>subcategory";
			document.location=redirect;
        });
	//---------End cancel------//	
	
	
	
	// ---------- < Delete Category   > ---------- //
		 		    $(document).on('click', '.btndlt', function(){
						//alert()
                var id=$(this).attr('rel');  
 swal({
                            title: "Are you sure?",
							   text: "Delete this Sub Category",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:'swal-delete',
							   closeOnConfirm: true,
							   closeOnCancel: true 
                         }).then(function(){
                             
			$('.overlay').css({'display':'flex'});
			var redirect = "<?php echo ADMIN_PATH?>subcategory";
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>Subcategory/deletesubategories",

                                            data:"id="+id,

                                            success:function(data){ //alert(data);
												$('.overlay').css({'display':'none'});
										

	                                customSwalFunD("Success","Sub Category has been  Deleted");
                         setTimeout(function(){
    document.location = redirect;
},600)                   }

                                        });
					

				          });

		
			  
        });
	
	
});
</script>










