
  <style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
	float:right;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
.file-field .btn {
        float: right;
    position: relative;
}
.addDynamicfield,.removeDynamicfield{
						    position: absolute;
							top: 16px;
							right: -10px;
							padding:0px;
							color: #0092d3;
							cursor:pointer;
							opacity:0.7;
							transition:opacity 0.2s;
							  -webkit-touch-callout: none; /* iOS Safari */
							-webkit-user-select: none; /* Safari */
							 -khtml-user-select: none; /* Konqueror HTML */
							   -moz-user-select: none; /* Firefox */
								-ms-user-select: none; /* Internet Explorer/Edge */
									user-select: none; /* Non-prefixed version, currently
														  supported by Chrome and Opera */
				  }
				   .addDynamicfield:hover,.removeDynamicfield:hover{
					   opacity:1;
				   }
				  .removeDynamicfield{
						color:#F30;  
				  }
                  .addDynamicfield i,.removeDynamicfield i{
					font-size: 22px;  
				  }
				  .removeDynamicfield i.removing{
					  animation:spin 2s linear infinite;
				  }
</style>

 <style>
					  		.merchant-reg-image{
								text-align:center;width: 150px;height: 181px;margin: 0 auto;overflow: hidden;
							}
                      		.merchant-reg-image img{
								border:none;width: 150px;height: 150px;/*float: right;border-radius:50%*/		
							}
							.merchant-reg-image .file-field .btn{
								float:none;	
							}
							.merchant-reg-image .file-field.input-field{
								margin-top:0rem;
							}
							.merchant-reg-image .btn{
								border-radius: 0;height: 2.1rem;line-height: 1;padding: 0.5rem 1.2rem;width: 150px;font-size: 14px;font-weight: 600;
							}
							.vdetails{
							display:none;	
								}
								.ulimit{
								display:none;
									
									}
                      </style>
<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m12 l6">
                <div class="card-panel">
                                      <h4 class="header2">Employee Registration</h4>

                  <div class="row">
                  <form role="form" name="frmsalesmanreg" id="frmsalesmanreg"  method="post" enctype="multipart/form-data">
                      <div class="row">
                      <div class="input-field col m6 s6">
                              			<div class="merchant-reg-image">
                                        <img src="<?php echo SITE_PATH; ?>dummy.jpg" id="imgfiles"/>
                                        <div class="file-field input-field">
                            <div class="btn">
                            <span>Photo</span>
                            <input type="file" id="imgfile"  name="imgfile" >
                            </div>
                            <div class="file-path-wrapper" style="display:none;" >
                            <input class="file-path validate" type="text">
                            </div>
                            </div>
                                        </div>
                              </div>
                      
                      
                     <div class="input-field col m6 s6">
                              			<div class="merchant-reg-image">
                                        <img src="<?php echo SITE_PATH; ?>dummy.jpg" id="biodate"/>
                                        <div class="file-field input-field">
                            <div class="btn">
                            <span>Resume</span>
                            <input type="file" id="biodata"  name="biodata" >
                            </div>
                            <div class="file-path-wrapper" style="display:none;" >
                            <input class="file-path validate" type="text">
                            </div>
                            </div>
                                        </div>
                              </div> 
                      <div style="height:20px; clear:both;"></div>
                      <!--<div class="input-field col s12">
                        
                    <img src="" id="imgfiles" style="border:none;      width: 150px;
    height: 150px;    float: right;">
                        <div class="file-field input-field">
                            <div class="btn">
                            <span>Select Image</span>
                            <input type="file" id="imgfile"  name="imgfile" >
                            </div>
                            <!--<div class="file-path-wrapper" >
                            <input class="file-path validate" type="text">
                            </div>
                            </div>
                              <img src="" id="biodate" style="border:none;      width: 150px;
    height: 50px;    float: right;">
                            <div class="file-field input-field">
                            <div class="btn">
                            <span>Choose Biodata</span>
                            <input type="file" id="biodata"  name="biodata" >
                            </div>
                            <!--<div class="file-path-wrapper" >
                            <input class="file-path validate" type="text">
                            </div>
                            </div>
    
    				
       
                         <!-- <input type="file" id="imgfile"  name="imgfile" class="form-control col-md-7 col-xs-12">
                      
                          <label for="first_name">Image</label>
                        </div>-->
                        <div class="input-field col s12 m6">
                        
                          	<input  type="text" placeholder="Employee Name" id="name" name="name" >
                            
                          <label for="first_name">Employee Name</label>
                        </div>
                        
                        <div class="input-field col s12 m6">
                        
                          	<input  type="text" placeholder="Employee Father Name" id="fname" name="fname" >
                            
                          <label for="first_name">Employee Father Name</label>
                        </div>
                        
                        <div class="input-field col  s12 m6">
                          	<input  type="text" placeholder="Address" id="address" name="address"/ >
                          <label for="first_name">Address</label>
                        </div>
                        
                        <div class="input-field col  s11 m5 l5 des">
                        <select name="designation" id="designation">
                          <option value="">Select Designations</option>
                            <?php if($designation) {  foreach($designation as $val) { ?>
                          <option value="<?php echo $val->desi_id;?>"><?php echo $val->desi_name?></option>
                          <?php  }  }?>
                          </select>
                        </div>
						<div  class="input-field col s1 m1 l1">
                          <a class="addDynamicfield btnadddesig" style="right:12px"><i class="material-icons">add_circle</i></a>
                        </div>
                         <div class="input-field col  s12 m6">
                          <select name="head" id="head">
                          <option value="">Reporting Officer</option>
                           <option value="0">Root</option>
                          <?php if($employee) {  foreach($employee as $val) { ?>
                          <option value="<?php echo $val->salesmanid;?>"><?php echo $val->name;?></option>
                          <?php  }  }?>
                          </select>
                        </div>
                        
                        <div class="input-field col s11 m5 l5 educat">
                        <select multiple name="edu" id="edu">
                          <option value="">Select Education</option>
                           <?php if($edu) {  foreach($edu as $val) { ?>
                          <option value="<?php echo $val->education_id;?>"><?php echo $val->educationname?></option>
                          <?php  }  }?>
                          
                          </select>
                        </div>
                        <div  class="input-field col s1 m1 l1">
                          <a class="addDynamicfield btnaddeducation" style="right:12px"><i class="material-icons">add_circle</i></a>
                        </div>
                        <div class="input-field col s12 m6">
                        
                          	<input  type="text" placeholder="Qualification" id="quali" name="quali" >
                            
                          <label for="first_name">Qualification</label>
                        </div>
                       
                       <div class="input-field col s12 m6">
                        
                          	<input  type="text" placeholder="Experience" id="exp" name="exp" >
                            
                          <label for="first_name">Experience</label>
                        </div>
                        
                        <div class="input-field col s12 m6">
                        
                          	<input  type="text" placeholder="Nationality" id="ntn" name="ntn" >
                            
                          <label for="first_name">Nationality</label>
                        </div>
                        
                       
                        
                        <div class="input-field col s12 m6">
                             <input type="text" class="datepicker" id="dob" name="dob">
                              <label for="dob">Date Of Birth</label>
                            </div>
                        
                        <div class="input-field col s12 m6">
                             <input type="text" class="datepicker" id="doj" name="doj">
                              <label for="doj">Date of Joining</label>
                            </div>
                        
                        
                        <div class="input-field col  s12 m6">
                          	<input  type="number"   name="phone" id="phone"  placeholder="Phone No.">
                          <label for="first_name">Phone</label>
                        </div>
                         
                        <div class="input-field col  s12 m6">
                       <select name="usergroup" id="usergroup">
                                    	<option disabled="disabled" value="">Select Usergroup</option>
										<?php foreach($usergroup as $key){?>
											
											<option value="<?php echo $key->usergroup_id;?>"><?php echo $key->usergroup_name;?></option>
											
									<?php		}?>
									</select>
                          <label for="first_name">Usergroup</label>
                        </div>
                        <div class="input-field col  s12 m6">
                          	 
							<select id="blood" name="blood">
							  <option value="1">A+</option>
							  <option value="2">A-</option>
							  <option value="3">AB+</option>
							  <option value="4">AB-</option>
							  <option value="5">B+</option>
							  <option value="6">B-</option>
							  <option value="7">O+</option>
							  <option value="8">O-</option>
							  
							</select>
                          <label for="first_name">Blood Group</label>
                        </div>
                       
                             <div class="input-field col  s12 m3">
                             	<input  type="text"   name="starttime" id="starttime"  placeholder="Job Timing." class="timepicker">
                                  <label for="first_name"> Start Job Timing</label>
                                </div>
                                 <div class="input-field col  s12 m3">
                             	<input  type="text"   name="endtime" id="endtime"  placeholder="Job Timing." class="timepicker">
                                  <label for="first_name"> end Job Timing</label>
                                </div>
                        
                        <div class="input-field col s12 m6">
                       <select  multiple name="area" id="area">
                          <option disabled="disabled" value="">Select Area</option>
										<?php foreach($area as $key){?>
											
											<option value="<?php echo $key->area_id;?>"><?php echo $key->area_name;?></option>
											
									<?php		}?>
									</select>
                          <label for="first_name">Area</label>
                        </div>
                        
                        <div class="input-field col s6" >
                         <select id="optionsRadios1"  name="gender">
                          <option disabled="disabled" value="">Select Gender</option>
                           <option value="male" >Male</option>
                            <option value="female" >Female</option>
                          </select>
                        <label for="first_name">Gender</label>
                 
                        
                         </div>
                         
          
                           
                        
                        <div class="input-field col  s12 m6">
                        <select name="fmlytype" id="fmlytype">
                          <option value="">Select Family Type </option>
                          <option value="1">Single</option>
                          <option value="2">Married </option>
                          <option value="3">Widow</option>
                          <option value="4">Widower </option>
                          </select>
                        </div>
                        
                        
                        <div class="input-field col s12 m6">
                          	<input  type="email" placeholder="Email" id="email" name="email"  >
                            
                          <label for="first_name">Email</label>
                        </div>
                        <div class="input-field col s12 m6">
                          	<input  type="password" placeholder="Password" name="salespwd" id="salespwd" >
                          <label for="first_name">Password</label>
                        </div>
                        
                        <div class="input-field col s12 m6">
                          	<input  type="password" placeholder="Confirm Password" name="cnfrmsalespwd" id="cnfrmsalespwd" > 
                          <label for="first_name">Confirm Password</label>
                        </div>
                         
                         
                         <div class="input-field col s12 m6">
                          	<input  type="text" placeholder="PF-UAN No:" name="pfuan" id="pfuan" > 
                          <label for="first_name">PF-UAN No:</label>
                        </div>
                        
                        <div class="input-field col s12 m6">
                          	<input  type="text" placeholder="ESI No" name="esi" id="esi" > 
                          <label for="first_name">ESI No:</label>
                        </div>
                        <div class="input-field col s12 m6 ulimit">
                          	<input  type="text" placeholder="Employee User Limit" name="empuserlimit" id="empuserlimit"  class="number-check"> 
                          <label for="first_name">Employee User Limit</label>
                        </div>
                          	
                            <div class="input-field col  s12 m6" >
                            <select id="attendance1"  name="atttrack">
                          <option value="">Select Attendance Tracker</option>
                           <option value="1">With Photo</option>
                            <option value="2">Without Photo</option>
                          </select>
                        <label for="first_name">Attendance Tracker</label>
                 
                        
                         
   
                        </div>
                            
                            
                            <div class="input-field col  s12 m6" >
                             <select id="background1"  name="bckgrndveri">
                          <option value="">Select Attendance Tracker</option>
                           <option value="Yes">Yes</option>
                            <option value="No">No</option>
                          </select>
                        <label for="first_name">Back Ground Verification</label>
                        </div>
               
                        <div class="input-field col s12 m6 vdetails">
                          	<input  type="text" placeholder="Agency Name" name="agencyname" id="agencyname" > 
                          <label for="first_name">Agency Name</label>
                        </div><div class="input-field col s12 m6 vdetails">
                          	<input  type="text" placeholder="Verified Date" class="datepicker" name="verifieddate" id="verifieddate" > 
                          <label for="first_name">Verified Date</label>
                        </div>
                         
                               </div>
                      
                      
                      
                      
                      <div class="row">
                       
                        <div class="row">
                          <div class="input-field col s12">
                            <button class="btn cyan waves-effect waves-light right"  id="btnsub" type="button"  name="btnsubmit">Submit
                              <i class="material-icons right"></i>
                            </button>
                          </div>
                        </div>
                      </div>
                      <input type="hidden"  name="eduid" id="eduid" />
                        <input type="hidden"  name="areaid" id="areaid" />
                    </form>
                  </div>
                  
                </div>
              </div>
              
              
              
              <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Employee List</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:10% !important;text-align:center;">SN</th>
                          <th style="width:100% !important;text-align:left;">Employee</th>
                          <th style="width:20% !important;">Action</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php if($employee) { $i=1; foreach($employee as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:10% !important;text-align:center;"><?php echo $i ?></td>
								<td style="width:100% !important;text-align:left;"><?php echo $val->name?> </td>
								<td > 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>employee/employeeedit/<?php echo encode($val->salesmanid); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class=" btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->salesmanid);?>" id="btndelt" >
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
              
              
              
              
              
              
              
              
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>


	
	
	
<script >
	//------insert -------------//
$(document).ready(function(e) {
	
		$(document).on('change', '#head', function(){
			
		if($('#head').val()==='0' ){
			
			$('.ulimit').show();
			}
		
			else{	
				$('.ulimit').hide();
				$('.empuserlimit').val('');
				}
		
		})	
	
	 $(document).on('keypress','.number-check', function(e) {	
				if ( event.keyCode == 46 || event.keyCode == 8 ) {
							
				}
				 else {
						if (event.keyCode < 48 || event.keyCode > 57) {
							event.preventDefault(); 
						}  
				 }
			});
		 $('#email').blur(function(){
		
	
	 var pattern =/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
	// console.log(pattern.test($('#txtemail').val()))
					//	 console.log( pattern.test( $scope.chkemail));
						 if(pattern.test($('#email').val())==false){
							 $('#email').addClass('errors');
			 				 $('#email').parent().children('label').addClass('labelerror');
							 
						
						  }
						  else{
							  $('#email').removeClass('errors');
			 				 $('#email').parent().children('label').removeClass('labelerror');
							  }
	
	  });
	
	 $('.timepicker').pickatime({
    default: 'now', // Set default time: 'now', '1:30AM', '16:30'
    fromnow: 0,       // set default time to * milliseconds from now (using with default = 'now')
    twelvehour: false, // Use AM/PM or 24-hour format
    donetext: 'OK', // text for done-button
    cleartext: 'Clear', // text for clear-button
    canceltext: 'Cancel', // Text for cancel-button,
    container: undefined, // ex. 'body' will append picker to body
    autoclose: false, // automatic close timepicker
    ampmclickable: true, // make AM PM clickable
    aftershow: function(){} //Function for after opening timepicker
  });
	
	
	
	$('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15, // Creates a dropdown of 15 years to control year,
    today: 'Today',
    clear: 'Clear',
    close: 'Ok',
    closeOnSelect: false, // Close upon selecting a date,
	format: 'yyyy-mm-dd',
    container: undefined // ex. 'body' will append picker to body
  });
	
		
	function readURL(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#imgfiles').attr('src', e.target.result);
			Materialize.fadeInImage('#imgfiles');
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$("#imgfile").change(function(){
    readURL(this);
});	


function alreadyexistalert(){
	
	 swal({
                            title: "Error",
							   text: "Tax Type Already Exist",
							   showCancelButton: true,
							   confirmButtonText: "OK",
							   cancelButtonText: "Cancel ",
							   customClass:"swal-delete",
                         	 }).then(function(){
							  
							   btnaddeducation();
							  
							  });
	}


function btnaddeducation(){
								
		  					  $('#edu').material_select();
							  $('#edu').css({'display':'block'});
							//  var cat=$("#cat").val();
				swal({
						  title: 'Add New Education',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input autofocus="autofocus" placeholder="Enter Education " name="ename" spellcheck="false" id="ename" type="text"  ><label for="first_name">Education</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var education=$("#ename").val();
									//alert(education); 
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors'); 
								    $('select').removeClass('errors');
								   if(education==''){ 
											$('#ename').parent().children('label').addClass('labelerror');
											$('#ename').addClass('errors');
											$('#ename').attr("placeholder", "Please enter Product type");
										err=1;
									}
									 
									return err;	
							}
								if(ev==0){
								
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>employee/inserteducation",
														data:"ename="+education,
														//alert(data);
														success:function(data){//alert(data);
															 $('.overlay').css({'display':'none'}); 
														if(data==1){
															alreadyexistalert();
															//reject('Tax Type Already Exist');
															}
															else{
															
																resolve();	  
															}
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
										$('.overlay').css({'display':'flex'});
									swal({
		  title: '<div class="tst" >Success</div>',
		  html:'<div class="tst1" >Education Added</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
			 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>employee/geteducation1",
												//	data:"catval="+cat2,
														success:function(data){ 
																$('.overlay').css({'display':'none'}); 
																$('#edu').material_select('destroy');
																$('.educat').html(data);
																$('#edu').material_select();
															//	location.reload();
														}
										 			});
			  	});
	
		}
						
						
	$(document).on('click', '.btnaddeducation', function(){
		btnaddeducation();
		
		})	
	
function alreadyexistalert(){
	
	 swal({
                            title: "Error",
							   text: "Designation already exist",
							   showCancelButton: true,
							   confirmButtonText: "OK",
							   cancelButtonText: "Cancel ",
							   customClass:"swal-delete",
                         	 }).then(function(){
							  
							   btnadddesig();
							  
							  });
	}


function btnadddesig(){
								
		  					  $('#designation').material_select();
							  $('#designation').css({'display':'block'});
							//  var cat=$("#cat").val();
				swal({
						  title: 'Add New Designation',
						  type: 'info',
						  html:
						  '<div class="row"><div class="input-field col s12"><input autofocus="autofocus" placeholder="Enter Designation " name="dname" spellcheck="false" id="dname" type="text"  ><label for="first_name">Designation</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var desi=$("#dname").val();
									//alert(education); 
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors'); 
								    $('select').removeClass('errors');
								   if(desi==''){ 
											$('#dname').parent().children('label').addClass('labelerror');
											$('#dname').addClass('errors');
											$('#dname').attr("placeholder", "Please enter Designtion");
										err=1;
									}
									 
									return err;	
							}
								if(ev==0){
								
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>employee/insertdesig",
														data:"dname="+desi,
														//alert(data);
														success:function(data){//alert(data);
															 $('.overlay').css({'display':'none'}); 
														if(data==1){
															alreadyexistalert();
															//reject('Tax Type Already Exist');
															}
															else{
															
																resolve();	  
															}
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
										$('.overlay').css({'display':'flex'});
									swal({
		  title: '<div class="tst" >Success</div>',
		  html:'<div class="tst1" >Designation Added</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		  
		})
			 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>employee/getdesignation",
												//	data:"catval="+cat2,
														success:function(data){// alert(data);
																$('.overlay').css({'display':'none'}); 
																$('#designation').material_select('destroy');
																$('.des').html(data);
																$('#designation').material_select();
																
															//	location.reload();
														}
										 			});
			  	});
	
		}
						
						
	$(document).on('click', '.btnadddesig', function(){
		btnadddesig();
		
		})		
	


		
function readURLB(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#biodate').attr('src', e.target.result);
			Materialize.fadeInImage('#biodate');
        }

        reader.readAsDataURL(input.files[0]);
    }
}
$("#biodata").change(function(){
    readURLB(this);
});
			
	$(document).on('change', '#background1', function(){
	//alert($("#background1").val())
			 if( $("#background1").val()=='Yes'){
			 $(".vdetails").css({'display':'block'});
			 }
			 else {
			 $(".vdetails").css({'display':'none'});
			 }
			 });
			 
		 
   
       	 $("#btnsub").click(function(e) {
				//alert();
				$('#eduid').val( $('#edu').val());
				
					$('#areaid').val( $('#area').val());
		//	alert($('#area').val());
		//	alert(e);
			var e=validation();
			
			if(e==0){
				$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>employee/employeereg";
  			var redirect = "<?php echo ADMIN_PATH?>employee";
  			var form = document.forms.namedItem("frmsalesmanreg");  
		              
			var oData = new FormData(document.forms.namedItem("frmsalesmanreg"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
					$('.overlay').css({'display':'none'});	
				 if(oReq.responseText==1){
					 customSwalFunD("Exist","Phone number already Exist");
					 }
					else if(oReq.responseText==2){
					  customSwalFunD("Exist","Email already Exist");
					 }
					 else if(oReq.responseText==3){
					
					  customSwalFunD("Error","Employee User Limit Greater Than Organisation User Limit");
					 }
					  else if(oReq.responseText==4){
					
					  customSwalFunD("Error","Organisation User Limit To Add Employee Reached");
					 }
					 else if(oReq.responseText==5){
					
					  customSwalFunD("Error","Employee User Limit Greater Than Emloyee Head User Limit");
					 }
					  else if(oReq.responseText==6){
					
					  customSwalFunD("Error","Employee User Limit To Add Employee Reached");
					 }
					 
					 else
					 {
					  customSwalFunD("Success","Sucessfully Added");
 				     document.location = redirect;
					 }
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');
        

            var values = {
                                    'name':$('#name').val(),
									'address':$('#address').val(),
									'phone':$('#phone').val(),
									'area':$('#area').val(),
									'gender':$('#optionsRadios1').val(),
									'salespwd':$('#salespwd').val(),
									'fmlytype':$('#fmlytype').val(),
									'verifieddate':$('#verifieddate').val(),
									'agencyname':$('#agencyname').val(),
									'cnfrmsalespwd':$('#cnfrmsalespwd').val(),
									'imgfile':$('#imgfile').val(),
									'usergroup':$('#usergroup').val(),
									'email':$('#email').val(),
									'background1':$('#background1').val(),
									'designation':$('#designation').val(),
									'head':$('#head').val(),
									'fathername':$('#fname').val(),
									'education':$('#edu').val(),
									'qualification':$('#quali').val(),
									'experience':$('#exp').val(),
									'nationality':$('#ntn').val(),
									'background':$('#bckgrndveri').val(),
									'dateofbirth':$('#dob').val(),
									'dateofjoin':$('#doj').val(),
									'pfuan':$('#pfuan').val(),
									'esi':$('#esi').val(),
									'attendancetracker':$('#atttrack').val(),
									'blood':$('#blood').val(),
									'starttime':$('#starttime').val(),
									'endtime':$('#endtime').val(),
									'empuserlimit':$('#empuserlimit').val()

                                 }
			if($('#head').val()==='0' ){
				if(values.empuserlimit == ''){
		   $('#empuserlimit').addClass('errors');
			$('#empuserlimit').attr("placeholder", "Please Enter Employee User Limit")
		    $('#empuserlimit').parent().children('label').addClass('labelerror');
            error=1;
        } 							
											
		} 
			if(values.email == ''){
		   $('#email').addClass('errors');
			$('#email').attr("placeholder", "Please enter email")
		    $('#email').parent().children('label').addClass('labelerror');
            error=1;
        } 
		 var pattern =/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
		 if(pattern.test($('#email').val())==false){
							 $('#email').addClass('errors');
			 				 $('#email').parent().children('label').addClass('labelerror');
							 
						 error=1;
						  }		
		/*if(values.background=='Yes'){
		
		       if(values.agencyname == ''){
		    $('#agencyname').addClass('errors');
			$('#agencyname').attr("placeholder", "Please enter agency name")
		    $('#agencyname').parent().children('label').addClass('labelerror');
            error=1;
        }
		    if(values.verifieddate == ''){
		    $('#verifieddate').addClass('errors');
			$('#verifieddate').attr("placeholder", "Please enter time")
		    $('#verifieddate').parent().children('label').addClass('labelerror');
            error=1;
        }
		}*/
             if(values.fmlytype == ''){
		    $('#fmlytype').parent().children('.select-dropdown').addClass('errors');
			$('#fmlytype').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		     if(values.education == ''){
		    $('#edu').parent().children('.select-dropdown').addClass('errors');
			$('#edu').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		
		     if(values.experience == ''){
		    $('#exp').addClass('errors');
			$('#exp').attr("placeholder", "Please enter experience")
		    $('#exp').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		
		
		     if(values.gender == ''){
		   $('#optionsRadios1').parent().children('.select-dropdown').addClass('errors');
			$('#optionsRadios1').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 

		      if(values.qualification == ''){
		    $('#quali').addClass('errors');
			$('#quali').attr("placeholder", "Please enter qualification")
		    $('#quali').parent().children('label').addClass('labelerror');
            error=1;
        } 
		      if(values.nationality == ''){
		     $('#ntn').addClass('errors');
			$('#ntn').attr("placeholder", "Please enter nationality")
		    $('#ntn').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		      if(values.background == ''){
		    $('#background').parent().children('.select-dropdown').addClass('errors');
			$('#background').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		     if(values.dateofbirth == ''){
		   $('#dob').addClass('errors');
			$('#dob').attr("placeholder", "Please enter Date of Birth")
		    $('#dob').parent().children('label').addClass('labelerror active');
            error=1;
        } 
		      if(values.dateofjoin == ''){
		    $('#doj').addClass('errors');
			$('#doj').attr("placeholder", "Please enter Date of Join")
		    $('#doj').parent().children('label').addClass('labelerror active');
            error=1;
        }   
		       if(values.pfuan == ''){
		     $('#pfuan').addClass('errors');
			$('#pfuan').attr("placeholder", "Please enter PF- UAN NO:")
		    $('#pfuan').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		       if(values.esi == ''){
		    $('#esi').addClass('errors');
			$('#esi').attr("placeholder", "Please enter ESI NO:")
		    $('#esi').parent().children('label').addClass('labelerror');
            error=1;
        } 
		     /*  if(values.attendancetracker == ''){
		    $('#attendancetracker').parent().children('.select-dropdown').addClass('errors');
			$('#attendancetracker').parent().parent().children('label').addClass('labelerror');
            error=1;
        } */
		   
		
			 if(values.usergroup == ''){
		    $('#usergroup').parent().children('.select-dropdown').addClass('errors');
			$('#usergroup').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
		
			  if(values.imgfile == ''){
            $('.file-path').addClass('errors');
			$('.file-path').attr("placeholder", "Please select file")
		    $('.file-path').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		
		    if(values.fathername == ''){
            $('#fname').addClass('errors');
			$('#fname').attr("placeholder", "Please enter father name")
		    $('#fname').parent().children('label').addClass('labelerror');
            error=1;
        }    
		
		if(values.background1 == ''){
		   $('#background1').parent().children('.select-dropdown').addClass('errors');
			$('#background1').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
		

        if(values.name == ''){
            $('#name').addClass('errors');
			$('#name').attr("placeholder", "Please enter name")
		    $('#name').parent().children('label').addClass('labelerror');
            error=1;
        } 
		 if(values.head == ''){
		    $('#head').parent().children('.select-dropdown').addClass('errors');
			$('#head').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
		  if(values.designation == ''){
			  $('#designation').parent().children('.select-dropdown').addClass('errors');
			$('#designation').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
		 if(values.blood == ''){
            $('#blood').addClass('errors');
			$('#blood').attr("placeholder", "Please enter blood group")
		    $('#blood').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.endtime == ''){
            $('#endtime').addClass('errors');
			$('#endtime').attr("placeholder", "Please enter end time")
		    $('#endtime').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.starttime == ''){
            $('#starttime').addClass('errors');
			$('#starttime').attr("placeholder", "Please enter start time")
		    $('#starttime').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.address == ''){
            $('#address').addClass('errors');
            $('#address').attr("placeholder", "Please enter address")
		    $('#address').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.phone == ''){
            $('#phone').addClass('errors');
            $('#phone').attr("placeholder", "Please enter phone number")
		    $('#phone').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.area == ''){
          //  $('.select-dropdown').addClass('errors');
			$('#area').parent().children('.select-dropdown').addClass('errors');
			$('#area').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.salespwd == ''){
            $('#salespwd').addClass('errors');
            $('#salespwd').attr("placeholder", "Please enter password")
		    $('#salespwd').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.cnfrmsalespwd == ''){
            $('#cnfrmsalespwd').addClass('errors');
            $('#cnfrmsalespwd').attr("placeholder", "Please enter confirm password")
		    $('#cnfrmsalespwd').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.cnfrmsalespwd !=values.salespwd ){
		
			
			$('#salespwd').addClass('errors');
            $('#salespwd').attr("placeholder", "Please enter password")
		    $('#salespwd').parent().children('label').addClass('labelerror');
			$('#cnfrmsalespwd').addClass('errors');
             $('#cnfrmsalespwd').attr("placeholder", "Please enter confirm password")
		    $('#cnfrmsalespwd').parent().children('label').addClass('labelerror');
         //   swal("error!", "new password and confirm password mismatch!", "error")
			  customSwalFun("Error","New password and confirm password mismatch!","error","swal-delete");
			 error=1;
        } 
		
        return error;
    }
	
});

	
	</script>
    
   <script type="text/javascript">

$(document).ready(function(e) {
   	
	// ---------- < Delete Employee   > ---------- //
	
	
	   $(document).on('click', '#btndelt', function(){
		 
                var id=$(this).attr('rel');  
 swal({
                            title: "Are you sure?",
							   text: "Delete this Employee",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:"swal-delete",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          }).then(function(){
						  
			$('.overlay').css({'display':'flex'});
			//alert(id);
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>employee/deleteEmployee",
					//redirect : "<?php echo ADMIN_PATH?>Merchant",

                                            data:"id="+id,

                                            success:function(data){// alert(data);
											$('.overlay').css({'display':'none'});	
											
                                               // $(".loader").remove();
                                 location.reload() ;
                                 // 	document.location = redirect;
	customSwalFunD("Sucessfully!", "Sucessfully deleted!", "success")
                                            }
           
     

                                        });
					

				          });

		
			  
        });
		// ---------- < Delete Category ENDS > ----------
	
	
	
	
	
	
});
</script>
 
    

        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->


    




    
    
    
    
    
    
    
    
    

