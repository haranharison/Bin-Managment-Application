<?php
class Tax_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	//selecting all tax names
		public function gettax(){
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_tax')->result();
		}
	//Adding New Tax name
	public function addtax()
		{
		$exist=fieldexist('tbl_tax','tax_name',$this->input->post('txttax'),'org_id',$this->session->userdata('org_id'));
		if($exist==1){
		echo 1;
		}
		else{
			$max=maxplus('tbl_tax','tax_product_id');
			$today= date("y-m-d");
			$tax=$this->input->post('txttax');
			$data= array(
			'org_id'=>$this->session->userdata('org_id'),
				   'tax_product_id'=>$max,
				   'tax_name'=>$tax,
				   'tax_create_date'=>$today,
				   'tax_modify_date'=>$today
			);
			$this->db->insert('tbl_tax',$data);
			}
		
	}


		
		
		
		
		
/*____________________________________________________________________________________________________________*/		
		
	//fetch &  update tax Name	
	public function edittax($id){
		$tid=$id;
		$array=array('tax_id'=>$tid,'status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_tax')->row();
	}		
	public function deletetax(){
		 $did=$this->input->post('id');
		 $data=array('status'=>1);
		 $array= array('tax_product_id'=>$did);
		 $this->db->where($array);
		 $this->db->update('tbl_tax',$data);
	}
		
	public function getdetails()
	{
		$eid=decode($this->input->post('eid'));
		$array=array('tax_id'=>$eid,'status'=>0);
		$this->db->where($array);
		$this->db->select('tax_name');
		$rows=$this->db->get('tbl_tax')->row();
		 echo $rows->tax_name;
	}	
	public function updatetax()
	{
		$eid=decode($this->input->post('eid'));
		$taxname=$this->input->post('taxname');
		$data=array('tax_id'=>$eid,'tax_name'=>$taxname);
		$array=array('tax_id'=>$eid,'status'=>0);
		$this->db->where($array);
		$this->db->update('tbl_tax',$data);
		 echo 1;
	}
}