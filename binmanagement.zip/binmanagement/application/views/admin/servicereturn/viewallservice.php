

  <style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
	float:right;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
.file-field .btn {
        float: right;
    position: relative;
}
/*.vname{
display:none;	
	}*/
	#vmid{
display:none;	
	}
</style>
 <!--breadcrumbs start-->
          <!--breadcrumbs end-->

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <!--<div class="col s12 m6 l6">
                <div class="card-panel">
				<h4 class="header2">Add Service</h4>
                  <div class="row">
                  <form role="form" name="frmservice" id="frmservice"  method="post" enctype="multipart/form-data">
                      <div class="row">                    
                                          
                        
                        <div class="input-field col s12 m6 s6" id="vname">
                        
                          	<input  type="text" placeholder="Name" id="sname" name="sname">
                            
                          <label for="first_name">Name</label>
                        </div>
                                                                    
                        <div class="input-field col s12 m6 s6">
                          	<input  type="text" placeholder="Address" id="address" name="address">
                          <label for="first_name">Address</label>
                        </div>
                        <div class="input-field col s12 m6 s6">
                          	<input  type="text" placeholder="Product" id="product" name="product">
                          <label for="first_name">Product</label>
                        </div>
                        <div class="input-field col s12 m6 s6">
                            <input type="text" class="datepicker" id="yrofmanu" name="yrofmanu">
                          	<label for="first_name">Year of Manufacturing</label>
                        </div>
                        
                        <div class="input-field col s12 m6 s6">
                        <select name="warranty" id="warranty">
                          <option value="">Select Warranty Type </option>
                          <option value="1">Under Warranty</option>
                          <option value="2">Out of Warranty </option>
                          </select>
                        </div>
                        
                        <div class="input-field col s12 m6 s6">
                            <input type="text" class="datepicker" id="exdeldate" name="exdeldate">
                          	<label for="first_name">Expected delivery date</label>
                        </div>
                        
                        <div class="input-field col s12 m6 s6">
                          	<input  type="text" name="cmplnts" id="cmplnts"  placeholder="Complaints description">
                          <label for="first_name">Complaints</label>
                        </div>
                        
                        <div class="input-field col s12 m6 s6">
                          	<input  type="number" name="mobile" id="mobile"  placeholder="Mobile No.">
                          <label for="first_name">Mobile</label>
                        </div>
                        
                         <div class="input-field col s12 m6 s6">
                          	<input  type="number" name="altnumber" id="altnumber"  placeholder="Alternative No.">
                          <label for="first_name">Alternative No.</label>
                        </div>  
                        <div class="input-field col s12 m6 s6">
                          	<input  type="email" name="semail" id="semail"  placeholder="Email">
                          <label for="first_name">Email</label>
                        </div>
                                  </div>
                      
                      <div class="row">
                       
                        <div class="row">
                          <div class="input-field col s12">
                            <button class="btn cyan waves-effect waves-light right"  id="btnsub" type="button"  name="btnsubmit">Submit
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>-->
			  <div class="col s12 m12 l12">
                    <div class="card-panel">
                      <h4 class="header2">All Services</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:20px;text-align:center;">SN</th>
                           <th style="text-align:left;width:200px;">Service Request No</th>
                          <th style="text-align:left;">Product</th>
                          <th style="text-align:left;">Name</th>
                         
                          <th style="text-align:left;">Mobile no</th>
                          <th style="width:75px"></th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php  if($service){ $i=1; foreach($service as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:20px;text-align:center;"><?php echo $i ?></td>
                                 <td style="text-align:left;"><a href="<?php echo ADMIN_PATH?>servicereturn/addservicereturn/<?php echo encode($val->ser_id);?>"><span class="btn cyan waves-effect waves-light"><?php echo $val->complaint_no?></span></a> </td>
								<td style="text-align:left;"><?php echo $val->ser_product?> </td>
                                <td style="text-align:left;"><?php echo $val->ser_name?> </td>
                               
                                 <td style="text-align:left;"><?php echo $val->ser_mobile?> </td>
								<td style="width:75px"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>service/seredit/<?php echo encode($val->ser_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->ser_id);?>" >
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
			  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>


	
	
	
<script >




	
	
	
	
$(document).ready(function(e) {
	$('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15, // Creates a dropdown of 15 years to control year,
    today: 'Today',
    clear: 'Clear',
    close: 'Ok',
    closeOnSelect: false, // Close upon selecting a date,
	format: 'yyyy-mm-dd',
    container: undefined // ex. 'body' will append picker to body
  });
	//------insert -------------//
	
   function showcomplaintid(cnid){
	   
	    swal({
		title: 'Complaint ID',
		text: cnid,
		confirmButtonColor: '#3085d6',
		confirmButtonText: 'Ok',
		customClass:'swal-delete'
	}).then(function () {
						
		  customSwalFunD("Success","Sucessfully Added");				
		location.reload();
						
  	})      
	   
	   }
       	 $("#btnsub").click(function(e) {
			 
			var e=validation();
		 
			if(e==0){
					$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>service/addservice";
  			var redirect = "<?php echo ADMIN_PATH?>service";
  			var form = document.forms.namedItem("frmservice");  
		              
			var oData = new FormData(document.forms.namedItem("frmservice"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { 
					$('.overlay').css({'display':'none'});
					showcomplaintid(oReq.responseText);
					 }
                oReq.send(oData);
                //ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');
        

            var values = {
                                    'sname':$('#sname').val(),
									'address':$('#address').val(),
									'product':$('#product').val(),
									'yrofmanu':$('#yrofmanu').val(),
									'warranty':$('#warranty').val(),
									'exdeldate':$('#exdeldate').val(),
									'cmplnts':$('#cmplnts').val(),
									'mobile':$('#mobile').val(),
									'altnumber':$('#altnumber').val()


                                 }
								 
			if(values.sname == ''){
		   $('#sname').addClass('errors');
			$('#sname').attr("placeholder", "Please enter name")
		    $('#sname').parent().children('label').addClass('labelerror');
            error=1;
        } 
			 if(values.address == ''){
		     $('#address').addClass('errors');
			$('#address').attr("placeholder", "Please enter address")
		    $('#address').parent().children('label').addClass('labelerror');
            error=1;
        } 
			  if(values.product == ''){
            $('#product').addClass('errors');
			$('#product').attr("placeholder", "Please enter product")
		    $('#product').parent().children('label').addClass('labelerror');
            error=1;
        } 

        if(values.yrofmanu == ''){
            $('#yrofmanu').addClass('errors');
			$('#yrofmanu').attr("placeholder", "Please enter Year of Manufacturing")
		    $('#yrofmanu').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		 if(values.warranty == ''){
		    $('#warranty').parent().children('.select-dropdown').addClass('errors');
			$('#warranty').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
				
		if(values.exdeldate == ''){
            $('#exdeldate').addClass('errors');
            $('#exdeldate').attr("placeholder", "Please enter Expected delivery date")
		    $('#exdeldate').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.cmplnts == ''){
            $('#cmplnts').addClass('errors');
            $('#cmplnts').attr("placeholder", "Please enter Complaints")
		    $('#cmplnts').parent().children('label').addClass('labelerror');
            error=1;
        }
        if(values.mobile == ''){
            $('#mobile').addClass('errors');
            $('#mobile').attr("placeholder", "Please enter Mobile No.")
		    $('#mobile').parent().children('label').addClass('labelerror');
            error=1;
        } 	
         	
		if(values.altnumber == 0){
            $('#altnumber').addClass('errors');
            $('#altnumber').attr("placeholder", "Please enter Alternative No.")
		    $('#altnumber').parent().children('label').addClass('labelerror');
            error=1;
        }
		

        return error;
    }
	
	
});
	// ---------- < Delete service   > ---------- //

$(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
				
 swal({
		title: 'Are you sure?',
		text: "You won't be able to revert this!",
		type: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#3085d6',
		cancelButtonColor: '#d33',
		confirmButtonText: 'Yes, delete it!'
	}).then(function () {
						 $.ajax({
                         type:"post",
                         url: "<?php echo ADMIN_PATH ?>service/deleteService",
                         data:"id="+id,
						 success:function(data){ 											
												 swal(
														'Deleted!',
														'Your file has been deleted.',
														'success'
													 )
														location.reload() ;
	
											   }
			    
	});
  	})                    
			  
});	
		
		
	</script>
    
      





    




    
    
    
    
    
    
    
    
    

