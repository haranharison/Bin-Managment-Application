<?php
class Smssettings_model extends CI_Model 
{	
    public function __construct()
	{
        $this->load->database(); 
    }	
		
			
		
		
		
		public function getsms()
		{
			$array=array('org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			
			return $rows=$this->db->get('tbl_sms')->result();
		}
		
		
			public function getbrand()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_brand')->result();
		}
		
		public function getallmodel()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_model')->result();
		}
		
			 function get_model()
       {   
	
	$id=decode($this->input->post('brand'));
	 $arr=array('brand_id'=>$id);
	  $this->db->where($arr);
	 $res=$this->db->get("tbl_model");
	$result=$res->result();
	
		$html='';
	
	
		if($res->num_rows() > 0)
	{
		 
	$html.='<option value="0"> select model</option>';
	foreach($result as $val =>$key)
	{
	$html.='<option value="'.encode($key->model_id).'">'.$key->model_name.'</option>';
	}
	echo $html;
	}
	
	
	}
		
		
		
		public function getsms1($id)
		{
			$id=decode($id);
			$array=array('sid'=>$id);
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_sms')->row();
		}
		public function insertsms()
		{
		    $max=maxplus('tbl_sms','sid');	
		    $today=date('Y-m-d');
			
			if($this->session->userdata('org_id')=='')
			{
				$orgid='admin';
			}
			else
			{
				$orgid=$this->session->userdata('org_id');
			}
			$settings=$this->input->post('settings');
			$from=$this->input->post('from');
			$to=$this->input->post('to');
			$brand=decode($this->input->post('brand'));
			$model=decode($this->input->post('model'));
			$c3=count($to);
			
			for($k=0;$k<$c3;$k++)
			{
			$data1=array('sid' =>$max,
							 'org_id' =>$orgid,
							  'brand_id' =>$brand,
							   'model_id' =>$model,
							 'category' =>$settings[$k],
							 's_range' =>$from[$k],
							 'e_range'=>$to[$k],
							 'created_on'=>$today,
							 'modified_on'=>$today);
				$this->db->insert('tbl_sms',$data1);
			}
		}
		
		
		public function updatesms($id)
		{
		    //$max=maxplus('tbl_sms','sid');	
		    $today=date('Y-m-d');
			$id=decode($id);
			$arr=array('sid'=>$id);
			$brand=decode($this->input->post('brand'));
			$model=decode($this->input->post('model'));
			$settings=$this->input->post('settings');
			$from=$this->input->post('from');
			$to=$this->input->post('to');
			var_dump($to);
			$data1=array(
							
							 'category' =>$settings,
							 's_range' =>$from,
							 'e_range'=>$to,
							'brand_id' =>$brand,
							   'model_id' =>$model,
							 'modified_on'=>$today);
							 $this->db->where($arr);
				$this->db->update('tbl_sms',$data1);
			
		}
		
		public function deletesms()
	    {
		    $cid=$this->input->post('id');
		    $max=decode($cid);
		    $del0=array('sid'=>$max);
		    $this->db->where($del0);
			$this->db->delete('tbl_sms');
		}
		
		
	
		
}