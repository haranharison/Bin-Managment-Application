<style>
#vwitmdetls
{
	width:100%;
	 overflow-x:scroll;
}
label {
    font-size: 0.8rem;
    color: #000;
}
.mdl-data-table th {
    
    color:#000 !important;
}
.order_placing_wrap{
	
display:none;	
	}

				  hr {
						display: block;
						height: 1px;
						border: 0;
						border-top: 1px solid #008cd2;
						margin: 1em 0;
						padding: 0; 
					}
				  .addDynamicfield,.removeDynamicfield{
						    position: absolute;
							top: 10px;
							right: -52px;
							color: #0092d3;
							cursor:pointer;
							transition:opacity 0.2s;
							  -webkit-touch-callout: none; /* iOS Safari */
							-webkit-user-select: none; /* Safari */
							 -khtml-user-select: none; /* Konqueror HTML */
							   -moz-user-select: none; /* Firefox */
								-ms-user-select: none; /* Internet Explorer/Edge */
									user-select: none; /* Non-prefixed version, currently
														  supported by Chrome and Opera */
				  }
				   .addDynamicfield:hover,.removeDynamicfield:hover{
					   opacity:0.7;
				   }
				  .removeDynamicfield{
						color:#F30;  
				  }
                  .addDynamicfield i,.removeDynamicfield i{
					font-size: 35px;  
				  }
				  .removeDynamicfield i.removing{
					  animation:spin 2s linear infinite;
				  }
				  @keyframes spin{
					0%{ transform:rotate(0deg)}
					100%{transform:rotate(360deg)}  
				  }
				  .rembg{
					      background: rgba(255, 0, 0, 0.25); 
				  }
				  .input-field {
    position: relative;
     margin-top: 0px; 
}
#btnback{
display:none;	
	}
	.sales_ty input[type="text"] {
		    border-bottom: 2px solid #f00;
			color: #f00;
			font-weight: bold;
			letter-spacing: 0.9px;
		
		}
		.seltypes label{
			color:#f00;
			}
                  </style>
<!--start container-->
          <form name="frmfulldetails" id="frmfulldetails">
<div style="min-height:527px;" class="mer_search_wrap ">
          <div class="container">
            <div class="section">
              <!--Basic Form-->
    
              <div id="basic-form" class="section">
              <div class="col s12 m12 l6 " >
    				<div class="row">
                    <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnback" >Back
                                </button>
                    </div>
</div>
                <div class="row">
                <div class="col s12 m12 l6">
                    <div class="card-panel">
                    <h4 class="header2">Merchant Search</h4>
                     <div class="row">
                            <div class="input-field col s6" style="text-align: left;padding: 0px 0px;font-size: 15px;font-weight: 600;">
                            <?php $oid=$this->session->userdata('emp_id').date('ymdhis'); ?>
                              
                              <span > Order Number: <?php echo $oid?> </span>
                            </div>
                            <div class="input-field col s6" style="    text-align: right;padding: 0px 0px;font-size: 15px;font-weight: 600;;">
                              
                              <span for="first_name"> Date : <?php $oiddate=date('Y-m-d') ;echo $oiddate ?></span>
                            </div>
                          </div>
                          <input type="hidden" name="txtorderid" value="<?php echo $oid ?>" />
          <input type="hidden" name="txtorderdate" value="<?php echo $oiddate ?>" />
                      <h4 class="header2"></h4>
                      
                      <div class="row">
                        
                    <!--   <form role="form" name="frmsermerchant" id="frmsermerchant" method="post" >-->
                       
                         <div class="row" style="display:none;">
                            <div class="input-field col s12">
                              <input placeholder="Enter Merchant Number" name="mer_num" id="mer_num"  type="text" >
                        
                            </div>
                          </div>
                          <div class="row" >
                            <div class="input-field col s12">
                              <input placeholder="Merchant Name" name="mername" id="mername"  type="text" readonly="readonly" style="    border-bottom: 2px solid black;    color: black;    font-weight: bold;" >
                              <label for="first_name"> Merchant Name</label>
                            </div>
                          </div>
                       
                       
                          <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnsubmit">Submit
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                              </div>
                              <div class="row">
                             <div class="input-field col s12 seltypes" >
                              <select data-order="1" class="form-control form-control1 sales_ty" name="salestype" id="salestype">
                                    <option value="0"> Sales Type</option>
                                    
											<option value="1" >Order</option>
                                            <option value="2" >Sales</option>
										 
									</select>
                              <label for="first_name">Select Order Taking/Sales</label>
                            </div>
                        </div>
                    
                      </div>
                    </div>
                  </div>
                  <div class="col s12 m12 l6" id="vwdetls"></div>
                 <div class="col s12 m12 l6 merlist" >
				    <div class="card-panel">
                      <h4 class="header2">Merchant List</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:10% !important;text-align:center;">SN</th>
                          <th style="width:100% !important;text-align:left;">Merchant</th>
                          <th style="width:20% !important;">Action</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php if($merchant) { $i=1; foreach($merchant as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:10% !important;text-align:center;"><?php echo $i ?></td>
								<td style="width:100% !important;text-align:left;"><?php echo $val->merchantname?> </td>
								<td > 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" rel="<?php echo $val->merchantid_num;  ?>" data-name="<?php echo $val->merchantname;  ?>"  id="btnSlct">
										<i class="material-icons">check_circle</i>
									</a>
                                    
									 
                                
                                </td>
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
                  <!-- Form with placeholder -->
                  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
        <style>
        .seltypes{
		display:none;	
			}
        </style> 
      
             <!--<div class="row seltypes">
         
          
                <div class="col s12 m12 l12">
                    <div class="card-panel">
                  
                     <div class="row">
                    
                    <div class="input-field col s6" >
                              <select data-order="1" class="form-control form-control1 ch3" name="taxtype" id="taxtype">
                                    <option value="0"> Tax Type</option>
                                    
											<option value="1" >Same state sale</option>
                                            <option value="2" >Interstate</option>
										 
									</select>
                              <label for="first_name">Select Tax Type</label>
                            </div>-->
                            <!-- <div class="input-field col s6" >
                              <select data-order="1" class="form-control form-control1 " name="salestype" id="salestype">
                                    <option value="0"> Sales Type</option>
                                    
											<option value="1" >Order</option>
                                            <option value="2" >Sales</option>
										 
									</select>
                              <label for="first_name">Select Sales Type</label>
                            </div>
                           
                   
                     </div>
                     </div>
                     </div>
        </div>-->
        
          </div>
                
                   
        
        
        
        
        
        <!---------------------------------Order Placing Start---------------------------------------->
         
 
          

<!--start container-->
<div class="order_placing_wrap">

          <div class="container ">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                <!--<div class="col s12 m12 l4">
                    <div class="card-panel">
                      <h4 class="header2"> Order</h4>
                      <div class="row">
                       <form role="form" name="frmaddorder" id="frmaddorder" method="post" action="">
                       <div class="row arr">
                       <div class="input-field col s12" >
                              <select data-order="1" class="form-control form-control1 ch3" name="taxtype" id="taxtype">
                                    <option value="0"> Tax Type</option>
                                    
											<option value="1" >Same state sale</option>
                                            <option value="2" >Interstate</option>
										 
									</select>
                              <label for="first_name">Select Tax Type</label>
                            </div>
                            </div>
                         <div class="row arr">
                         
                            <div class="input-field col s6" >
                              <select data-order="1" class="form-control form-control1 ch1" name="selcat[]" id="selcat">
                                    <option value="0"> Product</option>
                                    	<?php foreach($products as $pro) { ?>
											<option value="<?php echo $pro->product_id ?>" ><?php echo $pro->product_name ?></option>
                                            <?php } ?>
										 
									</select>
                              <label for="first_name">Select Product</label>
                            </div>
                            <div class="input-field col s4"> 
                       
                              <input data-order="1" placeholder="Enter Quantity" name="qty[]" id="qty"  type="number" class="ch2"  value="0">
                              <label for="first_name">Quantity</label><a  class="addDynamicfield"><i class="material-icons">add_circle</i></a>
                             
                            </div>
                            
                               <input type="hidden" name="amt[]" id="amt" class="amt"  value="0" />  
                                <input type="hidden" name="dis[]" id="dis" class="dis"  value="0" />  
                                  <input type="hidden" name="gamt[]" id="gamt" class="gamt"  value="0" />  
                          </div>
<div class="row" aria-describedby="fieldfor new items" id="field-new-item">
                      		<div id="exist">
                            
                            </div>
                      </div>
                        <div class="row">
                            <div class="col s12 show-exist-sub-cat" id="show-exist-sub-cat"></div>
                        </div>    
                        <div class="row">
                     <!--  <div class="input-field col s3">
                              <input  name="tamount" id="tamount"  type="number" readonly placeholder="Amount" value="0">
                              <label for="first_name">Amount</label>
                              
                            </div>
                          </div>
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right " type="button" name="action" id="btnorder">Submit
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                        </form>
                      </div>
                    </div>
                  </div>-->
                  <div class="col s12 m12 l12">
                    <div class="card-panel">
                      <h4 class="header2">Product Details</h4>
                      <div class="row " id="vwitmdetls">
                      <style>
					  th {
    font-size: 13px !important;
    font-weight: bold;
}
.mdl-data-table td, .mdl-data-table th {
    padding: 0 10px 0px;
    text-align: right;
}
.mdl-data-table td {
    border: 1px solid rgba(0,0,0,.12);
    border-bottom: 1px solid rgba(0,0,0,.12);
    padding-top: 0px;
    vertical-align: middle;
	text-align:center;
}
.mdl-data-table th {
    border: 1px solid rgba(0,0,0,.12);
	text-align:center;
   
}
.netamts
{
	font-weight:bold;
	color:#F00;
	font-size:24px;
	margin-top:20px;
}
.salesdet{
	float: right;
display:none;	
	}
	.vwchqdet{
	display:none;	
		}
			.vwmodetype{
			display:none;	
				}
				.parttimeamt{
				display:none;	
					}
					.ch1{
						display:block !important;
					}
					#selcat
					{
						display:block !important;
					}
					#vwitmdetls .select-dropdown
					{
						display:none !important;
					}
					#vwitmdetls .caret
					{
						display:none !important;
					}
@media only screen and (max-width: 701px) {
 .netamts {
    font-weight: bold;
    color: #F00;
    font-size: 18px !important;
    margin-top: 20px;
}
td input.select-dropdown
{
	width:135px !important;
}
.qty
{
	width:40px !important;
}
}	
					  </style>
                        <table id="datatables" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:20px;text-align:center;">SN</th>
                          <th style="width:200px !important;">Item</th>
                          <th>MRP</th>
                           <th>Units</th>
                          <th style="width:75px;">Qty</th>
                           <th>Rate</th>
                            <th>Rate</br>(Inc tax)</th>
                          <th>Total</th>
                             <th style="width:75px;">Disc %</th>
                             <th>Disc</br> amt</th>
                              <th>Taxable </br>value</th>
                          <th class="s_state">CGST </br>rate</th>
                          <th class="s_state">CGST </br>amt</th>
                          <th class="s_state">SGST </br>rate</th>
                          <th class="s_state">SGST </br>amt</th>
                           <th class="i_state">IGST </br>rate</th>
                          <th class="i_state">IGST </br>amt</th>
                          <th>Net amt</th>
                         
                        </tr>
                      </thead>
                      <tbody id="addtr">
                    
                         
                          
							<tr id="itt">
								<td style="width:20px;text-align:center;"><span class="slno">1</span></td>
								<td style="width:200px !important;" >
                                  <div class="col s12">
                                <select style="text-align: center;" data-order="1" class="form-control form-control1 ch1" name="selcat[]" id="selcat" >
                                    <option value="0"> Product</option>
                                    	<?php foreach($products as $pro) { ?>
											<option value="<?php echo $pro->product_id ?>" ><?php echo $pro->product_name ?>                                           </option>
                                            <?php } ?>
										 
									</select>
                                    </div>
                                    </td>
                                	<td>
                                    <input type="hidden" name="txtmrp[]"  class="mrp" id="mrp"/>
                                    <label class="mrplabel" id="mrplabel">0</label>                                     
                                    </td>
                                    	<td >
                                         <input type="hidden" name="txtunit[]"  class="unit" id="unit"/>
                                    <label class="unitlabel" id="unitlabel">0</label>     
                                      </td>
                                        	<td style="width:75px;" >
                                              <div class="input-field col s12"> 
                                            <input style="text-align: center;" type="text" name="qty[]" id="qty" class="qty" value="0" />
                                            </div>
                                            
                                            
                                            
                                            
                                            </td>
                                            <td > 
                                            <input type="hidden" name="txtrate[]"  class="rate" id="rate"/>
                                    <label class="ratelabel" id="ratelabel">0</label> 
                                         </td>
                                        	<td> 
                                            <input type="hidden" name="txtrateinctax[]"  class="rateinctax" id="rateinctax"/>
                                    		<label class="rateinctaxlabel" id="rateinctaxlabel">0</label>
                                     </td>
                                            <td >
                                             <input type="hidden" name="txttotal[]"  class="total" id="total"/>
                                    <label class="totallabel" id="totallabel">0</label> 
                                     </td>
                                     
                                     
                                     
                                     
                                     
                                       <td style="width:75px;">
                                             <input style="text-align: center;" type="text" name="txtdiscountp[]"  class="discountp" id="discountp" value="0"/>
                                   
                                     </td>  <td >
                                             <input type="hidden" name="txtdiscounta[]"  class="discounta" id="discounta"/>
                                    <label class="discountalabel" id="discountalabel">0</label> 
                                     </td>  <td>
                                             <input type="hidden" name="txttaxpay[]"  class="taxpay" id="taxpay"/>
                                    <label class="taxpaylabel" id="taxpaylabel">0</label> 
                                     </td>
                                     
                                     
                                        	<td class="s_state">
                                              <input type="hidden" name="txtcgstrate[]"  class="cgstrate" id="cgstrate"/>
                                    <label class="cgstratelabel" id="cgstratelabel">0</label> 
                                             </td>
                                            <td class="s_state">
                                            <input type="hidden" name="txtcgstamt[]"  class="cgstamt" id="cgstamt"/>
                                    <label class="cgstamtlabel" id="cgstamtlabel">0</label> 
                                            
                                             </td>
                                        	<td class="s_state">
                                             <input type="hidden" name="txtsgstrate[]"  class="sgstrate" id="sgstrate"/>
                                    <label class="sgstratelabel" id="sgstratelabel">0</label> 
                                             </td>
                                            <td class="s_state">
                                            <input type="hidden" name="txtsgstamt[]"  class="sgstamt" id="sgstamt"/>
                                    <label class="sgstamtlabel" id="sgstamtlabel">0</label> 
                                             </td>
                                           
                                            <td class="i_state"><input type="hidden" name="txtigstrate[]"  class="igstrate" id="igstrate"/>
                                    <label class="igstratelabel" id="igstratelabel">0</label>  </td>
                                            <td class="i_state"><input type="hidden" name="txtigstamt[]"  class="igstamt" id="igstamt"/>
                                    <label class="igstamtlabel" id="igstamtlabel">0</label>  </td>
                                            
                                            <td >
                                            <input type="hidden" name="txtnetamt[]"  class="netamt" id="netamt"/>
                                    <label class="netamtlabel" id="netamtlabel">0</label> 
                                            </td>
                                            
							</tr>
				
                        
                      </tbody>
                    </table>
                      </div>
                      
                      
                        <div class="row" style="margin-top:20px;">
                    
                       <div class="input-field col s12 l6"  >
                         <input type="hidden" name="txttotbillamt"  class="txttotbillamt" id="txttotbillamt"/>
                                    <span class="netamts" id="netamts">  
                                     Total amount :00.00</span> 
                       </div>
                       <div class="salesdet input-field col s12 l6">
                       <div class="row" >
                       <div class="input-field col s12 l6"  >
                         
                                     <select style="text-align: center;" data-order="1" class="form-control form-control1" name="selmode" id="selmode">
                                    <option value="0"> Select Mode</option>
											<option value="1" >One time settlement  </option>
                                            <option value="2" >Part time settlement  </option>
                                            <option value="3" >Credit settlement  </option>
									</select>
                       </div> 
                       <div class="input-field col s12 l6 vwmodetype" >
                         
                                     <select style="text-align: center;" data-order="1" class="form-control form-control1" name="selmodetype" id="selmodetype">
                                    <option value="0"> Select type</option>
											<option value="1" >Cash  </option>
                                            <option value="2" >Cheque  </option>
									</select>
                       </div> 
                       </div>
                       <div class="vwchqdet">
                       <div class="row" >
                        <div class="input-field col s12 l6" >
                         
                                    <input  type="text" placeholder="Cheque number" id="chqnum" name="chqnum" >
                            
                          <label for="first_name">Cheque number</label>
                       </div> 
                        <div class="input-field col s12 l6" >
                         
                                     <input  type="text" placeholder="Bank" id="bank" name="bank" >
                            
                          <label for="first_name">Bank</label>
                       </div> 
                        <div class="input-field col s12 l6" >
                         
                                      <input  type="text" placeholder="Date" class="datepicker" id="chqdate" name="chqdate" >
                            
                          <label for="first_name">Date</label>
                       </div> 
                       
                       </div>
                       </div>
                       <div class="row">
                       <div class="input-field col s12 l6 parttimeamt"  >
                         
                                      <input  type="text" placeholder="Amount"  id="partialamt" name="partialamt" >
                            
                          <label for="first_name"> Amount</label>
                       </div>
                       <div class="input-field col s12 l6 parttimeamt"  >
                         
                                      <input  type="text" placeholder="Credit Amount"  id="creditamt" class="numval" name="creditamt"  readonly value="0">
                            
                          <label for="first_name">Credit Amount</label>
                       </div>
                       </div>
                       </div>
                       </div>
                       <div class="row" style="margin-top:20px;">
                       <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnaddord">Submit
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                       </div>
                      
                      
                     
                    </div>
                  </div>
                  <!-- Form with placeholder -->
                  
                </div> </form>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

</div>





        
        <!--------------------------------------Order Placing End----------------------------------->
        




<script type="text/javascript">


  $(document).on('click', '#btnSlct', function(){
		 
                var id=$(this).attr('rel'); 
				 var mname=$(this).attr('data-name'); 
              
				$('#mer_num').val(id); 
				$('#mername').val(mname); 
			
						
 /* swal({
                            title: "Are you sure?",
							   text: "Delete this Employee",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:"swal-delete",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          }).then(function(){
						  
			$('.overlay').css({'display':'flex'}); */
			//alert(id);
                               /*         $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>sales/selectMerchant",
					//redirect : "<?php echo ADMIN_PATH?>Merchant",

                                            data:"id="+id,

                                            success:function(data){ alert(data);
											//$('.overlay').css({'display':'none'});	
											
                                               // $(".loader").remove();
                                 location.reload() ;
                                 // 	document.location = redirect;
	customSwalFunD("Sucessfully!", "Sucessfully deleted!", "success")
                                            }
           
     

                                        });*/
					

				          //});

		
			  
        });



	
		
function placeorder(){
	
	
	 
	 document.getElementsByClassName('order_placing_wrap')[0].style.display="block";
	  document.getElementsByClassName('mer_search_wrap')[0].style.display="none";
	}
	
	
		function checkval(){
		 if($("#taxtype").val()!=0 && $("#salestype").val()!=0){
			 
			 $(".order_placing_wrap").css({'display':'block'});
			  if($('#salestype').val()==1){
				  $('.salesdet').css({'display':'none'});
				  }
				  else  if($('#salestype').val()==2){
				  $('.salesdet').css({'display':'block'});
				  }
			  
			  
			 if($('#taxtype').val()==1){
				$('.s_state').css({'display':'table-cell'});
				$('.i_state').css({'display':'none'});
				
				}
				else if($('#taxtype').val()==2){
				$('.s_state').css({'display':'none'});
				$('.i_state').css({'display':'table-cell'});
				
				}
				else {
				$('.s_state').css({'display':'none'});
				$('.i_state').css({'display':'none'});
				
				}
			 
			 
			 
			 
			 }
			 else{
				 $(".order_placing_wrap").css({'display':'none'});
				 }
			}
			
	
$(document).ready(function(e) {
	
		$('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15, // Creates a dropdown of 15 years to control year,
    today: 'Today',
    clear: 'Clear',
    close: 'Ok',
    closeOnSelect: false, // Close upon selecting a date,
	format: 'yyyy-mm-dd',
    container: undefined // ex. 'body' will append picker to body
  });
	
	
	$(document).on('change','#salestype', function(evt) {
	
		
 if($("#taxtype").val()==0){
	 
	 customSwalFunD('Error','Please select Tax type');
	 evt.preventDefault();
	 
	 }
else{
	checkval();
}
	 
});	

$(document).on('change','#taxtype', function(evt) {
	
	checkval();
	});
function checktype(){
	
	 if($("#selmodetype").val()==1){
		 
		 $(".vwchqdet").css({'display':'none'}); 
		 }
		else if($("#selmodetype").val()==2){
		 
		 $(".vwchqdet").css({'display':'block'}); 
		 }
	else{
		 $(".vwchqdet").css({'display':'none'}); 
		}
	
	}
$(document).on('change','#selmodetype', function() {
	//alert($("#selmodetype").val());
	checktype();
	
	})
/*	function vwpartialamount(){
		if( $("#selmode").val()==2 && $("#selmodetype").val()==1){
		 $(".parttimeamt").css({'display':'block'}); 
		  }
		else  if( $("#selmode").val()==2 && $("#selmodetype").val()==2){
		 $(".parttimeamt").css({'display':'block'}); 
		  }
		  else{
			  $(".parttimeamt").css({'display':'none'}); 
			  }
		}*/
		
		
		
	function checkcmode(){
		//alert($("#selmode").val()); 
		
		 if($("#selmode").val()==1 ){
		
		 $(".vwmodetype").css({'display':'block'}); 
		  $(".parttimeamt").css({'display':'none'}); 
		  
		 }
		else if( $("#selmode").val()==2){
		 
		 $(".vwmodetype").css({'display':'block'}); 
		  $(".parttimeamt").css({'display':'block'}); 
		 }
		
	else{
		 $(".vwmodetype").css({'display':'none'}); 
		  $(".vwchqdet").css({'display':'none'}); 
		  $(".parttimeamt").css({'display':'none'});
		  $('#selmodetype').val(0);
		  $('#selmodetype').material_select();
		  $('#selmodetype').trigger('contentChanged');
		}
		
		}
	$(document).on('change','#selmode', function() {
	//alert($("#selmodetype").val());
	//$('#selcat').material_select();
		//	$('#selcat').trigger('contentChanged');
	checkcmode();
	
	})
$(document).on('keyup','#partialamt', function() {
	//alert();
	if($('#txttotbillamt').val()!=''){
			if(parseInt($('#txttotbillamt').val())>=parseInt($('#partialamt').val())){
	var creditamtval=parseInt($('#txttotbillamt').val())-parseInt($('#partialamt').val())
			}
			else{
				customSwalFunD('Error','Credit amount should be less than or equal to total amt');
				$('#creditamt').val('');
				$('#partialamt').val('');
				}
	$('#creditamt').val(creditamtval);
	}
	else{
		event.preventDefault(); 
		 customSwalFunD('Error','Please Select Product');
		$('#creditamt').val('');
		
		
		}
	})

$(document).on('keypress','#partialamt', function(e) {	
			
				
				if($('#txttotbillamt').val()==''){
					event.preventDefault();
				}
				else{
				if ( event.keyCode == 46 || event.keyCode == 8 ) {//|| event.keyCode == 37	event.keyCode==37 for Percentage
				
							
				}
				 else {
            // Ensure that it is a number and stop the keypress
							if (event.keyCode < 48 || event.keyCode > 57) {
								event.preventDefault(); 
							}  
					 }
				}
				//return isNumber(event, this)
			});
	
		//$('#qty').val(0);
		
		
		$('.s_state').css({'display':'none'});
		$('.i_state').css({'display':'none'});
		$('#frmaddorder').on('change','.ch3', function(e) {
			
			//alert($(this).val())
			if($(this).val()!=''){
			if($(this).val()==1){
				$('.s_state').css({'display':'table-cell'});
				$('.i_state').css({'display':'none'});
				}
				else if($(this).val()==2){
				$('.s_state').css({'display':'none'});
				$('.i_state').css({'display':'table-cell'});
				
				}
				else {
				$('.s_state').css({'display':'none'});
				$('.i_state').css({'display':'none'});
				
				}
			}
			})
			function addrow(){
				
				
					var h='<tr id="itt"><td style="width:20px;text-align:center;"><span class="slno">1</span></td><td style="width:200px;" ><div class="col s12"><select style="text-align: center;" data-order="1" class="form-control form-control1 ch1" name="selcat[]" id="selcat"><option value="0"> Product</option><?php foreach($products as $prod) { ?><option value="<?php echo $prod->product_id ?>" ><?php echo $prod->product_name ?></option> <?php } ?></select> </div></td><td><input type="hidden" name="txtmrp[]"  class="mrp" id="mrp"/><label class="mrplabel" id="mrplabel">0</label></td><td ><input type="hidden" name="txtunit[]"  class="unit" id="unit"/><label class="unitlabel" id="unitlabel">0</label></td><td style="width:100px;" ><div class="input-field col s12"><input style="text-align: center;" type="text" name="qty[]" id="qty" class="qty" value="0" /></div></td> <td ><input type="hidden" name="txtrate[]"  class="rate" id="rate"/><label class="ratelabel" id="ratelabel">0</label></td><td><input type="hidden" name="txtrateinctax[]"  class="rateinctax" id="rateinctax"/><label class="rateinctaxlabel" id="rateinctaxlabel">0</label></td><td ><input type="hidden" name="txttotal[]"  class="total" id="total"/><label class="totallabel" id="totallabel">0</label></td><td ><input style="text-align: center;" type="text" name="txtdiscountp[]"  class="discountp" id="discountp" value="0"/></td>  <td ><input type="hidden" name="txtdiscounta[]"  class="discounta" id="discounta"/><label class="discountalabel" id="discountalabel">0</label></td>  <td><input type="hidden" name="txttaxpay[]"  class="taxpay" id="taxpay"/> <label class="taxpaylabel" id="taxpaylabel">0</label></td><td class="s_state"><input type="hidden" name="txtcgstrate[]"  class="cgstrate" id="cgstrate"/> <label class="cgstratelabel" id="cgstratelabel">0</label> </td><td class="s_state"><input type="hidden" name="txtcgstamt[]"  class="cgstamt" id="cgstamt"/><label class="cgstamtlabel" id="cgstamtlabel">0</label></td><td class="s_state"><input type="hidden" name="txtsgstrate[]"  class="sgstrate" id="sgstrate"/> <label class="sgstratelabel" id="sgstratelabel">0</label></td><td class="s_state"><input type="hidden" name="txtsgstamt[]"  class="sgstamt" id="sgstamt"/><label class="sgstamtlabel" id="sgstamtlabel">0</label></td><td class="i_state"><input type="hidden" name="txtigstrate[]"  class="igstrate" id="igstrate"/><label class="igstratelabel" id="igstratelabel">0</label>  </td><td class="i_state"><input type="hidden" name="txtigstamt[]"  class="igstamt" id="igstamt"/><label class="igstamtlabel" id="igstamtlabel">0</label></td><td ><input type="hidden" name="txtnetamt[]"  class="netamt" id="netamt"/><label class="netamtlabel" id="netamtlabel">0</label></td></tr>';
											
								$('#addtr').append(h);
				$('select').material_select();
				if($('#taxtype').val()==1){
				$('.s_state').css({'display':'table-cell'});
				$('.i_state').css({'display':'none'});
				}
				else if($('#taxtype').val()==2){
				$('.s_state').css({'display':'none'});
				$('.i_state').css({'display':'table-cell'});
				
				}
				else {
				$('.s_state').css({'display':'none'});
				$('.i_state').css({'display':'none'});
				
				}
				var x=document.querySelectorAll(".slno");
												for(i=0;i<x.length;i++){
													sl=parseInt(i)+1;
													//console.log(x[i]);
													x[i].innerHTML=sl;
													
													}
				
													
								nettot();					
												
													
				}
	function nettot(){
		var xt=document.querySelectorAll("#netamt");
				var tot=0;
				
												for(i=0;i<parseInt(xt.length)-1;i++){
													tot=(parseFloat(tot)+parseFloat(xt[i].value)).toFixed(2);
													 var text='Total Amount : Rs'+tot;
													$('#netamts').text(text);
													
													$('#txttotbillamt').val(tot);
												
													}
	}
	function rowcalc(elm){
		
		var rate=parseFloat(elm.find('#rate').val());
		var qty=parseFloat(elm.find('#qty').val());
		var tax=parseFloat(elm.find('#igstrate').val());
		var total=parseFloat(rate)*parseFloat(qty);
		elm.find('#totallabel').text(parseFloat(total).toFixed(2));
		elm.find('#total').val(parseFloat(total).toFixed(2));
		var singletax=parseFloat((parseFloat(rate)*parseFloat(tax))/100).toFixed(2);
		var rateins=parseFloat(rate)+parseFloat(singletax);
		elm.find('#rateinctaxlabel').text(parseFloat(rateins).toFixed(2));
		elm.find('#rateinctax').val(parseFloat(rateins).toFixed(2));
		var disc=parseFloat(elm.find('#discountp').val());
		var discamt=((parseFloat(total)*parseFloat(disc))/100).toFixed(2);
		elm.find('#discountalabel').text(parseFloat(discamt).toFixed(2));
		elm.find('#discounta').val(parseFloat(discamt).toFixed(2));
		var taxamt=(parseFloat(total)-parseFloat(discamt)).toFixed(2);
		elm.find('#taxpaylabel').text(parseFloat(taxamt).toFixed(2));
		elm.find('#taxpay').val(parseFloat(taxamt).toFixed(2));
		var taxtotal=((parseFloat(taxamt)*parseFloat(tax))/100).toFixed(2);
		elm.find('#igstamtlabel').text(parseFloat(taxtotal).toFixed(2));
		elm.find('#igstamt').val(parseFloat(taxtotal).toFixed(2));
		elm.find('#cgstamtlabel').text((parseFloat(taxtotal)/2).toFixed(2));
		elm.find('#cgstamt').val((parseFloat(taxtotal)/2).toFixed(2));
		elm.find('#cgstamtrate').val((parseFloat(taxtotal)/2).toFixed(2));
		elm.find('#sgstamtlabel').text((parseFloat(taxtotal)/2).toFixed(2));
		elm.find('#sgstamt').val((parseFloat(taxtotal)/2).toFixed(2));
		elm.find('#sgstamtrate').val((parseFloat(taxtotal)/2).toFixed(2));
		var netamt=(parseFloat(taxamt)+parseFloat(taxtotal)).toFixed(2);
		elm.find('#netamtlabel').text(parseFloat(netamt).toFixed(2));
		elm.find('#netamt').val(parseFloat(netamt).toFixed(2));
	}
	
	$(document).on('keyup','.qty', function(e) {
		 var elm=$(this).parent().parent().parent();
		 var proq=$(this).val();
		  var proo=elm.find('#selcat').val();
		  $('.overlay').css({'display':'flex'});
		//  var eproval=checkprostock(proq,proo);
		     $.ajax({
                                            type:"post",
                       						url: "<?php echo ADMIN_PATH ?>sales/checkprostock",
                                            data:"proq="+proq+"&proo="+proo,
                                            success:function(data){// alert(data);
											$('.overlay').css({'display':'none'});
											//data=JSON.parse(data);
											if(data==1){
			 								 customSwalFunD("Alert", "Not enough qty");
												elm.find('#qty').val(0);
											}
											else if(data==2){
			 								 customSwalFunD("Alert", "Entered qty is higher than stock on hand");
											elm.find('#qty').val(0);
											// console.log(elm.find('#qty').val());
											 rowcalc(elm);
		 									nettot();
											}
											else{
													rowcalc(elm);
		 											nettot();
												}
                                            }

                                        });
		
	});
	$(document).on('keyup','.discountp', function(e) {
		 var elm=$(this).parent().parent();
		 rowcalc(elm);
		 	nettot();
	});
	$(document).on('change','.ch1', function(e) {
		
		$('.overlay').css({'display':'flex'});
		//console.log(1);
//$('#tamount').val(0);
//	var alltot=0;
	//var qty=	$(this).parent().parent().find('#qty').val();
	//console.log(isNaN(parseInt(qty)));	
	//if(isNaN(parseInt(qty))){
	//	qty=0;
	//	}
	//var corderid=$(this).attr('data-order');
	
	//	alert(corderid);
		// console.log($(this).val());
		 if($(this).val()!=''){
		 id=$(this).val();
		 var elm=$(this).parent().parent().parent().parent();
		// $('.ch1').parent().parent().parent().children('.s3').children('#qty')
		//alert(elm.text());
		   $.ajax({
                                            type:"post",
                       						url: "<?php echo ADMIN_PATH ?>sales/selproamount",
                                            data:"id="+id,
                                            success:function(data){
												$('.overlay').css({'display':'none'});
												// alert(data);
											//console.log(data);
												data=JSON.parse(data);
											elm.find('#mrplabel').text(parseFloat(data.mrp).toFixed(2));
											elm.find('#mrp').val(parseFloat(data.mrp).toFixed(2));
											elm.find('#unitlabel').text(data.measure_name);
											elm.find('#unit').val(data.measure_name);
											elm.find('#ratelabel').text(parseFloat(data.s_amt).toFixed(2));
											elm.find('#rate').val(parseFloat(data.s_amt).toFixed(2));
											elm.find('#cgstratelabel').text((parseFloat(data.p_type_per)/2).toFixed(2)+'%');
											elm.find('#cgstrate').val((parseFloat(data.p_type_per)/2).toFixed(2));
											elm.find('#sgstratelabel').text((parseFloat(data.p_type_per)/2).toFixed(2)+'%');
											elm.find('#sgstrate').val((parseFloat(data.p_type_per)/2).toFixed(2));
											elm.find('#igstratelabel').text(parseFloat(data.p_type_per).toFixed(2)+'%');
											elm.find('#igstrate').val(parseFloat(data.p_type_per).toFixed(2));
											elm.find('#qty').val(1);
											rowcalc(elm);
										var xs=document.querySelectorAll("#selcat");
				console.log(xs[0].value);					
												
													if(xs[parseInt(xs.length)-1].value!=0){
														addrow();
														
														}
		
													
                                            }

                                        });
		 }
		 })
		 
	$('#frmaddorder').on('keyup','.ch2', function(e) {
	
		
	var id=	$(this).parent().parent().find('select').val();
		//	console.log(id);
			
		var qty=	$(this).val();
		var corderid=$(this).attr('data-order');
		//alert(corderid);
$('#tamount').val(0);
	var alltot=0;
		 if(id!=''){
		 var elm=$(this).parent().parent();
	
		   $.ajax({
                                            type:"post",
                       						url: "<?php echo ADMIN_PATH ?>sales/selproamount",
                                            data:"id="+id,
                                            success:function(data){ //alert(data);
											data=JSON.parse(data);
												orderdetails(data,corderid,qty);
											/*var pamt=qty;
											console.log(qty)
											tpamt=parseInt(pamt)*parseInt(data.g_amt);
											elm.find('#amt').val(tpamt);
										//	elm.find('#dis').val(data.p_discount);
											elm.find('#gamt').val(data.g_amt);
												var x=document.querySelectorAll("#amt");
										
												for(i=0;i<x.length;i++){
													
													alltot=parseInt(alltot)+parseInt(x[i].value);
													
													}
											$('#tamount').val(alltot);		*/
													
                                            }

                                        });
		 }
		 
			
		});
	
	
		$count=2; 
	
	 $(".addDynamicfield").click(function(e) {
		 //alert()
		
	
		 
		 
			$contentappenTo=$('#field-new-item');
			$html='';
			$html+='<div class="dynamicaddfield arr">';
			$html+='<div class="col s5 " aria-controls="'+$count+'">';
			$html+='<select data-order="'+$count+'" class="form-control form-control1 ch1" name="selcat[]"><option value="0"> Product</option><?php foreach($products as $pro) { ?><option value="<?php echo $pro->product_id ?>"><?php echo $pro->product_name ?></option><?php } ?></select><label for="first_name">Select Product</label></div>';
    		$html+='<div class="input-field col s3"><input data-order="'+$count+'" name="qty[]" id="qty"  type="number" class="ch2" value="0"><label for="first_name"  class="active">Quantity</label><a data-order="'+$count+'"  class="removeDynamicfield"><i class="material-icons">close</i></a></div>';
            $html+='<input type="hidden" name="amt[]" id="amt" class="amt" value="0"/> <input type="hidden" name="dis[]" id="dis" class="dis"  value="0" /><input type="hidden" name="gamt[]" id="gamt" class="gamt"  value="0" /></div><div class="clearfix"></div></div>';
			$contentappenTo.append($html);
			$('.dynamicaddfield').fadeIn(1500);
			//console.log($( 'div[ area-controls=' + $count + ']' ));//.fadeIn(1000);
			$count++;
			//	$('[area-controls='$count]).fadeIn(1000);
			//$('area-controls'+$count).fadeIn(1000);
			$('select').material_select();
			$('#selcat').trigger('contentChanged');
			//$('#selcat').trigger('contentChanged');
	 });
	 //Remove clicked Field
	 $(document).on('click','.removeDynamicfield', function(e) {
		 var corderid=$(this).attr('data-order');
		// alert(corderid);
		$(this).children().addClass('removing').html('refresh')
		 $elm=$(this).parent().parent();
		 
			//$elm.addClass('rembg');
		 setTimeout(function(){
			  $elm.slideUp().delay(300).remove();
			$('#ord_'+corderid).remove();
				var x=document.querySelectorAll(".slno");
				//	console.log(x[0]);					
												for(i=0;i<x.length;i++){
													sl=parseInt(i)+1;
													//console.log(x[i]);
													x[i].innerHTML=sl;
													
													}
		/*	 var alltot=0;
			 var x=document.querySelectorAll("#amt");
										
												for(i=0;i<x.length;i++){
													console.log(x[i].value)
													alltot=parseInt(alltot)+parseInt(x[i].value);
													
													}
													alert(alltot);
											$('#tamount').val(alltot);	*/
		 },300)
	 });
	
	//btnback
	 /* $("#btnback").click(function(e) {

	   			$(".order_placing_wrap").css({'display':'none'});
			   $(".mer_search_wrap").css({'display':'block'});
		  
		  })*/
		   $("#btnback").click(function(e) {

	   			$(".order_placing_wrap").css({'display':'none'});
			  // $(".mer_search_wrap").css({'display':'block'});
			   	$('.merlist').css({'display':'block'});
				 	$('#vwdetls').css({'display':'none'});
					$('.seltypes').css({'display':'none'});
					$('#btnsubmit').show();
						$('#btnback').css({'display':'none'});
				
		  
		  })
	
   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
		//alert($("#mer_num").val());
		$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>sales/merchantsearch";
  			//var redirect = "<?php echo ADMIN_PATH?>sales";
  			var form = document.forms.namedItem("frmfulldetails");                        
			var oData = new FormData(document.forms.namedItem("frmfulldetails"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
				$('.overlay').css({'display':'none'});
				if(oReq.responseText!=1)
				{
			$('#vwdetls').css({'display':'block'});		
		$('#btnback').css({'display':'block'});
		$('#vwdetls').html(oReq.responseText);
		$('.seltypes').css({'display':'block'});
		$('.merlist').css({'display':'none'});
		
		$('#btnsubmit').hide();
				}else{
					
					 customSwalFunD("Alert", "Merchant not found", "success")
				}
					 }
                oReq.send(oData);
               // ev.preventDefault();   
			
   			});
	//----end insert--------------------//	
	
	 	/* $("#btnorder").click(function(e) {
		
		$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>sales/addorder";
  			//var redirect = "<?php echo ADMIN_PATH?>sales";
  			var form = document.forms.namedItem("frmaddorder");                        
			var oData = new FormData(document.forms.namedItem("frmaddorder"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
				$('.overlay').css({'display':'none'});	
		$('#vwitmdetls').html(oReq.responseText);
					 }
                oReq.send(oData);
               // ev.preventDefault();   
			
   			});
	*/
	 $("#btnaddord").click(function(e) {
		
		$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>sales/addorder";
  			//var redirect = "<?php echo ADMIN_PATH?>sales";
  			var form = document.forms.namedItem("frmfulldetails");                        
			var oData = new FormData(document.forms.namedItem("frmfulldetails"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
				$('.overlay').css({'display':'none'});	
	//	$('#vwitmdetls').html(oReq.responseText);
	if(oReq.responseText==1){
		customSwalFunD("Success", "Added");
		location.reload();
		
		}
		else if(oReq.responseText==2){
		customSwalFunD("Alert", "Credit amount Exceed Credit limit ");
		
		
		}
		else{
			var arr=JSON.parse(oReq.responseText);
			arrlist=arr.join(",");
			//console.log(arrlist);
				if(arr.length==1){
				 customSwalFunD("Alert", "Item "+arrlist+" is not in stock or low qty");
				}
				
				else{
					customSwalFunD("Alert", "Items "+arrlist+" are not in stock or low qty");
					
					}
					
		    }
		 }
         oReq.send(oData);
               // ev.preventDefault();   
			
   			});
	
		
});
</script>










