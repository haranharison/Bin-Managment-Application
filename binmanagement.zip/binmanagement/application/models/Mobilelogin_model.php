<?php
class Mobilelogin_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
      
	 public function mobilelogin($id){
		
		 // $user    = $this->input->post('email');
        // $password  =  $this->input->post('password');
		 //$pass=do_hash($password,'md5');
		 $array=array('emp_id'=>$id,'status'=>0);
                $this->db->where($array);
				$query = $this->db->get('tbl_login');
				$result=$query->row();
				
				if($query->num_rows() >0){
						$emp_id=$result->emp_id;
						$org_id=$result->org_id;
						$usergroup=$result->usergroup;
						$user= $result->username;
						$this->session->set_userdata(array(
										'loggedIn'=> true,
										'username' =>$user,
										'emp_id' =>$emp_id,
										'org_id' =>$org_id,
										'usergroup'=>$usergroup
								));
						header('location:'.SITE_PATH.'index/home');
			}else{
				//echo 2;
				}
				
		}  
	  
	  
	  
	
	  
	  
	    
}