<?php
class Sms_model extends CI_Model 
{	
    public function __construct()
	{
        $this->load->database(); 
    }	
		
		
		
		public function send_sms()
		{
			$org_id= $this->session->userdata('org_id');
			$message= $this->input->post('txtsmsmsg');
			$array=array('org_id'=>$org_id,'status'=>0);
			$this->db->where($array);
			$this->db->select('name,mobile');
			$rows=$this->db->get('tbl_servicereg');
			$result=$rows->result();
			$c=count($result);
			for($i=0;$i<$c;$i++)
	{
			$phone=$result[$i]->mobile;
			
			mobilesms($phone,$message);
			 echo json_encode($phone);

		}
			
		//var_dump($result);	
		}
		
		
		
	
		
}