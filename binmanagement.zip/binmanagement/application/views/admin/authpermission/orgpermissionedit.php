

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2"> Organisation Permission</h4>
                      <div class="row">
                       <form role="form" name="frmaddgroup" action="" method="post">
                          <div class="row">
                            <div class="input-field col s12">
                               <label for="first_name"> Organisation Permission</label>
                            <!--  <input placeholder="Enter Usergroup" name="group" id="group" type="text">-->
                            </div>
                            </div>
                            <input type="hidden" name="txtid" value="<?php echo encode($details->o_maxid); ?>" id="txtid" />
                             <div class="row">
                               <?php if($details->permission) {$farr=explode(",",$details->permission); } ?>
                            <div class="input-field col s12">
                              <select multiple="multiple" id="selper" name="selper">
                             
                                <option disabled="disabled" value="0">Choose permission....</option>  
                                <option value="1"  <?php if($details->permission){if(in_array(1,$farr)) { echo 'selected';} }?>>Category</option>
                                <option value="2"  <?php if($details->permission){if(in_array(2,$farr)) { echo 'selected';} }?>>Sub Category</option>
                                 <option value="3"  <?php if($details->permission){if(in_array(3,$farr)) { echo 'selected';} }?>>Manufacture</option>
                                 <option value="4"  <?php if($details->permission){if(in_array(4,$farr)) { echo 'selected';} }?>>Tax Type</option>
                                 <option value="5"  <?php if($details->permission){if(in_array(5,$farr)) { echo 'selected';} }?>>UOM ( Unit of Measurement)</option>
                                  <option value="6"  <?php if($details->permission){if(in_array(6,$farr)) { echo 'selected';} }?>>User Group</option> 
                                   <option value="7"  <?php if($details->permission){if(in_array(7,$farr)) { echo 'selected';} }?>>Employee Registration</option> 
                            	  <option value="9"  <?php if($details->permission){if(in_array(9,$farr)) { echo 'selected';} }?>> Education </option>
                           		   <option value="10"  <?php if($details->permission){if(in_array(10,$farr)) { echo 'selected';} }?>> Designation </option>
                            	  <option value="11"  <?php if($details->permission){if(in_array(11,$farr)) { echo 'selected';} }?>>Product List</option>
                         	      <option value="12"  <?php if($details->permission){if(in_array(12,$farr)) { echo 'selected';} }?>>New Product</option>
                          	      <option value="13"  <?php if($details->permission){if(in_array(13,$farr)) { echo 'selected';} }?>>Area</option>
                          	 	   <option value="14"  <?php if($details->permission){if(in_array(14,$farr)) { echo 'selected';} }?>>Employee List</option>
                          		  <option value="15"  <?php if($details->permission){if(in_array(15,$farr)) { echo 'selected';} }?>>Bin Management</option>
                        	    <!--<option value="17"  <?php if($details->permission){if(in_array(17,$farr)) { echo 'selected';} }?>>New Merchant </option>
                         	   <option value="18"  <?php if($details->permission){if(in_array(18,$farr)) { echo 'selected';} }?>>Attendance</option>
                         		   <option value="19"  <?php if($details->permission){if(in_array(19,$farr)) { echo 'selected';} }?>>Damaged Product</option>
                         	    <!--<option value="20"  <?php if($details->permission){if(in_array(20,$farr)) { echo 'selected';} }?>>Enquiry Form </option>-->
                         	   <option value="21"  <?php if($details->permission){if(in_array(21,$farr)) { echo 'selected';} }?>>Service Return </option>
                         	  <!-- <option value="22"  <?php if($details->permission){if(in_array(22,$farr)) { echo 'selected';} }?>>Cash Collection</option>
                           <option value="23"  <?php if($details->permission){if(in_array(23,$farr)) { echo 'selected';} }?>>Date Vice Damaged Product Report</option>
                            <option value="24"  <?php if($details->permission){if(in_array(24,$farr)) { echo 'selected';} }?>>Date Vice Collection Report</option>
                             <option value="25"  <?php if($details->permission){if(in_array(25,$farr)) { echo 'selected';} }?>>Employee Vice Damaged Product Report</option>-->-->
                              <!--<option value="26"  <?php if($details->permission){if(in_array(26,$farr)) { echo 'selected';} }?>>Employee Vice Collection Report</option>
                               <option value="27"  <?php if($details->permission){if(in_array(27,$farr)) { echo 'selected';} }?>>My Damaged Product Report</option>-->
                                <!--<option value="28"  <?php if($details->permission){if(in_array(28,$farr)) { echo 'selected';} }?>>My Collection Report</option>
                                 <option value="29"  <?php if($details->permission){if(in_array(29,$farr)) { echo 'selected';} }?>>Current Location</option>
                                  <option value="30"  <?php if($details->permission){if(in_array(30,$farr)) { echo 'selected';} }?>>Route History</option>
                                      <option value="31"  <?php if($details->permission){if(in_array(31,$farr)) { echo 'selected';} }?>>service</option>
                              <option value="32" <?php if($details->permission){if(in_array(32,$farr)) { echo 'selected';} }?>>Advertisement</option>-->



 <!--note:-->

<?php /*?><option value="33" <?php if($details->permission){if(in_array(33,$farr)) { echo 'selected';} }?>>Services</option>
                               <option value="34" <?php if($details->permission){if(in_array(34,$farr)) { echo 'selected';} }?>>Service Amenity</option>
                               <option value="35" <?php if($details->permission){if(in_array(35,$farr)) { echo 'selected';} }?>>Service Terms & Condition</option>
                               <option value="36" <?php if($details->permission){if(in_array(36,$farr)) { echo 'selected';} }?>>Service Jobs</option>
                               <option value="37" <?php if($details->permission){if(in_array(37,$farr)) { echo 'selected';} }?>>Service User Registration</option>
                               <option value="38" <?php if($details->permission){if(in_array(38,$farr)) { echo 'selected';} }?>>Driver Assigning</option>
                               <option value="39" <?php if($details->permission){if(in_array(39,$farr)) { echo 'selected';} }?>>Sms Settings</option>
							 <option value="40" <?php if($details->permission){if(in_array(40,$farr)) { echo 'selected';} }?>>Fare Settings</option>
                                 <option value="41" <?php if($details->permission){if(in_array(41,$farr)) { echo 'selected';} }?>>Trip Sheet</option><?php */?>
                                 

                                 </select>
                                   <input type="hidden" name="txthper" id="txthper" />
                           
                            </div>
                          </div>
                         <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnsubmit">Update
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  <div class="col s12 m6 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Organisations</h4>
                      <div class="row">
						
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
						  <thead>
							  <tr class="text-center">
								  <th style="width:50px;">Sl.no</th>
								 <!-- <th>Shop name</th>-->
                                   <th style="text-align:left;">Organisation name</th>
                                    <th style="text-align:left;">Action</th>
								  <!--<th>Edit</th>
                                  
                                  <th>Delete</th>-->
							  </tr>
						  </thead>   
						  <tbody>
                          
                          
                           <?php  if($allorg) { $i=1; foreach($allorg as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:50px;text-align:center;"><?php echo $i ?></td>
                                    	<td style="text-align:left;"><?php echo $val->org_name?> </td>
								      <td  style="width:100px;text-align:right;">
								
									<a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH?>Organisation/orgedit/<?php echo encode($val->org_maxid);?>">
										<i class="material-icons">mode_edit</i>
									</a>
                               
									<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange btndlt"  id="btndelt"rel="<?php echo encode($val->org_maxid);?>">
										<i class="material-icons">delete</i>
									</a>
								</td>
							</tr>
					<?php $i=$i+1;}}?>
							
						
							
							
						  </tbody>
					  </table>   
						
								
								
							
						
				</div>
                    </div>
                  </div>
                  <!-- Form with placeholder -->
                  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->





<script type="text/javascript">

$(document).ready(function(e) {
	
   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			//alert(1);
				$('#txthper').val($('#selper').val());
			var e=validation();
			if(e==0){
				$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>department/updatepermission2";
  			var redirect = "<?php echo ADMIN_PATH?>department";
  			var form = document.forms.namedItem("frmaddgroup");                        
			var oData = new FormData(document.forms.namedItem("frmaddgroup"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) {//console.log(oReq.responseText);
					$('.overlay').css({'display':'none'});
				 if(oReq.responseText==1){
					// alert("Exist");
					customSwalFunD(" Already Exist!", "Exist!", "error")
					  //alert("Exist");
					 }
					 else
					 {
						 customSwalFunD("Sucessfully!", "Permission Added!", "success")
 				 document.location = redirect;
					 }
					
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	/*$('label').removeClass('labelerror');
$('#txttax').parent().children('label').addClass('labelerror');
*/	function validation(){

        error=0;

        $('input').removeClass('errors');
		$('label').removeClass('labelerror');
        $('select').removeClass('errors');

            var values = {
                                    'per':$('#selper').val(),
                                 }

       if(values.per == 0){
			 $('#selper').parent().children('.select-dropdown').addClass('errors');
			$('#selper').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
	
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmncat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
	
	
	
	// ---------- < Delete Category   > ---------- //
	
	   $(document).on('click', '#btndelt', function(){
                var id=$(this).attr('rel');  
 swal({
                             title: "Are you sure?",
							   text: "Delete this organisation",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:"swal-delete",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          }).then(function(){
						  
			$('.overlay').css({'display':'flex'});
			//alert(id);
                                        $.ajax({

                                            type:"post",
                        					url: "<?php echo ADMIN_PATH ?>Organisation/deleteorganisation",
                                            data:"id="+id,
                                            success:function(data){//alert(data);
											$('.overlay').css({'display':'none'});	
											document.location = "<?php echo ADMIN_PATH?>Organisation";
											customSwalFunD("Sucess", "Sucessfully deleted!", "success")
                                            }
                                        });
				          });
			  
        });
		// ---------- < Delete Category ENDS > ----------
	
});
</script>
  
    





    
    
    
    
    
    
    
    
    

