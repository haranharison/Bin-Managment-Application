<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Smssettings extends CI_Controller 
{
	 function __construct()
	 {
		parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Smssettings_model','model');
	 }	
		 public function index()
		{}
	
	public function deletesms()
	{
		$this->model->deletesms();
	}
	public function smssettings()
		{
			$data['brands']=$this->model->getbrand();
			$data['menu']='services';
			$data['submenu']='sservices';
			$data['service']=0;
			
			$data['sms']=$this->model->getsms();
			//$data['services']=$this->model->getservicereg();
			$this->load->view('admin/header',$data);
			$this->load->view('admin/services/sms');
			$this->load->view('admin/footer');
		}
		public function get_model()
	{
		$this->model->get_model();	
	}
		 public function editsms($id)
		{
			$data['menu']='services';
			$data['submenu']='sservices';
			$data['service']=0;
						$data['sms']=$this->model->getsms();

			$data['brands']=$this->model->getbrand();	
		$data['model']=$this->model->getallmodel();
			$data['val']=$this->model->getsms1($id);
			//$data['services']=$this->model->getservicereg();
			$this->load->view('admin/header',$data);
			$this->load->view('admin/services/editsms');
			$this->load->view('admin/footer');
		}
		public function insertsms()
	{
		$this->model->insertsms();	
	}
	public function updatesms($id)
	{
		$this->model->updatesms($id);	
	}
}

