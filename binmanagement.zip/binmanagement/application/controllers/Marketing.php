<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Marketing extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
	$this->load->model('Marketing_model','model');
	 }	
	 public function index()
	{
		$this->load->model('Notification_model');
		$data['menu']='marketing';
		$data['submenu']='enquiry';
		$data['status']=$this->model->getstatus();
		$data['mainmarketing']=$this->model->getmainmarketing();
		$data['marketing']=$this->model->getmarketing();
		$data['notification']=$this->Notification_model->notification();
		//var_dump($data['notification']);
		$this->load->view('admin/header',$data);
		$this->load->view('admin/marketing/marketingadd',$data);
		$this->load->view('admin/footer');
	}
	public function addmarketing()
	{
		$this->model->addmarketing();	
	}
	public function deleteMarketing(){
		//echo "dfgf";
		$this->model->deleteMarketing();
		}
	public function maredit($id=false){
		$mid=decode($id);
		$data['menu']='marketing';
		$data['submenu']='enquiry';
		$data['status']=$this->model->getstatus();
		$data['edit']=$this->model->editmarketing($mid);
		$data['marketing']=$this->model->getmarketing();
		$this->load->view('admin/header',$data);
		$this->load->view('admin/marketing/marketingedit',$data);
		$this->load->view('admin/footer'); 
		}
	public function updatemarketing(){
		$this->model->updatemarketing();	
	}
	public function newstatus(){
		$this->model->insertnew();	
	}
	
	
	public function getnewstatus(){
	$this->model->getnewstatus();
	
	}
	public function changevwstatus(){
	$this->model->changevwstatus();
	
	}
	
	
	
	/*public function addmenu(){
	$this->model->addmenu();	
	}
	public function editCategories($id=false){
		$data['edit']=$this->model->editcategory($id);
		$this->load->view('admin/header');
		$this->load->view('admin/category/edit',$data);
		$this->load->view('admin/footer');
		}
		
	public function updatemenu(){
		$this->model->updatemenu();	
	}/*

	public function deleteMenu(){
		
		$this->model->deleteMenu();
		}
	
	public function deleteCategories($id=false){
		//echo $id;
		$this->model->deleteCategories($id);
		}*/
//product edit page*/
	
}

