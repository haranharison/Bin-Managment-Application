

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">New Usergroup</h4>
                      <div class="row">
                       <form role="form" name="frmaddgroup" action="" method="post">
                          <div class="row">
                            <div class="input-field col s12">
                              <input placeholder="Enter Usergroup" name="group" id="group" type="text">
                              <label for="first_name">New Usergroup</label>
                            </div>
                          </div>
                         <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnsubmit">Submit
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Usergroup</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:10px;text-align:left;">SN</th>
                          <th style="text-align:left;">Usergroup</th>
                          <th style="text-align:left;">Action</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                       
                            <?php  if($group)   { $i=1; foreach($group as $val) {?>                          
							<tr>
								<td style="width:10px;text-align:left;"><?php echo $i ?></td>
								<td style="text-align:left;"><?php echo $val->	usergroup_name?> </td>
								<td style="text-align:left;"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>usergroup/editgroup/<?php echo encode($val->usergroup_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->usergroup_id);?>" >
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
				
                        <?php $i=$i+1; }}?>
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
                  <!-- Form with placeholder -->
                  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->





<script type="text/javascript">

$(document).ready(function(e) {
	
   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			//alert(1);
			var e=validation();
			if(e==0){
				$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>usergroup/addgroup";
  			var redirect = "<?php echo ADMIN_PATH?>usergroup/permission";
  			var form = document.forms.namedItem("frmaddgroup");                        
			var oData = new FormData(document.forms.namedItem("frmaddgroup"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) {//console.log(oReq.responseText);
					$('.overlay').css({'display':'none'});
				 if(oReq.responseText=='ex'){
					// alert("Exist");
					customSwalFunD("Area Already Exist!", "Exist!", "error")
					  //alert("Exist");
					 }
					 else
					 {
						 customSwalFunD("Sucess!", "Sucessfully Added!", "success")
 					 document.location = redirect;
					 }
					
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	/*$('label').removeClass('labelerror');
$('#txttax').parent().children('label').addClass('labelerror');
*/	function validation(){

        error=0;

        $('input').removeClass('errors');
		$('label').removeClass('labelerror');
        $('select').removeClass('errors');

            var values = {
                                    'group':$('#group').val(),
                                 }

        if(values.group == ''){
			
			  $('#group').addClass('errors');
              $('#group').attr("placeholder", "Please enter Usergroup.");
			  $('#group').parent().children('label').addClass('labelerror');
		 error=1;
             } 
	
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmncat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
	
	
	
	// ---------- < Delete Category   > ---------- //
		    $(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
					
 swal({
                            title: "Are you sure?",
							   text: "Delete this Usergroup",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:"swal-delete",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          }).then(function(){
						  
						  
			$('.overlay').css({'display':'flex'});
			
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>usergroup/deletegroup",
					//	 redirect : "<?php echo ADMIN_PATH?>category",

                                            data:"id="+id,

                                            success:function(data){ //alert(data);
												
										$('.overlay').css({'display':'none'});	
                                               // $(".loader").remove();
                         location.reload() ;
                                 // 	document.location = redirect;
	customSwalFunD("Sucess!", "Sucessfully deleted!", "success")
                                            }
                                  });
				          });
       });
		// ---------- < Delete Category ENDS > ----------
	
});
</script>
  
    





    
    
    
    
    
    
    
    
    

