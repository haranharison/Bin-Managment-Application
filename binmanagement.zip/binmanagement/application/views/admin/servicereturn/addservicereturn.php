

  <style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
	float:right;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
.file-field .btn {
        float: right;
    position: relative;
}
/*.vname{
display:none;	
	}*/
	#vmid{
display:none;	
	}
	#txtpartgst:focus {
    outline: none;
}
  .addDynamicfield,.removeDynamicfield{
						    position: absolute;
							top: 16px;
							right: -10px;
							padding:0px;
							color: #0092d3;
							cursor:pointer;
							opacity:0.7;
							transition:opacity 0.2s;
							  -webkit-touch-callout: none; /* iOS Safari */
							-webkit-user-select: none; /* Safari */
							 -khtml-user-select: none; /* Konqueror HTML */
							   -moz-user-select: none; /* Firefox */
								-ms-user-select: none; /* Internet Explorer/Edge */
									user-select: none; /* Non-prefixed version, currently
														  supported by Chrome and Opera */
				  }
				   .addDynamicfield:hover,.removeDynamicfield:hover{
					   opacity:1;
				   }
				  .removeDynamicfield{
						color:#F30;  
				  }
                  .addDynamicfield i,.removeDynamicfield i{
					font-size: 22px;  
				  }
				  .removeDynamicfield i.removing{
					  animation:spin 2s linear infinite;
				  }
				  .istate{
					 display:none; 
					  }
</style>
 <!--breadcrumbs start-->
          <!--breadcrumbs end-->

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">  
              <form role="form" name="frmservicereturn" id="frmservicereturn"  method="post" enctype="multipart/form-data">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                    
                  <div class="col s12 m4 l4">
                <div class="card-panel">
				<h4 class="header2">Add Service Return</h4>
                  <div class="row">
              
                      <div class="row">                    
                                          
                        
                        <div class="input-field col s12 m6 s6" id="vname">
                        	<input  type="hidden" id="cno" name="cno" value="<?php echo $edit[0]->complaint_no;?>" >
                          	<input  type="text" placeholder="Name" id="sname" name="sname" value="<?php echo $edit[0]->ser_name;?>" readonly>
                            
                          <label for="first_name">Name</label>
                        </div>
                                                                    
                        <div class="input-field col s12 m6 s6">
                          	<input  type="text" placeholder="Address" id="address" name="address"  value="<?php echo $edit[0]->ser_address;?>" readonly>
                          <label for="first_name">Address</label>
                        </div>
                        <div class="input-field col s12 m6 s6">
                          	<input  type="text" placeholder="Product" id="product" name="product" value="<?php echo $edit[0]->ser_product;?>" readonly>
                          <label for="first_name">Product</label>
                        </div>
                        
                    
                        
                        
                        <div class="input-field col s12 m6 s6">
                          	<input  type="text" name="cmplnts" id="cmplnts"  placeholder="Complaints description" value="<?php echo $edit[0]->ser_complaints;?>" readonly>
                          <label for="first_name">Complaints</label>
                        </div>
                        
                        <div class="input-field col s12 m6 s6">
                          	<input  type="number" name="mobile" id="mobile"  placeholder="Mobile No." value="<?php echo $edit[0]->ser_mobile;?>" readonly>
                          <label for="first_name">Mobile</label>
                        </div>
                            <div class="input-field col s12 m6 s6">
                        
                         	<input  type="text" name="warranty" id="warranty"  value="<?php if($edit[0]->ser_warranty==1) { echo 'Under Warranty';} else if($edit[0]->ser_warranty==2) { echo 'Out of Warranty';}  ?>" readonly> 
                             <label for="first_name"> Warranty Type </label>
                      
                        </div>
                          <div class="input-field col s12 m6 s6">
                        <select name="itmstatus" id="itmstatus" >
                          <option value="">Item Status </option>
                          <option value="1">Resolved</option>
                          <option value="2">Not Resolved </option>
                          </select>
                            <label for="first_name"> Item Status </label>
                        </div>
                            <div class="input-field col s12 m6 s6">
                        <select name="ttype" id="ttype">
                     <!--     <option value="">Tax Type </option>-->
                          <option value="1">Same state</option>
                          <option value="2">Inter state </option>
                          </select>
                           <label for="first_name"> Tax Type </label>
                           
                        </div>
                                  </div>
                      
                     
                        
                  
                  </div>
                </div>
              </div>
			  <div class="col s12 m8 l8">
                    <div class="card-panel">
                      <h4 class="header2">All Services</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:20px;text-align:center;">SN</th>
                           <th style="text-align:left;width:200px;">Additional Parts</th>
                          <th style="text-align:left;">Amount</th>
                          <th style="text-align:left;    width: 100px;" class="sstate">SGST</th>
                         
                          <th style="text-align:left;    width: 100px;" class="sstate">CGST</th>
                          <th style="text-align:left;    width: 100px;" class="istate">IGST</th>
                           <th style="text-align:left;">Total</th>
                         
                          
                        </tr>
                      </thead>
                      <tbody id="addtr">
                  
                         
                          
							<tr >
								<td style="width:20px;text-align:center;"><span class="slno">1</span></td>
                                 <td style="text-align:left;">  
                               <div style="    width: 130px;" id="partsel">
                                 <select name="additionalpart[]" id="additionalpart">
                          <option value="">Select  Parts  </option>
                          
                          <?php foreach($allparts as $pval){ ?>
                          <option value=" <?php echo $pval->part_id?>"><?php echo $pval->part_name?></option>
                          <?php } ?>
                      
                          </select><a class="addDynamicfield btnaddparts" style="right:12px"><i class="material-icons">add_circle</i></a></div>
                           </td>
								<td style="text-align:left;"><label id="amtlabel"></label><input type="hidden" id="amtvalue" name="amtvalue[]" /></td>
                                <td style="text-align:left;" class="sstate"><label id="sgstlabel"></label><input type="hidden" id="sgstvalue" name="sgstvalue[]" /></td>
                               
                                 <td style="text-align:left;"  class="sstate"><label id="cgstlabel"></label><input type="hidden" id="cgstvalue" name="cgstvalue[]" /> </td>
                                  <td style="text-align:left;"  class="istate"><label id="igstlabel"></label><input type="hidden" id="igstvalue" name="igstvalue[]" /> </td>
                                    <td style="text-align:left;"><label id="totlabel"></label><input type="hidden" id="totvalue" name="totvalue[]" value="0" /></td>
								
								
							</tr>
                            
			
                        
                      </tbody>
                    </table>	<div class="row">
                          <div class="input-field col s12">
                           <label id="nettotlabel" style="font-size:20px;font-weight:bold;color:#F00;">Total amount : Rs 0.00 </label>
                    <input type="hidden"  id="nettotvalue" name="nettotvalue" value="0"/>
                            <button class="btn cyan waves-effect waves-light right"  id="btnsalesreturn" type="button"  name="btnsalesreturn">Submit
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                      </div>
                   
                      </div>
                    </div>
                  </div>
			  
                </div>
                </form>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>


	
	
	
<script >




	
	
	
	
$(document).ready(function(e) {
	$('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15, // Creates a dropdown of 15 years to control year,
    today: 'Today',
    clear: 'Clear',
    close: 'Ok',
    closeOnSelect: false, // Close upon selecting a date,
	format: 'yyyy-mm-dd',
    container: undefined // ex. 'body' will append picker to body
  });
	//------insert -------------//
	
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');
        
        var values = { 'itmstatus':$('#itmstatus').val() }
								 
		 if(values.itmstatus == ''){
		    $('#itmstatus').parent().children('.select-dropdown').addClass('errors');
			$('#itmstatus').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
				
        return error;
    }
	



 $(document).on('keypress','.number-check', function(e) {	
				if ( event.keyCode == 46 || event.keyCode == 8 ) {
				}
				 else {
						if (event.keyCode < 48 || event.keyCode > 57) {
							event.preventDefault(); 
						}  
				 }
			});
			
	function alreadyexistalert(){
	
	 swal({
                            title: "Error",
							   text: "Part Name Already Exist",
							   showCancelButton: true,
							   confirmButtonText: "OK",
							   cancelButtonText: "Cancel ",
							   customClass:"swal-delete",
                         	 }).then(function(){
							  
							   btnaddparts();
							  
							  });
	}					
function btnaddparts(elmpart){
								
		  					 $('#txtpartgst').material_select();
							$('#txtpartgst').css({'display':'block'});
							//  var cat=$("#cat").val();
				swal({
						  title: 'Add New Additional Part',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input  placeholder="Enter  New Additional Part" name="txtpartname"  id="txtpartname" type="text"  ><label for="first_name">Part Name</label></div></div><div class="row"><div class="input-field col s12"><input  placeholder="Enter Amount" name="txtpartamt" id="txtpartamt" type="text" class="number-check"  ><label for="first_name" class="active">Amount</label></div></div><div class="row"><div class=" col s12"><select class="form-control" id="txtpartgst" name="txtpartgst"  style="display:block;    padding: 0px;" ><option value="0" selected="selected">Select Tax </option><?php foreach($protypes as $ptval){	?><option value="<?php echo $ptval->pro_type_id;?>"><?php echo $ptval->pro_type_name;?></option><?php }	?></select></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var txtpartname=$("#txtpartname").val();
									var txtpartamt=$("#txtpartamt").val();
									var txtpartgst=$("#txtpartgst").val();
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors'); 
								    $('select').removeClass('errors');
								   if(txtpartname==''){ 
											$('#txtpartname').parent().children('label').addClass('labelerror');
											$('#txtpartname').addClass('errors');
											$('#txtpartname').attr("placeholder", "Please enter Part name");
										err=1;
									}
									if(txtpartamt==''){ 
											$('#txtpartamt').parent().children('label').addClass('labelerror');
											$('#txtpartamt').addClass('errors');
											$('#txtpartamt').attr("placeholder", "Please enter Amount");
										err=1;
									}
									if(txtpartgst==''){ 
											$('#txtpartgst').addClass('errors');
										err=1;
									}
									return err;	
							}
								if(ev==0){
								
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>servicereturn/addpart",
														data:"txtpartname="+txtpartname+"&txtpartamt="+txtpartamt+"&txtpartgst="+txtpartgst,
														success:function(data){
															 $('.overlay').css({'display':'none'}); 
														if(data==1){
															alreadyexistalert();
															//reject('Tax Type Already Exist');
															}
															else{
															
																resolve();	  
															}
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
										$('.overlay').css({'display':'flex'});
									swal({
		  title: '<div class="tst" >Success</div>',
		  html:'<div class="tst1" >Additional Part Added</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
			 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>servicereturn/getnewparts",
												//	data:"catval="+cat2,
														success:function(data){ 
																$('.overlay').css({'display':'none'}); 
																elmpart.find('#additionalpart').material_select('destroy');
																elmpart.find('#partsel').html(data);
																elmpart.find('#additionalpart').material_select();
														}
										 			});
			  	});
	
		}
						
						
	$(document).on('click', '.btnaddparts', function(){
		 var elmpart=$(this).parent().parent();
		btnaddparts(elmpart);
		
		})


$(document).on('change','#ttype', function(e) {	

if(	$('#ttype').val()==1){
	
	$('.sstate').css({'display':' table-cell','width':'75px'});
	$('.istate').css('display','none');
	}
else	if(	$('#ttype').val()==2){
	$('.istate').css({'display':' table-cell','width':'100px'});
	$('.sstate').css('display','none');
	}


})
function addrow(){
	
	var h='<tr><td style="width:20px;text-align:center;"><span class="slno">1</span></td><td style="text-align:left;"> <div style="width: 130px;" id="partsel"><select name="additionalpart[]" id="additionalpart"><option value="">Select  Parts  </option><?php foreach($allparts as $pval){ ?><option value=" <?php echo $pval->part_id?>"><?php echo $pval->part_name?></option><?php } ?></select><a class="addDynamicfield btnaddparts" style="right:12px"><i class="material-icons">add_circle</i></a></div></td><td style="text-align:left;"><label id="amtlabel"></label><input type="hidden" id="amtvalue" name="amtvalue[]" /></td><td style="text-align:left;" class="sstate"><label id="sgstlabel"></label><input type="hidden" id="sgstvalue" name="sgstvalue[]" /></td><td style="text-align:left;"  class="sstate"><label id="cgstlabel"></label><input type="hidden" id="cgstvalue" name="cgstvalue[]" /> </td><td style="text-align:left;"  class="istate"><label id="igstlabel"></label><input type="hidden" id="igstvalue" name="igstvalue[]" /></td><td style="text-align:left;"><label id="totlabel"></label><input type="hidden" id="totvalue" name="totvalue[]" value="0" /></td></tr>';
	
	$('#addtr').append(h);
	$('select').material_select();
		if($('#ttype').val()==1){
				$('.sstate').css({'display':' table-cell','width':'75px'});
				$('.istate').css({'display':'none'});
				}
				else if($('#ttype').val()==2){
				$('.sstate').css({'display':'none'});
				$('.istate').css({'display':' table-cell','width':'100px'});
				
				}
				
			var x=document.querySelectorAll(".slno");
												for(i=0;i<x.length;i++){
													sl=parseInt(i)+1;
													//console.log(x[i]);
													x[i].innerHTML=sl;
													
													}
													
						nettot();							
	}
		function nettot(){
		var xt=document.querySelectorAll("#totvalue");
		//	console.log(xt);
				var tot=0;
				
												for(i=0;i<parseInt(xt.length)-1;i++){
												
													tot=(parseFloat(tot)+parseFloat(xt[i].value)).toFixed(2);
													 var text='Total Amount : Rs '+tot;
													$('#nettotlabel').text(text);
													
													$('#nettotvalue').val(tot);
												
													}
	}
function rowcalc(pid,elm){
		$.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>servicereturn/getpartdetails",
												     	data:"pid="+pid,
														success:function(data){ 
																$('.overlay').css({'display':'none'}); 
																//alert(data);
																data=JSON.parse(data);
																elm.find('#amtlabel').text(parseFloat(data.amt).toFixed(2));
																elm.find('#amtvalue').val(parseFloat(data.amt).toFixed(2));
															
																//	var gst=(parseFloat(data.gst)/2).toFixed(2);
																	elm.find('#cgstlabel').text((parseFloat(data.gst)/2).toFixed(2)+'%');
																	elm.find('#cgstvalue').val((parseFloat(data.gst)/2).toFixed(2));
																
																	elm.find('#sgstlabel').text((parseFloat(data.gst)/2).toFixed(2)+'%');
																	elm.find('#sgstvalue').val((parseFloat(data.gst)/2).toFixed(2));
																	
																	elm.find('#igstlabel').text(parseFloat(data.gst).toFixed(2)+'%');
																	elm.find('#igstvalue').val(parseFloat(data.gst).toFixed(2));
																	
																var amt=parseFloat(data.amt).toFixed(2);
																var tax=((parseFloat(data.amt)*parseFloat(data.gst))/100).toFixed(2);
																var tot=(parseFloat(amt)+parseFloat(tax)).toFixed(2);
																	elm.find('#totvalue').val(parseFloat(tot).toFixed(2));
																	elm.find('#totlabel').text(parseFloat(tot).toFixed(2));
															nettot();		
														}
										 			});
	
	
	}
$(document).on('change','#additionalpart', function(e) {
	var pid=$(this).val();
	if($(this).val()!=''){
	$('.overlay').css({'display':'flex'});
	 var elm=$(this).parent().parent().parent().parent();
	
	rowcalc(pid,elm);
	
		var xs=document.querySelectorAll("#additionalpart");
			//	console.log(xs[0].value);					
												
													if(xs[parseInt(xs.length)-1].value!=''){
														addrow();
														
														}
	}
	
			  	});
				


$(document).on('click','#btnsalesreturn', function(e) {
		if(validation()==0){
		$('.overlay').css({'display':'flex'});
	
		var url="<?php echo ADMIN_PATH?>servicereturn/addnewservicereturn";
  			var redirect = "<?php echo ADMIN_PATH?>servicereturn";
  			var form = document.forms.namedItem("frmservicereturn");                        
			var oData = new FormData(document.forms.namedItem("frmservicereturn"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
				$('.overlay').css({'display':'none'});
				
					  customSwalFunD("Success","Sucessfully Added");				
					document.location=redirect;
				
				}
				    oReq.send(oData);
			}	
		
	})
});
			  

		
		
	</script>
    
      





    




    
    
    
    
    
    
    
    
    

