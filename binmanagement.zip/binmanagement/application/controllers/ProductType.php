<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Producttype extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Producttype_model','model');
	 }	
	 public function index()
	{
		$headdata['status']='active';
		$headdata['menu']='organizer';
		$headdata['submenu']='tax';
		$data['producttype']=$this->model->getproducttype();
		$this->load->view('admin/header',$headdata);
		$this->load->view('admin/producttype/producttype_add',$data);
		$this->load->view('admin/footer');
	}
	
	public function addproducttype(){
		$this->model->addproducttype();	
	}
	
		public function updateproducttype()
	{
		$this->model->updateproducttype();	
	}
	public function getdetails()
	{
		$this->model->getdetails();	
	}
	
	public function deleteproducttype()
	{
		$this->model->deleteproducttype();	
	}

}

