  <style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
		 .panel-heading1 {
		 font-size: 18px;
    font-weight: 300;
    letter-spacing: 0.025em;
    height: 66px;
    line-height: 45px;
    background: ##ddd;
    border-bottom: 1px solid #eee;
    color: #333;
	padding: 10px 15px;
    /* background: #428bca; */
}

</style>		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		</br>
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Update Product</div>
					<div class="panel-body">
						<div class="col-md-6">
							<form role="form" name="frmproduct" id="frmproduct">
							
<fieldset>
							 
							  	 <div class="form-group">
									
									<select class="form-control form-control1" id="selcat" name="selcat">
                                    	<!--<option value="0"> Category</option>-->
										<?php foreach($category as $key){
                                                if($edit->cat_id==$key->cat_id)
													{
													?>
														<option  selected="selected" value="<?php   echo $edit->cat_id;?>"><?php echo $key->cat_name;?></option>
													<?php 
												 }
													else{?>
													<option value="<?php echo $key->category_id;?>"><?php echo $key->cat_name;?></option>	
                                                <?php }}?>
									</select>
								</div>
                                 <div class="form-group">
									
									<select class="form-control" id="selsubcats" name="selsubcat">
                                    	<!--<option value="0">Sub Category</option>-->
                                        <?php foreach($subcat as $keydt){
											
                                                    if($edit->subcat_id==$keydt->sub_id)
													{
														?>
														<option  selected="selected"value="<?php echo $edit->subcat_id;?>"><?php echo $keydt->subcat_name;?></option>
													<?php 
													}
													else  {?>
													<option value="<?php echo $keydt->sub_id;?>"><?php echo $keydt->subcat_name;?></option>	
                                                    
                                                <?php }}?>
									</select>
								</div>
							<div class="form-group" >
                            <input type="hidden" name="txthidden" value="<?php echo $edit->product_id ?>" />
								<input  class="form-control "  value="<?php echo $edit->product_name ?>" id="txtproduct" name="txtproduct" type="text" >
							</div>
                            <div class="form-group" >
                            
								<input  class="form-control "  value="<?php echo $edit->amount ?>" id="txtamount" name="txtamount" type="text" >
							</div>
							<!--<div class="text-center"><a href="index.html" class="btn btn-primary btn-block lg">Submit</a></div>-->
                            
                             <div class="col-md-6" >
                              <a href="#" class="btn btn-primary btn-block lg" id="btnsubmit" style="float:right;">Update</a></div>
                            	<div class="col-md-6">  <a href="" id="btncancel" class="btn btn-default btn-block lg" style="float:left;">Cancel</a></div>
                            </fieldset>								
							</form>	
					</div>
				</div>
                	 <div class="panel-footer"></div>
                     </div>
                     </div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->
    <!-- /.row -->
</div>
    <script src="<?php echo ADMIN_STYLEPATH ?>js/jquery-1.11.1.min.js" type="text/javascript"></script>


<script type="text/javascript">

$(document).ready(function(e) {
	
	//-----changing subcategory on selecting category-------//
		$("#selcat").change(function(e) {
	//alert(1);
	var catid=$( this).val();
//alert(catid);
			 	$.ajax({
			   	type:"post",
			   	url:"<?php echo ADMIN_PATH;?>Product/getsubcategorybycategoryid",
			  	data:"catid="+catid,
				success:function(data){
				//	alert(data);
					$("#selsubcats").html(data);
					}		   
			   			});
        });
	
	
	
	
   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			//alert(1);
			var e=validation();
			if(e==0){
  			var url="<?php echo ADMIN_PATH?>product/proupdate";
  			var redirect = "<?php echo ADMIN_PATH?>product";
  			var form = document.forms.namedItem("frmproduct");                        
			var oData = new FormData(document.forms.namedItem("frmproduct"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
					
				 if(oReq.responseText==1){
					 
					  alert("Exist");
					 }
					 else
					 {
 					document.location = redirect;
					 }}
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');

        $('input').removeClass('errorInput');

        $('select').removeClass('errors');

        $('select').removeClass('errorInput');
        

        var values = {
                                    'category':$('#selcat').val(),
									'sucategory':$('#selsubcats').val(),
									'product':$('#txtproduct').val(),

                                 }

        if(values.category == 0){

            $('#selcat').addClass('errors');

            $('#selcat').attr("placeholder", "Select");

            $('#selcat').addClass('errorInput');

            error=1;

        } 
		if(values.sucategory == 0){

            $('#selsubcats').addClass('errors');

            $('#selsubcats').attr("placeholder", "Select");

            $('#selsubcats').addClass('errorInput');

            error=1;

        } 
				if(values.product == ''){

            $('#txtproduct').addClass('errors');

            $('#txtproduct').attr("placeholder", "Please enter product name");

            $('#txtproduct').addClass('errorInput');

            error=1;
        } 
        return error;
    }
//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmsubcat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
});
</script>
