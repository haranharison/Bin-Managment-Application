<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Salesmanlocation extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->load->model('Salesmanlocation_model','model');
	 }	
	 public function index()
	{
		$data['salesman']=$this->model->getsalesman();
		$data['area']=$this->model->getarea();
	
		$this->load->view('admin/header');
		$this->load->view('admin/salesmanlocation',$data);
		$this->load->view('admin/footer');
	}
	
	public function getlocbysid()
	{
		$this->model->getlocbysid();
		
	}	
}

