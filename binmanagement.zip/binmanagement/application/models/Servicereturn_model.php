<?php
class Servicereturn_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	
	 public function allparts()
		{
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_additional_part')->result();
		}
         public function getprotypes()
		{
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_product_type')->result();
		}
		public function getservice()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_service')->result();
		}
		
		public function addservice()
		{
		    $max=maxplus('tbl_service','ser_id');	
		    $today=date('Y-m-d');
			$complaintno='SRN#'.$this->session->userdata('org_id').$this->session->userdata('emp_id').date('ymdHis').$max;
			$data= array(
			   'ser_id' =>$max,
			   'org_id'=>$this->session->userdata('org_id'),
			   'emp_id'=>$this->session->userdata('emp_id'),
			   'complaint_no'=>$complaintno,
		       'ser_name'=>$this->input->post('sname'),
			   'ser_address'=>$this->input->post('address'),
			   'ser_product'=>$this->input->post('product'),
			   'yr_of_manu'=>$this->input->post('yrofmanu'),
			   'ser_warranty'=>$this->input->post('warranty'),
			   'ser_delivery_date'=>$this->input->post('exdeldate'),
			   'ser_complaints'=>$this->input->post('cmplnts'),
			   'ser_mobile'=>$this->input->post('mobile'),
			   'ser_alternative'=>$this->input->post('altnumber'),
			   'ser_email'=>$this->input->post('semail'),
			   'status'=>0,
			   'created_date'=>$today,
			   'modified_date'=>$today,
			);
			$this->db->insert('tbl_service',$data);	
			$to=$this->input->post('sname');
			$msg='Complaint ID : ' .$complaintno;
			$sub='Complaint ID';
			$email=$this->input->post('semail');
			
			send_mail($to,$msg,$sub,$email);
			
		     echo $complaintno;
		}
		
		public function addservicereturn($mid){ 
		    $id=$mid;
			$array=array('status'=>0,'ser_id'=>$id);
			$this->db->where($array);
			$this->db->select('*');
       		$result=$this->db->get('tbl_service');
       		return $rows=$result->result();
		}
	
	public function addpart(){
	 $max=maxplus('tbl_additional_part','part_id');	
	$txtpartname=	$this->input->post('txtpartname');
	$txtpartamt=	$this->input->post('txtpartamt');
	$txtpartgst=	$this->input->post('txtpartgst');
	$today=date('Y-m-d');
	$arr=array(
	'part_id'=> $max,
	'org_id'=>$this->session->userdata('org_id'),
	'part_name'=>$txtpartname,
	'part_amt'=>$txtpartamt,
	'part_gst'=>$txtpartgst,
	'created_date'=>$today,
	'modified_date'=>$today
	
	);
		$this->db->insert('tbl_additional_part',$arr) ;
	 }
	
 public function getnewparts(){
	
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_additional_part');
				 $res= $rows->result();
				 $html='';
				 
				 if($rows->num_rows()>0){
					 
					 $html.='<select name="additionalpart" id="additionalpart"><option value="0" >Select Parts</option>';
					foreach($res as $val){
					 $html.='<option value="'.$val->part_id.' ">'.$val->part_name.'</option>	';
					}
					$html.='</select><a class="addDynamicfield btnaddparts" style="right:12px"><i class="material-icons">add_circle</i></a>';
					 //$html.='</select><a class="addDynamicfield btnaddunit"><i class="material-icons">add_circle</i></a>';
					 }
					
					
						 
				echo $html;
		 
	 }


   public function getpartdetails(){
	   
			$pid=	$this->input->post('pid');
			$array=array('tbl_additional_part.status'=>0,'tbl_additional_part.org_id'=>$this->session->userdata('org_id'),'tbl_additional_part.part_id'=>$pid);
			$this->db->where($array);
			$this->db->select('tbl_additional_part.*,tbl_product_type.pro_type_percentage');
				$this->db->from('tbl_additional_part');
				$this->db->join('tbl_product_type','tbl_product_type.pro_type_id=tbl_additional_part.part_gst');
			
			 $rows=$this->db->get()->row(); 
			 
			 $arr=array('amt'=>$rows->part_amt,'gst'=>$rows->pro_type_percentage);
		 echo json_encode($arr);
	 }
	 
	 public function addnewservicereturn(){
	$sname=$this->input->post('sname');
	$complaint=$this->input->post('cmplnts');
	$product=$this->input->post('product');
	$mobile=$this->input->post('mobile');
	$cno=$this->input->post('cno');
	$itmstatus=$this->input->post('itmstatus');
	$ttype=$this->input->post('ttype');
	$nettotvalue=$this->input->post('nettotvalue');
	
	$additionalpart=$this->input->post('additionalpart');
	$amtvalue=$this->input->post('amtvalue');
	$sgstvalue=$this->input->post('sgstvalue');
	$cgstvalue=$this->input->post('cgstvalue');
	$igstvalue=$this->input->post('igstvalue');
	$totvalue=$this->input->post('totvalue');
	$orgid=$this->session->userdata('org_id');
	$empid=$this->session->userdata('emp_id');
	 $max=maxplus('tbl_servicereturn','servicereturn_id');	
	 $today=date('Y-m-d');
		$arr=array(
		'servicereturn_id'=>$max,
		'org_id'=>$orgid,
		'emp_id'=>$empid,
		'complaint_id'=>$cno,
		'item_status'=>$itmstatus,
		's_tax_type'=>$ttype,
		's_net_total'=>$nettotvalue,
		'created_date'=>$today,
		'modified_date'=>$today,
		);

	$this->db->insert('tbl_servicereturn',$arr);
	
	$c1=count($this->input->post('additionalpart'));
	
	
		for($i1=0;$i1<$c1;$i1++){
						
							if($additionalpart[$i1]!=''){ 
							
								if($ttype==1){ 
									
									$darr=array(
									'sreturn_id'=>$max,
									'part_id'=>$additionalpart[$i1],
									'part_amnt'=>$amtvalue[$i1],
									'p_cgst'=>$cgstvalue[$i1],
									'p_sgst'=>$sgstvalue[$i1],
									'p_totamt'=>$totvalue[$i1],
									'created_date'=>$today,
									'modified_date'=>$today,
									);
									
								$this->db->insert('tbl_servicereturn_details',$darr);	
								}
								else if($ttype==2){ 
									
									$darr=array(
									'sreturn_id'=>$max,
									'part_id'=>$additionalpart[$i1],
									'part_amnt'=>$amtvalue[$i1],
									'p_igst'=>$igstvalue[$i1],
									'p_totamt'=>$totvalue[$i1],
									'created_date'=>$today,
									'modified_date'=>$today,
									);
								
								
								$this->db->insert('tbl_servicereturn_details',$darr);		
								}
							
							
							}
							
			}
			
		$arrcc=array('complaint_no'=>$cno); 
		$this->db->where($arrcc)	;
		if($itmstatus==1){
		$arrdata=array('status'=>1);
		}
		else if($itmstatus==2){
		$arrdata=array('status'=>2);
		}
		$this->db->update('tbl_service',$arrdata);
		
			
			$msg="Dear ".$sname."your complaint with id ".$cno." for ".$product."  has been resolved and total amount is Rs : ".$nettotvalue ; 
			sentsms($msg,$mobile)	;
			
			
	 }
}