<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Area extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Area_model','model');
	 }	
	 public function index()
	{
		$data['area']=$this->model->getarea();
		$headdata['menu']='organizer';
		$headdata['submenu']='area';
		$this->load->view('admin/header',$headdata);
		$this->load->view('admin/area/areaadd',$data);
		$this->load->view('admin/footer');
	}
	
	public function addarea(){
	$this->model->addarea();	
	}
	public function editArea($id=false){
		$data['edit']=$this->model->editArea($id);
		$data['area']=$this->model->getarea();
		$headdata['menu']='organization';
		$headdata['submenu']='area';
		$this->load->view('admin/header',$headdata);
		if(empty($data['edit']))
		{
			$data['heading']='Message';
			$data['message']='An uncaught Exception was encountered.Please try again';
			$this->load->view('errors/html/error_general',$data);
		}
		else{
		$this->load->view('admin/area/edit',$data);
		}
		$this->load->view('admin/footer');
		}
		
	public function updatearea(){
		$this->model->updatearea();	
	}

	public function deleteArea(){
		//echo $id;
		$this->model->deleteArea();
		}
	
/*	public function deleteCategories($id=false){
		//echo $id;
		$this->model->deleteCategories($id);
		}*/
//product edit page
}

