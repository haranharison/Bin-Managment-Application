<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Viewshifts extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Viewshifts_model','model');
	 }	
	 public function index()
	{
		//$data['area']=$this->model->getarea();
		$data['shifts']=$this->model->getallshifts();
		$headdata['menu']='viewshifts';
		$headdata['submenu']='viewshifts';
		$this->load->view('admin/header',$headdata);
		$this->load->view('admin/shifts/shiftlist',$data);
		$this->load->view('admin/footer');
	}
	
	 

}
