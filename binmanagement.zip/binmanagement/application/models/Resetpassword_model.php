<?php
class Resetpassword_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        
		public function checkoldpwd()
		{
			//$id=$this->input->post('id');
			
			$oldpwd=$this->input->post('oldpwd');
			$array=array('password'=>$oldpwd);
		$this->db->where($array);
		$this->db->select('*');
		$result=$this->db->get('tbl_admin');
		//var_dump($result);
				if($result->num_rows() > 0)
				{
				$newpwd=$this->input->post('newpwd');
				$data= array(
				'password' =>$newpwd,
				);	
		
		//$array= array('area_id'=>$cid);
		 //  $this->db->where($array);
		   $this->db->update('tbl_admin',$data);
				echo 1;		
				}
				else{
					echo 2;	
					}
				
			
		
		
		}
		public function checkoldpwds()
		{
			//$id=$this->input->post('id');
			
			$oldpwd=$this->input->post('id');
			$array=array('password'=>$oldpwd);
		$this->db->where($array);
		$this->db->select('*');
		$result=$this->db->get('tbl_admin');
		//var_dump($result);
				if($result->num_rows() > 0)
				{
				echo 1;		
				}
				else{
					echo 2;	
					}
		
		}
		
		
}