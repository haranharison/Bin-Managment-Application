<?php
class Organisation_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	public function getallorg()
	{
		$array=array('tbl_organisation.status'=>0);
		$this->db->where($array);
		$this->db->select('tbl_organisation.*');
		$this->db->from('tbl_organisation');
		return $result=$this->db->get()->result();
		
	}
	 public function getusergroup()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_usergroup')->result();
		}
	public function getarea()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_area')->result();
		}
	
	public function addorg()
		{
		$existphone=fieldexist2('tbl_organisation','org_mobile',$this->input->post('orgmobile'));
		$existmail=fieldexist2('tbl_organisation','org_mail',$this->input->post('orgmail'));
			if($existphone==1){
				echo 1;
			}
			else if($existmail==1){
				echo 2;
				}
			else{
	
		$max=maxplus('tbl_organisation','org_maxid');
		$o_maxid='O_'.$max;
		//$pwd=rand(1000,9999);
				$today= date("y-m-d");
				
		$name=$this->input->post('orgname');
		$address=$this->input->post('orgaddress');
		$phone=$this->input->post('orgphone');
		$mobile=$this->input->post('orgmobile');
		$fax=$this->input->post('orgfax');
		$email=$this->input->post('orgmail');
		$pwd=$this->input->post('orgpass');
		$website=$this->input->post('orgweb');
		$gst=$this->input->post('orggst');
		$pincode=$this->input->post('orgpin');
		$district=$this->input->post('orgdistrict');
		$state=$this->input->post('orgstate');
		$nation=$this->input->post('orgnat');
		$person=$this->input->post('orgperson');
		$year=$this->input->post('orgyear');
		
		$appstatus=$this->input->post('appstatus');
		$trialdays=$this->input->post('trialdays');
		$userlimit=$this->input->post('userlimit');
		/////////////////gallery///////////////////////////
		$config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
			 
            $this->load->library('upload', $config);
            if ( ! $this->upload->do_upload('icon')) {
            $error = array('error' => $this->upload->display_errors());
            } 
			else 
			{
            $dataimg = array('upload_data' => $this->upload->data());
            }
	   	
		if(isset($dataimg['upload_data']['file_name'])){
				 $path1='uploads/'.$dataimg['upload_data']['file_name'];		
			}else{
				 $path1='uploads/dummyicon.png';		
			}
		
		
		//////////////////tbl_sms//////////////////////////
		$maxz=maxplus('tbl_sms_orgsettings','max_id');
		$dataz= array(
		      'max_id'=>$maxz,
			   'org_id'=>$o_maxid,
			   'smscount'=>0,
			   'created_on'=>$today,
			   'modified_on'=>$today
		);
		$this->db->insert('tbl_sms_orgsettings',$dataz);
		
		////////////////////////////////////////////
		
		
		$data= array(
		       'org_name'=>$name,
			   'org_logo'=>$path1,
			   'org_maxid'=>$max,
			   'o_maxid'=>$o_maxid,
			   'org_address'=>$address,
			   'org_phone'=>$phone,
			   'org_mobile'=>$mobile,
			   'org_fax'=>$fax,
			  'org_mail'=>$email,
			   'password'=>$pwd,
			'org_web'=>$website,	
			   'org_gstno'=>$gst,
			   'org_pin'=>$pincode,
			   'org_state'=>$state,
			   'org_district'=>$district,
			   'org_nationality'=>$nation,
			    'org_year'=>$year,
				'user_limit'=>$userlimit,
				'org_authperson'=>$person,
			   'created_date'=>$today,
			   'modified_date'=>$today
		);
		$this->db->insert('tbl_organisation',$data);
		$oid=$this->db->insert_id();
	
			$array=array('status'=>0,'org_id'=>$oid);
			$this->db->where($array);
			$this->db->select('o_maxid');
			$rowid=$this->db->get('tbl_organisation')->row();
			$orid=$rowid->o_maxid;
			$this->session->set_userdata('oid',$orid);
	
	    $username=$mobile;
        $to_email = $this->input->post('orgmail');
		$msg='Username:'.$username.', Password:'.$pwd;
		$sub= 'Username and Password for login.'; 
    	$array=array(
	'emp_id'=>$o_maxid,
	'username'=>$mobile,
	'password'=>$pwd,
	'usergroup'=>'org',
	'org_id'=>$o_maxid,
	'email'=>$email,
	'app_status'=>$appstatus,
	'trial_days'=>$trialdays,
	'created_date'=>$today,
	'modified_date'=>$today,
	'status'=>0
	);
	$this->db->insert('tbl_login',$array);
	
	sentsms( $msg, $mobile);
	send_mail_org($to_email, $msg, $sub);
		}
		}
       public function getorgbyid($id)
	   {
		 $id=decode($id);
		 $array=array(
		 'tbl_organisation.org_maxid'=>$id,'tbl_organisation.status'=>0
		 );
		  	 $this->db->where($array);
		     $this->db->select('tbl_organisation.*,tbl_login.app_status,tbl_login.trial_days');
			 $this->db->from('tbl_organisation');
			 $this->db->join('tbl_login','tbl_login.emp_id=tbl_organisation.o_maxid');
		 return $result=$this->db->get()->row();
	   }
	   
	public function updateorg()
	{
		
		   $org_maxid=decode($this->input->post('hidden'));
				$existphone=0;
			  $existmail=0;
			$array=array('org_maxid'=>$org_maxid,'status'=>0);
			$this->db->where($array);
			$this->db->select('org_mobile,org_mail');
       		$res=$this->db->get('tbl_organisation')->row();
			
			if($res->org_mobile!=$this->input->post('orgmobile')){
				$existphone=fieldexist('tbl_organisation','org_mobile',$this->input->post('orgmobile'),'org_id',$this->session->userdata('org_id'));
			}
			if($res->org_mail!=$this->input->post('orgmail')){
		  
				$existmail=fieldexist('tbl_organisation','org_mail',$this->input->post('orgmail'),'org_id',$this->session->userdata('org_id'));
			}
		if($existphone==1){
			echo 1;
			}
		else if($existmail==1){
			echo 2;
			}
				else{
		$org_id=decode($this->input->post('hidden'));
		$today= date("y-m-d");
		$name=$this->input->post('orgname');
		$address=$this->input->post('orgaddress');
		$phone=$this->input->post('orgphone');
		$mobile=$this->input->post('orgmobile');
		$fax=$this->input->post('orgfax');
		$email=$this->input->post('orgmail');
		$website=$this->input->post('orgweb');
		$gst=$this->input->post('orggst');
		$pincode=$this->input->post('orgpin');
		$district=$this->input->post('orgdistrict');
		$state=$this->input->post('orgstate');
		$nation=$this->input->post('orgnat');
	//	$user=decode($this->input->post('orgusergrp'));
		$person=$this->input->post('orgperson');
		$year=$this->input->post('orgyear');
	$userlimit=$this->input->post('userlimit');
	$org_oid=decode($this->input->post('hiddeno'));
		$appstatus=$this->input->post('appstatus');
		//$trialdays=$this->input->post('trialdays');
		
			$oldimg=decode($this->input->post('hdicon'));
		
			$config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
			 
            $this->load->library('upload', $config);
            if ( ! $this->upload->do_upload('icon')) {
            $error = array('error' => $this->upload->display_errors());
            } 
			else 
			{
            $dataimg = array('upload_data' => $this->upload->data());
            }
	   	
		if(isset($dataimg['upload_data']['file_name'])){
				 $path1='uploads/'.$dataimg['upload_data']['file_name'];		
			}else{
				 $path1=$oldimg;		
			}
		
		
		
		
		
		if($this->input->post('appstatus')==1){
			$trialdays=$this->input->post('trialdays');
			}
			else{
			$trialdays='';	
				}
		
		$data= array(
		       'org_name'=>$name,
			    'org_logo'=>$path1,
			   'org_address'=>$address,
			   'org_phone'=>$phone,
			   'org_mobile'=>$mobile,
			   'org_fax'=>$fax,
			  'org_mail'=>$email,
			'org_web'=>$website,	
			   'org_gstno'=>$gst,
			   'org_pin'=>$pincode,
			   'org_state'=>$state,
			   'org_district'=>$district,
			   'org_nationality'=>$nation,
			    'org_year'=>$year,
				'user_limit'=>$userlimit,
				'org_authperson'=>$person,
			   'created_date'=>$today,
			   'modified_date'=>$today
		);
		$array=array('o_maxid'=>$org_oid,'status'=>0);
			$this->db->where($array);
	$this->db->update('tbl_organisation',$data);
			
		//Update NEW LOGIN EMAIL 
    	$data=array('app_status'=>$appstatus,'trial_days'=>$trialdays,'email'=>$email,'modified_date'=>$today,'status'=>0);
		$array=array('emp_id'=>$org_oid,'status'=>0);
		$this->db->where($array);
		$this->db->update('tbl_login',$data);

			}
	}
		
		 public function deleteorganisation()
		 {
			 $oid=decode($this->input->post('id'));
			 $array=array('org_maxid'=>$oid);
			 $data=array('status'=>1);
			 $this->db->where($array);
			 $this->db->update('tbl_organisation',$data);
			 
			 $ar=array('emp_id'=>'O_'.$oid);
			 $this->db->where($ar);
			 $this->db->update('tbl_login',$data);
			 
		 }
		 
			 public function updatepermission()
			  {
			 $id=$this->session->userdata('oid');
		//	$id=$this->input->post('txtid');	
				  $permission=$this->input->post('txthper');	
				  
				  $today= date("y-m-d");
				   	$data=array(
				   		 		'permission'=>$permission,
			  					 'modified_date'=>$today
				  			 	);
		   			$array= array('o_maxid'=>$id,'status'=>0);
		  			 $this->db->where($array);
		   			$this->db->update('tbl_organisation',$data);
				  
			  }
			  
	public function getgroupdetails($id)
		{
			$sid=decode($id);
		$array=array('status'=>0,'o_maxid'=>$sid);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_organisation');
		return $result=$this->db->get()->row();	
		}
		
			public function getorganisation()
		{
			$oid=decode($this->input->post('oid'));
		$array=array('tbl_organisation.status'=>0,'org_maxid'=>$oid);
		$this->db->where($array);
		$this->db->select('password');
		$result=$this->db->get('tbl_organisation')->row();	
		echo $result->password;
		}
		
		  public function updatepermission2()
			  {
			
					$id=decode($this->input->post('txtid'));	
				  $permission=$this->input->post('txthper');	
				  
				  $today= date("y-m-d");
				   	$data=array(
				   		 		'permission'=>$permission,
			  					 'modified_date'=>$today
				  			 	);
		   			$array= array('o_maxid'=>$id,'status'=>0);
		  			 $this->db->where($array);
		   			$this->db->update('tbl_organisation',$data);
				  
			  }
		
}