<?php
class Logout_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
      
	  
	  
	  
	  
	    
}