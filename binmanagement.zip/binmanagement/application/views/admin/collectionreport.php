

          <!--breadcrumbs end-->
<style>
.picker__table th{
	color:#fff !important;
}
</style>
<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  <!-- Form with placeholder -->
                  <div class="col s12 m12 l4">
                <div class="card-panel">
                  <div class="row">
                  <!--FORM Report ADD-->
                   <form role="form" action="" name="frmopeningbalance" id="frmopeningbalance">
                    <!-- Sales man-->
                 <div class="row">
                            <div class="input-field col s12">
									<select class="form-control form-control1" name="selsalesman" id="selsalesman">
                                    	<option value="0"> Salesman</option>
											  <?php foreach($salesman as $val){?>
											<option value="<?php  echo $val->salesmanid?>"><?php  echo $val->name?></option>
											<?php  }?>
									</select>
                              		<!--<label for="select Salesman">Salesman</label>-->
                            </div>
                        </div>
                      <!--Sales date--> 
                    <div class="row">
                        <div class="input-field col s12">
                       			<input class="datepicker form-control " type="text" placeholder="Date" name="txtdate" id="txtdate" >
                              <!--	<label for="date of report">Select Date</label>-->
                        </div>
                      </div>
                      <div class="row">
                        <div class="input-field col s12">
                         <select class="form-control form-control1" name="selarea" id="selarea">
                                    	<option value="0"> Location</option>
											<?php foreach($area as $val){?>
											<option value="<?php echo $val->area_id?>"><?php echo $val->area_name?></option>
											<?php }?>
									</select>
                          <!--<label for="sales man location">Location</label>-->
                        </div>
                      </div>
                      <!--Merchant-->
                      <div class="row">
                      	<div class="input-field col s12">
									<select class="form-control form-control1" name="selmerchant" id="selmerchant">
                                    	<option value="0"> Merchant</option>
											<?php foreach($merchant as $val){?>
											<option value="<?php echo $val->merchant_id?>"><?php echo $val->merchantname?></option>
											<?php }?>
									</select>
                              		<!--<label for=" "> </label>-->
                           </div>
                      </div>
                      <!--BUTTON SUBMIT-->
                        <div class="row">
                          <div class="input-field col s12">
                            <button class="btn green accent-4 waves-effect waves-light right" type="button" id="prdct-add-btn" name="action">View Report
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                        </div>
                    </form>
                  </div>
                </div>
              </div>
              
           <div class="col s12 m12 l8">
               <div class="card-panel">
                  <div class="row">
                     <table id="datatable" class="display" cellspacing="0" width="100%">
						 <thead>
						     <tr class="text-center">
								  <!--<th style="width:50px;">-->
                            <th style="width:10%;">Sl No</th>
                            <th>Sales ManName</th>
                            <th>Merchant</th>
                            <th>Amount</th>
                            
                         </tr>   
						</thead>
						<tbody id="dat">
                                      
				 </tbody>
                             </table>               		
                  </div>
             	</div>
          </div>
</div>     
        
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

  
<script>


						
		$(document).ready(function(e) {	
		
		<!---- salesman wise report----->				
$("#selsalesman").change(function(e) {
	
	alert(1);
	var sid=$( this).val();
	//alert(sid);
			 	$.ajax({
			   	type:"post",
			   	url:"<?php echo ADMIN_PATH;?>salesreport/getdetailsbysid",
			  	data:"sid="+sid,
				success:function(data){
					//alert(data);
					var divs = data.split('--');
					 $( '#dat' ).html( divs[0] );
					  $( '#dat1' ).html( divs[1] );
					   $( '#dat2' ).html( divs[2] );
					    $( '#dat3' ).html( divs[3] );
						$( '#dat4' ).html( divs[4] );
						$( '#dat5' ).html( divs[5] );
					  
					//$("#dat").html(data);
					}		   
			   			});
        });
	<!---- date wise report----->				
$("#txtdate").change(function(e) {
	
	//alert(1);
	var date=$( this).val();
	//alert(date);
				$.ajax({
			   	type:"post",
			   	url:"<?php echo ADMIN_PATH;?>salesreport/getdetailsbydate",
			  	data:"date="+date,
				success:function(data){
					//alert(data);
					var divs = data.split('--');
					 $( '#dat' ).html( divs[0] );
					  $( '#dat1' ).html( divs[1] );
					   $( '#dat2' ).html( divs[2] );
					    $( '#dat3' ).html( divs[3] );
						$( '#dat4' ).html( divs[4] );
						$( '#dat5' ).html( divs[5] );
					//$("#dat").html(data);
					}		   
			   			});
        });
		
		<!---- area wise report----->				
$("#selarea").change(function(e) {
	
	//alert(1);
	var area=$( this).val();
	//alert(area);
				$.ajax({
			   	type:"post",
			   	url:"<?php echo ADMIN_PATH;?>salesreport/getdetailsbyarea",
			  	data:"area="+area,
				success:function(data){
					//alert(data);
					//$("#dat").html(data);
					var divs = data.split('--');
					 $( '#dat' ).html( divs[0] );
					  $( '#dat1' ).html( divs[1] );
					   $( '#dat2' ).html( divs[2] );
					    $( '#dat3' ).html( divs[3] );
						$( '#dat4' ).html( divs[4] );
						$( '#dat5' ).html( divs[5] );
					}		   
			   			});
        });
		
			<!---- merchant wise report----->				
$("#selmerchant").change(function(e) {
	
	//alert(1);
	var mid=$( this).val();
	//alert(mid);
				$.ajax({
			   	type:"post",
			   	url:"<?php echo ADMIN_PATH;?>salesreport/getdetailsbymid",
			  	data:"mid="+mid,
				success:function(data){
				//alert(data);
					//$("#dat").html(data);
					var divs = data.split('--');
					 $( '#dat' ).html( divs[0] );
					  $( '#dat1' ).html( divs[1] );
					   $( '#dat2' ).html( divs[2] );
					    $( '#dat3' ).html( divs[3] );
						$( '#dat4' ).html( divs[4] );
						$( '#dat5' ).html( divs[5] );
					}		   
			   			});
        });
		
		   });
						</script>