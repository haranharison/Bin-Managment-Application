<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Tax extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Tax_model','model');
	 }	
	 public function index()
	{
	//Tax Table & Adding Field
		$data['tax']=$this->model->gettax();//fetch all tax Names	default
		$data['menu']='organizer';
		$data['submenu']='tax';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/tax/tax',$data);
		$this->load->view('admin/footer');
	}
	//ADD New Tax
	public function addtax()
	{
		$this->model->addtax();	
	}	
	//Edit Tax Name 
	public function edittax($id=false)
	{
		$data['tax']=$this->model->edittax($id);
		$data['menu']='organizer';
		$data['submenu']='tax';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/tax/tax_edit',$data);
		$this->load->view('admin/footer');
	}
/*____________________________________________________________________________________________________________*/	
	public function deletetax()
	{
		$this->model->deletetax();	
	}
	public function getdetails()
	{
		$this->model->getdetails();	
	}
		public function updatetax()
	{
		$this->model->updatetax();	
	}

}

