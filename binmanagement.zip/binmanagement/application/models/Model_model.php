<?php
class Model_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	
	public function getbrand()
	{
	
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_brand')->result();

	}
	
	public function getallmodel()
	{
		$oid=$this->session->userdata('org_id');
		$array=array('tbl_model.status'=>0,'tbl_model.org_id'=>$oid);
		$this->db->where($array);
		$this->db->select('tbl_model.*,tbl_brand.man_title');
		$this->db->from('tbl_model');
		$this->db->join('tbl_brand','tbl_model.brand_id=tbl_brand.man_id');
		return $rows=$this->db->get()->result();
	}
	
	public function getdet($id)
	{
	$sid=decode($id);
			$array=array('status'=>0,'model_id'=>$sid);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_model')->row();

	}
	/////////////////////////////////////////////////////////////////////////
	
	public function insert()
	{
			$exist=fieldexist('tbl_model','model_name',$this->input->post('txtsubcategory'),'org_id',$this->session->userdata('org_id'));
	if($exist==1){
		echo 1;
	}else{
		$max=maxplus('tbl_model','model_id');
		$today= date("y-m-d");
		$subcategory=$this->input->post('txtsubcategory');
		$orgid=$this->session->userdata('org_id');
		$category=decode($this->input->post('selcat'));
		$data= array(
			 'model_id'=>$max,
			 'org_id'=>$orgid,
		      'model_name'=>$subcategory,
			   'brand_id'=>$category,
			   'created_date'=>$today,
			   'modified_date'=>$today
		);
		$this->db->insert('tbl_model',$data);
		}
		
	}
       
	   
	    
		public function editcategory($id){
			$cid=$id;
				$array=array('subcategory_id'=>$cid,'status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_subcategory')->row();
			}
			
			public function update()
			{
				$max=decode($this->input->post('hdid'));
		$today= date("y-m-d");
		$subcategory=$this->input->post('txtsubcategory');
		$orgid=$this->session->userdata('org_id');
		$category=decode($this->input->post('selcat'));
		$data= array(
			
			 'org_id'=>$orgid,
		      'model_name'=>$subcategory,
			   'brand_id'=>$category,
			  
			   'modified_date'=>$today
		);
		$this->db->where('model_id',$max);
		$this->db->update('tbl_model',$data);
				
				}
			
				
//New 
	public function delete()
	{
		$id=decode($this->input->post('id'));
		 $array= array('model_id'=>$id);
		   $this->db->where($array);
		   $this->db->delete('tbl_model');
		}
	
	
		
		
}