<?php
class Product_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	
	public function newprotype(){
		$exist=fieldexist('tbl_product_type','pro_type_name',$this->input->post('txtprotype'),'org_id',$this->session->userdata('org_id'));
	  if($exist==1){
		     echo 1;
	     }
	       else
	     {
			$max=maxplus('tbl_product_type','pro_type_id');
			$today=date("y-m-d");
			$txtprotype=$this->input->post('txtprotype');
			$txtproper=$this->input->post('txtproper');
			$data= array( 
				'org_id'=>$this->session->userdata('org_id'),
				'pro_type_id'=>$max,
				'pro_type_name'=>$txtprotype,
				'pro_type_percentage'=>$txtproper,
				'created_date'=>$today,
				'modified_date'=>$today
			);
			$this->db->insert('tbl_product_type',$data);
		 }
		}
	 public function getprotypes()
		{
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_product_type')->result();
		}
        public function getcategory()
		{
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_category')->result();
		}
		  public function getmanufacturer()
		{
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_manufacture')->result();
		}
		public function addingcategorydirect(){
			$max=maxplus('tbl_category','category_id');
		$today= date("y-m-d");
		$category=$this->input->post('txtcats');
		$data= array(
		'org_id'=>$this->session->userdata('org_id'),
			'category_id' =>$max,
		       'cat_name'=>$category,
			   'create_date'=>$today,
			   'modify_date'=>$today
		);
		$this->db->insert('tbl_category',$data);
			
		}
		public function addnewmesure(){
			$max=maxplus('tbl_measurement','measurement_id');
			$today=date("y-m-d");
			$mesure=$this->input->post('munit');
			$data= array( 
				   'org_id'=>$this->session->userdata('org_id'),
				   'measurement_id'=>$max,
				   'measurement_name'=>$mesure,
				   'created_date'=>$today,
				   'modified_date'=>$today
			);
			$this->db->insert('tbl_measurement',$data);
		}
		
		
	public function addnewhsn(){
		
			$max=maxplus('tbl_hsn','hsn_id');
			$today=date("y-m-d");
			$name=$this->input->post('hsn');
			$data= array( 
				   'org_id'=>$this->session->userdata('org_id'),
				   'hsn_id'=>$max,
				   'hsn_code'=>$name,
				   'created_date'=>$today,
				   'modified_date'=>$today
			);
			$this->db->insert('tbl_hsn',$data);
		
		
		}
			public function addnewmanufacturer(){
			$max=maxplus('tbl_manufacture','manufacture_id');
			$today=date("y-m-d");
			$txtmanus=$this->input->post('txtmanus');
			$data= array( 
				   'org_id'=>$this->session->userdata('org_id'),
				   'manufacture_id'=>$max,
				   'manufacture_name'=>$txtmanus,
				   'created_date'=>$today,
				   'modified_date'=>$today
			);
			$this->db->insert('tbl_manufacture',$data);
		}
			public function getnewmanufacturer()
		{
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),);
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_manufacture');
				 $res= $rows->result();
				 $html='';
				 
				 if($rows->num_rows()>0){
					 
					 $html.='<select class="form-control form-control1" id="manufacturer" name="manufacturer" style="display:block;" ><option value="0" >Select Manufacturer</option>';
					foreach($res as $val){
					 $html.='<option value="'.$val->manufacture_id.'">'.$val->manufacture_name.'</option>	';
					}
					$html.='</select><label for="price">Manufacturer</label>';
					 //$html.='</select><a class="addDynamicfield btnaddunit"><i class="material-icons">add_circle</i></a>';
					 }
					
					
						 
				echo $html;
		}
		public function getnewprotypes()
		{
	
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_product_type');
				 $res= $rows->result();
				 $html='';
				 
				 if($rows->num_rows()>0){
					 
					 $html.='<select class="form-control form-control1" id="selptype" name="selptype" style="display:block;" ><option value="0" >Select Tax Type</option>';
					foreach($res as $val){
					 $html.='<option value="'.$val->pro_type_id.'">'.$val->pro_type_name.'</option>	';
					}
					$html.='</select><label for="product tax">Tax Type</label>';
					 //$html.='</select><a class="addDynamicfield btnaddunit"><i class="material-icons">add_circle</i></a>';
					 }
					
					
						 
				echo $html;
		
		}
		public function getnewmesureunit()
		{
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),);
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_measurement');
				 $res= $rows->result();
				 $html='';
				 
				 if($rows->num_rows()>0){
					 
					 $html.='<select class="form-control form-control1" id="selunit" name="selunit" style="display:block;" ><option value="0" >Select Product Unit</option>';
					foreach($res as $val){
					 $html.='<option value="'.$val->measurement_id.'">'.$val->measurement_name.'</option>	';
					}
					$html.='</select>';
					 //$html.='</select><a class="addDynamicfield btnaddunit"><i class="material-icons">add_circle</i></a>';
					 }
					
					
						 
				echo $html;
		}
			public function getallhsn()
		{
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),);
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_hsn');
				return  $res= $rows->result();
		}
			public function getnewhsn()
		{
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),);
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_hsn');
				 $res= $rows->result();
				 $html='';
				 
				 if($rows->num_rows()>0){
					 
					 $html.='<select class="form-control txthsncode" id="txthsncode" name="txthsncode" ><option value="0" >Select Hsn Code</option>';
					foreach($res as $val){
					 $html.='<option value="'.$val->hsn_id.'">'.$val->hsn_code.'</option>	';
					}
					$html.='</select><label for="first_name">Hsn Code</label>';
					 //$html.='</select><a class="addDynamicfield btnaddunit"><i class="material-icons">add_circle</i></a>';
					 }
					
					
						 
				echo $html;
		}
		
		
		
		
		
		
		
		public function getnewsubcats()
		{
				$cat=$this->input->post('catval');
				$array=array('status'=>0,'cat_id'=>$cat,'org_id'=>$this->session->userdata('org_id'),);
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_subcategory');
				 $res= $rows->result();
				 $html='';
				  $html.='<select class="form-control selsubcats" id="selsubcats" name="selsubcat">';
				 if($rows->num_rows()>0){
					  $html.='<option value="0" >Select Sub Category</option>';
					
					foreach($res as $val){
					 $html.='<option value="'.$val->subcategory_id.'">'.$val->subcat_name.'</option>	';
					}
					
					 }
					 else{
						 $html.='<option value="0">--No result found--</option>	';
						}
						$html.='</select>';
						// $html.='</select><a class="addDynamicfield btnaddsubcat"><i class="material-icons">add_circle</i></a>';
				echo $html;	
}
public function getnewcats()
{
	
				$cat=decode($this->input->post('cat'));
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_category');
				 $res= $rows->result();
				 $html='';
				  $html.='<select class="form-control form-control1 ncat" id="selcat" name="selcat" >';
				 if($rows->num_rows()>0){
					  $html.='<option value="0" >Select Category</option>';
					
					foreach($res as $val){
						if($val->category_id==$cat){
							$sel='selected';
							}
							else{
							$sel='';
							}
					 $html.='<option value="'.$val->category_id.'"'.$sel.' >'.$val->cat_name.'</option>	';
					}
					
					 }
					 else{
						 $html.='<option value="0">--No result found--</option>	';
						}
						
						 $html.='</select><a class="addDynamicfield btnaddcat"><i class="material-icons">add_circle</i></a>';
				echo $html;	
}
	public function addingsubcategorydirect(){
		
			$max=maxplus('tbl_subcategory','subcategory_id');
		$today= date("y-m-d");
		$subcategory=$this->input->post('txtsubcats');
		$cat=$this->input->post('cat');
		$data= array(
		'org_id'=>$this->session->userdata('org_id'),
			 'subcategory_id'=>$max,
		       'subcat_name'=>$subcategory,
			 'cat_id'=>$cat,
			   'create_date'=>$today,
			   'modify_date'=>$today
		);
		$this->db->insert('tbl_subcategory',$data);
		
		
	}
		
		
		public function getsubcategory()
		{
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_subcategory')->result();
		}
		//GET tax name
		public function gettax()
		{
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_tax')->result();
		}
		//GET Product Measure ments
		public function getmeasurement(){
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_measurement')->result();
		}
	//GET Product Tax Propertes	
	public function newgettaxproperty(){
			$id=decode($this->input->post('selectedtaxid'));
			$array=array('ptax_taxid'=>$id,'status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');//ptax_propery,ptax_u_id
			$result=$this->db->get('tbl_taxpropery');
			$rows=$result->result();
			$count=$result->num_rows();
			$html='';
				if($count > 0)
				{
					foreach($rows as $val =>$key){
							$html.='<div class="input-field col s6 append-div-item"><input type="hidden" name="subtaxid[]" value="'.encode($key->ptax_u_id).'">';
							$html.='<input class="form-control input_field-tax_properties txval" id="input_field-tax_properties" name="subtax[]" type="text" >';
							$html.='<label for="sub tax">Value of '.$key->ptax_propery.'</label><div class="iconunit">%</div></div>';
				}
				}
				else{
					$html.='<div class="input-field col s12 append-div-item"><div class="card-panel">
      <span style="user-select: none;" class="red-text text-darken-2">Tax Property Not Added ! <a class="blue-text darken-3" href=""> Click here to add</a></span>
    </div></div>';
				}
				echo $html;	
	}
	//GET PRODUCT TAX PROPERTY
	public function gettaxproperty($id)
	{	
		$pid=decode($id);
			$array=array('product_id'=>$pid,'status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('product_tax');
			$rows=$this->db->get('tbl_product')->row();
			
			$ptax=$rows->product_tax;
			$array=array('txp_p_id'=>$pid);
			$this->db->where($array);
			$this->db->select('tbl_taxpropery.ptax_propery,tbl_product_tax.*');
			$this->db->from('tbl_product_tax');
			$this->db->join('tbl_taxpropery','tbl_product_tax.txp_property=tbl_taxpropery.ptax_u_id');
			return $data=$this->db->get()->result();
			//var_dump($rows);		
	}
/*--------------------------------------------*/		
	public function getproduct()
	{
		$array=array('tbl_product.status' =>0,'tbl_product.org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->group_by('product_id');
		$this->db->select('tbl_category.cat_name,tbl_category.cat_id,tbl_product.*');
		$this->db->from('tbl_product');
		$this->db->join('tbl_category', 'tbl_category.category_id=tbl_product.cat_id');
		
		return $rows=$this->db->get()->result();
	}
	public function getsubcategorybycategoryid(){
			$id=$this->input->post('catid');
		
			//var_dump($id);
			$array=array('cat_id'=>$id,'status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
       		$result=$this->db->get('tbl_subcategory');
       		$rows=$result->result();
			//echo $rows;
     			$html='';
				if($result->num_rows() > 0)
				{
					$html.='<option value="0" class="bt">Select Sub Category</option>';
					foreach($rows as $val =>$key)
					{
						$html.='<option value="'.$key->sub_id.'">'.$key->subcat_name.'</option>';
					}
				}else{
					$html.='<option value="0">-- No result  --</option>'; 
				}
			echo $html;
		}	
		
		
		public function newselgetsubcategoriey(){
			
			
			$id=$this->input->post('catid');
			$sid=$this->input->post('scatid');
		
			//var_dump($id);
			$array=array('cat_id'=>$id,'status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
       		$result=$this->db->get('tbl_subcategory');
       		$rows=$result->result();
			//echo $rows;
     			$html='';
				if($result->num_rows() > 0)
				{
					$html.='<option value="0" class="bt">Select Sub Category</option>';
					foreach($rows as $val =>$key)
					{
						if($key->sub_id==$sid){
							$sel='selected';
							}
							else{
								$sel='';
								}
						$html.='<option value="'.$key->sub_id.'"'.$sel.' >'.$key->subcat_name.'</option>';
					}
				}else{
					$html.='<option value="0">-- No result  --</option>'; 
				}
			echo $html;
		}	
//New Product - add new Product
	public function addproduct() // addproduct
	{
	$exist=fieldexist('tbl_product','product_name',$this->input->post('txtproduct'),'org_id',$this->session->userdata('org_id'));
		if($exist==1){
			echo 1;
		}else{
				$max=maxplus('tbl_product','product_id');
				$today= date("y-m-d");
				$ptype=$this->input->post('selptype');
				$hsncode=$this->input->post('txthsncode');
				$category=$this->input->post('selcat');
				$subcategory=$this->input->post('selsubcat');
				$product=$this->input->post('txtproduct');
				$tax=$this->input->post('seltax');
				$amount=$this->input->post('txtamount');
				$purchase=$this->input->post('purchase');
				$batch=$this->input->post('batch');
				$discount=$this->input->post('txtdiscount');
				$netamount=$this->input->post('txtnetamount');
				
				$txtpcode=$this->input->post('txtpcode');
				$txtbcode=$this->input->post('txtbcode');
				$txtmrp=$this->input->post('txtmrp');
				$selunit=$this->input->post('selunit');
				$qtyinhand=$this->input->post('qtyinhand');
				$description=$this->input->post('description');
				$txtrack=$this->input->post('txtrack');
				$txreorderlvl=$this->input->post('txreorderlvl');
			$manufacturer=$this->input->post('manufacturer');
				
				$unit=$this->input->post('selunit');
				$negative=$this->input->post('selNeg');
				$data= array(
				'org_id'=>$this->session->userdata('org_id'),
						'p_type'=>$ptype,
						'p_hsncode'=>$hsncode,
					   	'subcat_id'=>$subcategory,
					   	'product_id'=>$max,
					   	'amount'=>$amount,
					   	'cat_id'=>$category,
					   	'product_name'=>$product,
					 //  	'product_tax'=>$tax,
					   	'p_measurement'=>$unit,
						'pur_amount'=>$purchase,
						'banum'=>$batch,
					//   	'p_discount'=>$discount,
					 //  	'p_netamount'=>$netamount,
						
						'manufacturer'=>$manufacturer,
							'product_code'=>$txtpcode,
							'barcode_num'=>$txtbcode,
							'mrp'=>$txtmrp,
							'qtyonhand'=>$qtyinhand,
							'description'=>$description,
							'rack'=>$txtrack,
							'reorder_lvl'=>$txreorderlvl,
							'negative_stock'=>$negative,
						
						
					   	'create_date'=>$today,
					   	'modify_date'=>$today
				);
				
			$this->db->insert('tbl_product',$data);
			//	echo json_encode($data);
			//Insert Product Tax values
	/*	$s=$this->input->post('subtaxid');
		$i=0;
			foreach($this->input->post('subtax') as $taxvalue){	
				$max1=maxplus('tbl_product_tax','txp_id');
				$sv=decode($s[$i]);
				$subtaxdata= array(
				'org_id'=>$this->session->userdata('org_id'),
				   'txp_uid'=>$max1,
				   'txp_p_id'=>$max,
				   'txp_tax_type'=>$tax,
				   'txp_property'=>$sv,
				   'txp_percentage'=>$taxvalue,
				   'status'=>0,
				   'created_date'=>$today,
				   'modifed_date'=>$today
			   ); 
			   $i++;	
			 $this->db->insert('tbl_product_tax',$subtaxdata);
			}*/
		
			//echo json_encode($subtaxdata);
		}
}
			
//Get Product details for product edit	- New
		public function editproduct($id)
		{
		$pid=decode($id);
		$array=array('product_id'=>$pid,'status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_product')->row();
		//var_dump($rows);
		}
		//Get Product tax for edit
		public function getproducttax(){//SAME AS GET TAX FUNCTION
			/*$array=array('status'=>0);
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_tax')->result();*/
		}
		

		
	//new	
	public function editsubcategory(){
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
       		$result=$this->db->get('tbl_subcategory');
       		return $rows=$result->result();
			//echo $rows;
		}	

//UPDATE PRODUCT DETAILS - new		
public function updaproduct()
		{
		$pid=decode($this->input->post('hiddenprdid'));
		$array= array('product_id'=>$pid);
		$today= date("Y-m-d");
				$product=$this->input->post('txtproduct');
				$batch=$this->input->post('batch');
				$pdtcod=$this->input->post('txtpcode');	
				$barco=$this->input->post('txtbcode');
				$ptype=$this->input->post('selptype');
				$mrp=$this->input->post('txtmrp');
				$category=$this->input->post('selcat');
				$purchase=$this->input->post('purchase');
				$subcategory=$this->input->post('selsubcat');
				$salerte=$this->input->post('txtamount');
				$tax=$this->input->post('seltax');
				$manuf=$this->input->post('manufacturer');
				$qtyhd=$this->input->post('qtyinhand');
				$unit=$this->input->post('selunit');
				$desc=$this->input->post('description');
				$rack=$this->input->post('txtrack');
				$hsncode=$this->input->post('txthsncode');
				$reord=$this->input->post('txreorderlvl');

				$data= array(
						'product_name'=>$product,
						'banum'=>$batch,
						'product_code'=>$pdtcod,
						'barcode_num'=>$barco,
						'p_type'=>$ptype,
						'mrp'=>$mrp,
						'cat_id'=>$category,
						'pur_amount'=>$purchase,
					   'subcat_id'=>$subcategory,
						'amount'=>$salerte,
						'manufacturer'=>$manuf,
						'qtyonhand'=>$qtyhd,
						'p_measurement'=>$unit,
						'description'=>$desc,
						'rack'=>$rack,
						'p_hsncode'=>$hsncode,
						'reorder_lvl'=>$reord,
						
				);	 	
		$this->db->where($array);
		$this->db->update('tbl_product',$data);
		
			

	}	
	//Delete Product incom	
		public function deleteproduct(){
		 	$cid=decode($this->input->post('id'));
		   $data=array('status'=>1);
		   $array= array('product_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_product',$data);
		}
}