<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Merchant extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Merchant_model','model');
	 }	public function index()
	{
			//$data['title']='Merchant Registration';	
	      //	$data['product']=$this->model->getproduct();
		//var_dump($data['product']);
        $data['merchant']=$this->model->getmerchant();
		$data['menu']='merchant';
		$data['submenu']='merlist'; 
		$this->load->view('admin/header',$data);
		$this->load->view('admin/merchant/merchanthome',$data);
		$this->load->view('admin/footer');
	}
	
	public function addmerchant()
	{   $data['title']='Merchant Registration';
	    $data['menu']='merchant';
		$data['submenu']='newmerchant'; 
	    $this->load->view('admin/header',$data);
		$data['area']=$this->model->getarea();
		$data['merchant']=$this->model->getmerchant();
		$this->load->view('admin/merchant/merchantregistration',$data);
		$this->load->view('admin/footer');
	}
	
	public function merchantadd()
	{
	$this->model->merchantadd();
	}
	public function merchantedit($id=false)
	{
	    $data['title']='Edit Merchant Registration';	
		$data['menu']='merchant';
		$data['submenu']='merlist'; 
		//$data['merchantid']=$this->model->getmerchantid();
		$data['merchant']=$this->model->getmerchant();
		$data['area']=$this->model->getarea();
		$data['edit']=$this->model->editmerchant($id);
		$this->load->view('admin/header',$data);
		$this->load->view('admin/merchant/editmerchant',$data);
		$this->load->view('admin/footer');	
	}
	public function updatemerchant()
	{
		$this->model->updatemerchant();
	}
	
	public function merchantproductadd()
	{
		$data['merchantid']=$this->model->getmerchantid();
		$data['productcat']=$this->model->getcategory();
		$data['merchant']=$this->model->getmerchant();
		$data['area']=$this->model->getarea();
		$this->load->view('admin/header');
			$this->load->view('admin/merchant/merchantproductadd',$data);
		$this->load->view('admin/footer');
	}
		public function deletemerchant()
	{
		$this->model->deletemerchant();
	}
	
	public function getsubcategorybycategoryid()
	{ //fetching sucbcategory by category 
		$this->model->getsubcategorybycategoryid();
		
	}
	public function getproductsbysubcategoryid()
	{ //fetching products by sucbcategory 
		$this->model->getproductsbysubcategoryid();
		
	}
	public function addmerchantproduct()
	{ //add salesman product
		$this->model->addmerchantproduct();
		
	}
	public function editmerchantreg($id=false,$mid=false)
	{ //add salesman product
		$data['title']='Edit Merchant Registration';	
		$data['merchantid']=$this->model->getmerchantid();
		$data['productcat']=$this->model->getcategory();
		$data['area']=$this->model->getarea();
		$data['edit']=$this->model->editmerchantreg($id);
		$data['terminal']=$this->model->getterminal($mid);
		//var_dump($data['edit']);
		$this->load->view('admin/header');
			$this->load->view('admin/merchant/editmerchant',$data);
		$this->load->view('admin/footer');
	}
	
	public function editmerchantproduct($id=false)
	{ //add salesman product
		$data['title']='Edit Merchant Product';	
		$data['productcat']=$this->model->getcategory();
		$data['editcategory']=$this->model->editcategory($id);
		$data['editsubcategory']=$this->model->editsubcategory($id);
		   $data['merchant']=$id;
$data['productsubcat']=$this->model->getsubcategory();
		$data['products']=$this->model->getproducts($data['editsubcategory'][0]);
		$data['edit']=$this->model->editmerchantproduct($id);
	//	var_dump($data['edit']);
		$this->load->view('admin/header');
			$this->load->view('admin/merchant/editmerchantproductadd',$data);
		$this->load->view('admin/footer');
	}
	
	
	
	public function updatemerchantproduct()
	{
		$this->model->updatemerchantproduct();
	}
	
}
