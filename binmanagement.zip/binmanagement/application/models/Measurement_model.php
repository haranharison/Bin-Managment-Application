<?php
class Measurement_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	
		public function getmeasurement(){
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_measurement')->result();
		}
		
	public function addmeasurement()
		{
		$exist=fieldexist('tbl_measurement','measurement_name',$this->input->post('mesname'),'org_id',$this->session->userdata('org_id'));
		if($exist==1){
		echo 1;
		}
		else{
			$max=maxplus('tbl_measurement','measurement_id');
			$today= date("y-m-d");
			$tax=$this->input->post('mesname');
			$data= array(
			'org_id'=>$this->session->userdata('org_id'),
				   'measurement_id'=>$max,
				   'measurement_name'=>$tax,
				   'created_date'=>$today,
				   'modified_date'=>$today
			);
			$this->db->insert('tbl_measurement',$data);
			}
		
	}

	public function getdetails()
	{
		 $eid=decode($this->input->post('eid'));
		$array=array('measurement_id'=>$eid,'status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('measurement_name');
		 $rows=$this->db->get('tbl_measurement')->row();
		 echo $rows->measurement_name;
		
	}	
	public function updatemeasurement()
	{
		$eid=decode($this->input->post('eid'));
		$mname=$this->input->post('mname');
		$data=array('measurement_id'=>$eid,'measurement_name'=>$mname);
		$array=array('measurement_id'=>$eid,'status'=>0);
		$this->db->where($array);
		$this->db->update('tbl_measurement',$data);
		 echo 1;
	}
	
		public function deletemeasurement(){
		 $did=decode($this->input->post('id'));
		 $data=array('status'=>1);
		 $array= array('measurement_id'=>$did);
		 $this->db->where($array);
		 $this->db->update('tbl_measurement',$data);
	}
		
		
}